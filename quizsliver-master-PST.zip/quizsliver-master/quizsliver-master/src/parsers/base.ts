export interface IParser {
  parse(doc: Document);
}
