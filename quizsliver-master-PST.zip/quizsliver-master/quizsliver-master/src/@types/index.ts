export const _app$ = Symbol();
(window[_app$] as any) = {};
