export interface IHandler {
  handle(doc: Document);
}
