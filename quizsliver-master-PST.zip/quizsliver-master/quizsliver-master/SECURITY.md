# Security Policy

## Supported Versions

Supported Versions of Quiz Sliver are given below recommend to use the lastest version currently being supported with security updates.

| Version  | Supported          |
| -------- | ------------------ |
| 1.3.3 (Latest/Recommend)  | :white_check_mark: |
| v1.3.2   | :x:                |
| v1.3.1   | :x:                |
| < v1.3.0 | :x:                |

## Unsupported Versions

Avoid using those Unsupported version of Quiz Sliver as the ownership is transferred

| Version  | Older          |
| -------- | ------------------ |
| v1.2.7   | :x:                |
| v1.2.6   | :x:                |
| v1.2.5   | :x:                |
| v1.2.3   | :x:                |

## Disclaimer

This extension is provided as is without any warranty of any kind. Also Author is not responsible for any kind of damage caused by this piece of software. USE AT YOU OWN RISK.
