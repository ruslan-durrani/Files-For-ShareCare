(function () {
    'use strict';

    const _app$ = Symbol();
    window[_app$] = {};

    var n$1,l$3,u$2,t$2,o$2,r$2,f$3,e$2={},c$2=[],s$2=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;function a$2(n,l){for(var u in l)n[u]=l[u];return n}function h$2(n){var l=n.parentNode;l&&l.removeChild(n);}function v$3(l,u,i){var t,o,r,f={};for(r in u)"key"==r?t=u[r]:"ref"==r?o=u[r]:f[r]=u[r];if(arguments.length>2&&(f.children=arguments.length>3?n$1.call(arguments,2):i),"function"==typeof l&&null!=l.defaultProps)for(r in l.defaultProps)void 0===f[r]&&(f[r]=l.defaultProps[r]);return y$3(l,f,t,o,null)}function y$3(n,i,t,o,r){var f={type:n,props:i,key:t,ref:o,__k:null,__:null,__b:0,__e:null,__d:void 0,__c:null,__h:null,constructor:void 0,__v:null==r?++u$2:r};return null!=l$3.vnode&&l$3.vnode(f),f}function p$3(){return {current:null}}function d$3(n){return n.children}function _$2(n,l){this.props=n,this.context=l;}function k$4(n,l){if(null==l)return n.__?k$4(n.__,n.__.__k.indexOf(n)+1):null;for(var u;l<n.__k.length;l++)if(null!=(u=n.__k[l])&&null!=u.__e)return u.__e;return "function"==typeof n.type?k$4(n):null}function b$3(n){var l,u;if(null!=(n=n.__)&&null!=n.__c){for(n.__e=n.__c.base=null,l=0;l<n.__k.length;l++)if(null!=(u=n.__k[l])&&null!=u.__e){n.__e=n.__c.base=u.__e;break}return b$3(n)}}function m$3(n){(!n.__d&&(n.__d=!0)&&t$2.push(n)&&!g$4.__r++||r$2!==l$3.debounceRendering)&&((r$2=l$3.debounceRendering)||o$2)(g$4);}function g$4(){for(var n;g$4.__r=t$2.length;)n=t$2.sort(function(n,l){return n.__v.__b-l.__v.__b}),t$2=[],n.some(function(n){var l,u,i,t,o,r;n.__d&&(o=(t=(l=n).__v).__e,(r=l.__P)&&(u=[],(i=a$2({},t)).__v=t.__v+1,j$4(r,t,i,l.__n,void 0!==r.ownerSVGElement,null!=t.__h?[o]:null,u,null==o?k$4(t):o,t.__h),z$3(u,t),t.__e!=o&&b$3(t)));});}function w$3(n,l,u,i,t,o,r,f,s,a){var h,v,p,_,b,m,g,w=i&&i.__k||c$2,A=w.length;for(u.__k=[],h=0;h<l.length;h++)if(null!=(_=u.__k[h]=null==(_=l[h])||"boolean"==typeof _?null:"string"==typeof _||"number"==typeof _||"bigint"==typeof _?y$3(null,_,null,null,_):Array.isArray(_)?y$3(d$3,{children:_},null,null,null):_.__b>0?y$3(_.type,_.props,_.key,null,_.__v):_)){if(_.__=u,_.__b=u.__b+1,null===(p=w[h])||p&&_.key==p.key&&_.type===p.type)w[h]=void 0;else for(v=0;v<A;v++){if((p=w[v])&&_.key==p.key&&_.type===p.type){w[v]=void 0;break}p=null;}j$4(n,_,p=p||e$2,t,o,r,f,s,a),b=_.__e,(v=_.ref)&&p.ref!=v&&(g||(g=[]),p.ref&&g.push(p.ref,null,_),g.push(v,_.__c||b,_)),null!=b?(null==m&&(m=b),"function"==typeof _.type&&null!=_.__k&&_.__k===p.__k?_.__d=s=x$4(_,s,n):s=P$3(n,_,p,w,b,s),a||"option"!==u.type?"function"==typeof u.type&&(u.__d=s):n.value=""):s&&p.__e==s&&s.parentNode!=n&&(s=k$4(p));}for(u.__e=m,h=A;h--;)null!=w[h]&&("function"==typeof u.type&&null!=w[h].__e&&w[h].__e==u.__d&&(u.__d=k$4(i,h+1)),N$3(w[h],w[h]));if(g)for(h=0;h<g.length;h++)M$3(g[h],g[++h],g[++h]);}function x$4(n,l,u){var i,t;for(i=0;i<n.__k.length;i++)(t=n.__k[i])&&(t.__=n,l="function"==typeof t.type?x$4(t,l,u):P$3(u,t,t,n.__k,t.__e,l));return l}function A$4(n,l){return l=l||[],null==n||"boolean"==typeof n||(Array.isArray(n)?n.some(function(n){A$4(n,l);}):l.push(n)),l}function P$3(n,l,u,i,t,o){var r,f,e;if(void 0!==l.__d)r=l.__d,l.__d=void 0;else if(null==u||t!=o||null==t.parentNode)n:if(null==o||o.parentNode!==n)n.appendChild(t),r=null;else {for(f=o,e=0;(f=f.nextSibling)&&e<i.length;e+=2)if(f==t)break n;n.insertBefore(t,o),r=o;}return void 0!==r?r:t.nextSibling}function C$3(n,l,u,i,t){var o;for(o in u)"children"===o||"key"===o||o in l||H$3(n,o,null,u[o],i);for(o in l)t&&"function"!=typeof l[o]||"children"===o||"key"===o||"value"===o||"checked"===o||u[o]===l[o]||H$3(n,o,l[o],u[o],i);}function $$4(n,l,u){"-"===l[0]?n.setProperty(l,u):n[l]=null==u?"":"number"!=typeof u||s$2.test(l)?u:u+"px";}function H$3(n,l,u,i,t){var o;n:if("style"===l)if("string"==typeof u)n.style.cssText=u;else {if("string"==typeof i&&(n.style.cssText=i=""),i)for(l in i)u&&l in u||$$4(n.style,l,"");if(u)for(l in u)i&&u[l]===i[l]||$$4(n.style,l,u[l]);}else if("o"===l[0]&&"n"===l[1])o=l!==(l=l.replace(/Capture$/,"")),l=l.toLowerCase()in n?l.toLowerCase().slice(2):l.slice(2),n.l||(n.l={}),n.l[l+o]=u,u?i||n.addEventListener(l,o?T$4:I$3,o):n.removeEventListener(l,o?T$4:I$3,o);else if("dangerouslySetInnerHTML"!==l){if(t)l=l.replace(/xlink[H:h]/,"h").replace(/sName$/,"s");else if("href"!==l&&"list"!==l&&"form"!==l&&"tabIndex"!==l&&"download"!==l&&l in n)try{n[l]=null==u?"":u;break n}catch(n){}"function"==typeof u||(null!=u&&(!1!==u||"a"===l[0]&&"r"===l[1])?n.setAttribute(l,u):n.removeAttribute(l));}}function I$3(n){this.l[n.type+!1](l$3.event?l$3.event(n):n);}function T$4(n){this.l[n.type+!0](l$3.event?l$3.event(n):n);}function j$4(n,u,i,t,o,r,f,e,c){var s,h,v,y,p,k,b,m,g,x,A,P=u.type;if(void 0!==u.constructor)return null;null!=i.__h&&(c=i.__h,e=u.__e=i.__e,u.__h=null,r=[e]),(s=l$3.__b)&&s(u);try{n:if("function"==typeof P){if(m=u.props,g=(s=P.contextType)&&t[s.__c],x=s?g?g.props.value:s.__:t,i.__c?b=(h=u.__c=i.__c).__=h.__E:("prototype"in P&&P.prototype.render?u.__c=h=new P(m,x):(u.__c=h=new _$2(m,x),h.constructor=P,h.render=O$3),g&&g.sub(h),h.props=m,h.state||(h.state={}),h.context=x,h.__n=t,v=h.__d=!0,h.__h=[]),null==h.__s&&(h.__s=h.state),null!=P.getDerivedStateFromProps&&(h.__s==h.state&&(h.__s=a$2({},h.__s)),a$2(h.__s,P.getDerivedStateFromProps(m,h.__s))),y=h.props,p=h.state,v)null==P.getDerivedStateFromProps&&null!=h.componentWillMount&&h.componentWillMount(),null!=h.componentDidMount&&h.__h.push(h.componentDidMount);else {if(null==P.getDerivedStateFromProps&&m!==y&&null!=h.componentWillReceiveProps&&h.componentWillReceiveProps(m,x),!h.__e&&null!=h.shouldComponentUpdate&&!1===h.shouldComponentUpdate(m,h.__s,x)||u.__v===i.__v){h.props=m,h.state=h.__s,u.__v!==i.__v&&(h.__d=!1),h.__v=u,u.__e=i.__e,u.__k=i.__k,u.__k.forEach(function(n){n&&(n.__=u);}),h.__h.length&&f.push(h);break n}null!=h.componentWillUpdate&&h.componentWillUpdate(m,h.__s,x),null!=h.componentDidUpdate&&h.__h.push(function(){h.componentDidUpdate(y,p,k);});}h.context=x,h.props=m,h.state=h.__s,(s=l$3.__r)&&s(u),h.__d=!1,h.__v=u,h.__P=n,s=h.render(h.props,h.state,h.context),h.state=h.__s,null!=h.getChildContext&&(t=a$2(a$2({},t),h.getChildContext())),v||null==h.getSnapshotBeforeUpdate||(k=h.getSnapshotBeforeUpdate(y,p)),A=null!=s&&s.type===d$3&&null==s.key?s.props.children:s,w$3(n,Array.isArray(A)?A:[A],u,i,t,o,r,f,e,c),h.base=u.__e,u.__h=null,h.__h.length&&f.push(h),b&&(h.__E=h.__=null),h.__e=!1;}else null==r&&u.__v===i.__v?(u.__k=i.__k,u.__e=i.__e):u.__e=L$2(i.__e,u,i,t,o,r,f,c);(s=l$3.diffed)&&s(u);}catch(n){u.__v=null,(c||null!=r)&&(u.__e=e,u.__h=!!c,r[r.indexOf(e)]=null),l$3.__e(n,u,i);}}function z$3(n,u){l$3.__c&&l$3.__c(u,n),n.some(function(u){try{n=u.__h,u.__h=[],n.some(function(n){n.call(u);});}catch(n){l$3.__e(n,u.__v);}});}function L$2(l,u,i,t,o,r,f,c){var s,a,v,y=i.props,p=u.props,d=u.type,_=0;if("svg"===d&&(o=!0),null!=r)for(;_<r.length;_++)if((s=r[_])&&(s===l||(d?s.localName==d:3==s.nodeType))){l=s,r[_]=null;break}if(null==l){if(null===d)return document.createTextNode(p);l=o?document.createElementNS("http://www.w3.org/2000/svg",d):document.createElement(d,p.is&&p),r=null,c=!1;}if(null===d)y===p||c&&l.data===p||(l.data=p);else {if(r=r&&n$1.call(l.childNodes),a=(y=i.props||e$2).dangerouslySetInnerHTML,v=p.dangerouslySetInnerHTML,!c){if(null!=r)for(y={},_=0;_<l.attributes.length;_++)y[l.attributes[_].name]=l.attributes[_].value;(v||a)&&(v&&(a&&v.__html==a.__html||v.__html===l.innerHTML)||(l.innerHTML=v&&v.__html||""));}if(C$3(l,p,y,o,c),v)u.__k=[];else if(_=u.props.children,w$3(l,Array.isArray(_)?_:[_],u,i,t,o&&"foreignObject"!==d,r,f,r?r[0]:i.__k&&k$4(i,0),c),null!=r)for(_=r.length;_--;)null!=r[_]&&h$2(r[_]);c||("value"in p&&void 0!==(_=p.value)&&(_!==l.value||"progress"===d&&!_)&&H$3(l,"value",_,y.value,!1),"checked"in p&&void 0!==(_=p.checked)&&_!==l.checked&&H$3(l,"checked",_,y.checked,!1));}return l}function M$3(n,u,i){try{"function"==typeof n?n(u):n.current=u;}catch(n){l$3.__e(n,i);}}function N$3(n,u,i){var t,o;if(l$3.unmount&&l$3.unmount(n),(t=n.ref)&&(t.current&&t.current!==n.__e||M$3(t,null,u)),null!=(t=n.__c)){if(t.componentWillUnmount)try{t.componentWillUnmount();}catch(n){l$3.__e(n,u);}t.base=t.__P=null;}if(t=n.__k)for(o=0;o<t.length;o++)t[o]&&N$3(t[o],u,"function"!=typeof n.type);i||null==n.__e||h$2(n.__e),n.__e=n.__d=void 0;}function O$3(n,l,u){return this.constructor(n,u)}function S$3(u,i,t){var o,r,f;l$3.__&&l$3.__(u,i),r=(o="function"==typeof t)?null:t&&t.__k||i.__k,f=[],j$4(i,u=(!o&&t||i).__k=v$3(d$3,null,[u]),r||e$2,e$2,void 0!==i.ownerSVGElement,!o&&t?[t]:r?null:i.firstChild?n$1.call(i.childNodes):null,f,!o&&t?t:r?r.__e:i.firstChild,o),z$3(f,u);}function q$3(n,l){S$3(n,l,q$3);}function B$2(l,u,i){var t,o,r,f=a$2({},l.props);for(r in u)"key"==r?t=u[r]:"ref"==r?o=u[r]:f[r]=u[r];return arguments.length>2&&(f.children=arguments.length>3?n$1.call(arguments,2):i),y$3(l.type,f,t||l.key,o||l.ref,null)}function D$3(n,l){var u={__c:l="__cC"+f$3++,__:n,Consumer:function(n,l){return n.children(l)},Provider:function(n){var u,i;return this.getChildContext||(u=[],(i={})[l]=this,this.getChildContext=function(){return i},this.shouldComponentUpdate=function(n){this.props.value!==n.value&&u.some(m$3);},this.sub=function(n){u.push(n);var l=n.componentWillUnmount;n.componentWillUnmount=function(){u.splice(u.indexOf(n),1),l&&l.call(n);};}),n.children}};return u.Provider.__=u.Consumer.contextType=u}n$1=c$2.slice,l$3={__e:function(n,l){for(var u,i,t;l=l.__;)if((u=l.__c)&&!u.__)try{if((i=u.constructor)&&null!=i.getDerivedStateFromError&&(u.setState(i.getDerivedStateFromError(n)),t=u.__d),null!=u.componentDidCatch&&(u.componentDidCatch(n),t=u.__d),t)return u.__E=u}catch(l){n=l;}throw n}},u$2=0,_$2.prototype.setState=function(n,l){var u;u=null!=this.__s&&this.__s!==this.state?this.__s:this.__s=a$2({},this.state),"function"==typeof n&&(n=n(a$2({},u),this.props)),n&&a$2(u,n),null!=n&&this.__v&&(l&&this.__h.push(l),m$3(this));},_$2.prototype.forceUpdate=function(n){this.__v&&(this.__e=!0,n&&this.__h.push(n),m$3(this));},_$2.prototype.render=d$3,t$2=[],o$2="function"==typeof Promise?Promise.prototype.then.bind(Promise.resolve()):setTimeout,g$4.__r=0,f$3=0;

    function getQueryParam(param) {
        return (new URLSearchParams(window.location.search)).get(param);
    }
    function hashCode(input) {
        let hash = 0, i, chr;
        if (input.length === 0)
            return hash;
        for (i = 0; i < input.length; i++) {
            chr = input.charCodeAt(i);
            hash = ((hash << 5) - hash) + chr;
            hash |= 0; // Convert to 32bit integer
        }
        return hash;
    }

    var version$4 = "1.2.7";
    var firebaseConfig = "eyJhcGlLZXkiOiJBSXphU3lBdktrY2RWVlM5MWEyU0hyYll5dV95MVhDWnhkakVtWE0iLCJkYXRhYmFzZVVSTCI6Imh0dHBzOi8vcXVpei1zbGl2ZXIuZmlyZWJhc2Vpby5jb20iLCJwcm9qZWN0SWQiOiJxdWl6LXNsaXZlciIsImFwcElkIjoiMTozODkzNzUwMDE4NTI6d2ViOmRiOGQwN2U2NDE0Yjg1Y2QwOTQzNzkifQ==";

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spreadArray(to, from, pack) {
        if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
            if (ar || !(i in from)) {
                if (!ar) ar = Array.prototype.slice.call(from, 0, i);
                ar[i] = from[i];
            }
        }
        return to.concat(ar || from);
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    var Deferred = /** @class */ (function () {
        function Deferred() {
            var _this = this;
            this.reject = function () { };
            this.resolve = function () { };
            this.promise = new Promise(function (resolve, reject) {
                _this.resolve = resolve;
                _this.reject = reject;
            });
        }
        /**
         * Our API internals are not promiseified and cannot because our callback APIs have subtle expectations around
         * invoking promises inline, which Promises are forbidden to do. This method accepts an optional node-style callback
         * and returns a node-style callback which will resolve or reject the Deferred's promise.
         */
        Deferred.prototype.wrapCallback = function (callback) {
            var _this = this;
            return function (error, value) {
                if (error) {
                    _this.reject(error);
                }
                else {
                    _this.resolve(value);
                }
                if (typeof callback === 'function') {
                    // Attaching noop handler just in case developer wasn't expecting
                    // promises
                    _this.promise.catch(function () { });
                    // Some of our callbacks don't expect a value and our own tests
                    // assert that the parameter length is 1
                    if (callback.length === 1) {
                        callback(error);
                    }
                    else {
                        callback(error, value);
                    }
                }
            };
        };
        return Deferred;
    }());

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    var ERROR_NAME = 'FirebaseError';
    // Based on code from:
    // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error#Custom_Error_Types
    var FirebaseError = /** @class */ (function (_super) {
        __extends(FirebaseError, _super);
        function FirebaseError(code, message, customData) {
            var _this = _super.call(this, message) || this;
            _this.code = code;
            _this.customData = customData;
            _this.name = ERROR_NAME;
            // Fix For ES5
            // https://github.com/Microsoft/TypeScript-wiki/blob/master/Breaking-Changes.md#extending-built-ins-like-error-array-and-map-may-no-longer-work
            Object.setPrototypeOf(_this, FirebaseError.prototype);
            // Maintains proper stack trace for where our error was thrown.
            // Only available on V8.
            if (Error.captureStackTrace) {
                Error.captureStackTrace(_this, ErrorFactory.prototype.create);
            }
            return _this;
        }
        return FirebaseError;
    }(Error));
    var ErrorFactory = /** @class */ (function () {
        function ErrorFactory(service, serviceName, errors) {
            this.service = service;
            this.serviceName = serviceName;
            this.errors = errors;
        }
        ErrorFactory.prototype.create = function (code) {
            var data = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                data[_i - 1] = arguments[_i];
            }
            var customData = data[0] || {};
            var fullCode = this.service + "/" + code;
            var template = this.errors[code];
            var message = template ? replaceTemplate(template, customData) : 'Error';
            // Service Name: Error message (service/code).
            var fullMessage = this.serviceName + ": " + message + " (" + fullCode + ").";
            var error = new FirebaseError(fullCode, fullMessage, customData);
            return error;
        };
        return ErrorFactory;
    }());
    function replaceTemplate(template, data) {
        return template.replace(PATTERN, function (_, key) {
            var value = data[key];
            return value != null ? String(value) : "<" + key + "?>";
        });
    }
    var PATTERN = /\{\$([^}]+)}/g;

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * The amount of milliseconds to exponentially increase.
     */
    var DEFAULT_INTERVAL_MILLIS = 1000;
    /**
     * The factor to backoff by.
     * Should be a number greater than 1.
     */
    var DEFAULT_BACKOFF_FACTOR = 2;
    /**
     * The maximum milliseconds to increase to.
     *
     * <p>Visible for testing
     */
    var MAX_VALUE_MILLIS = 4 * 60 * 60 * 1000; // Four hours, like iOS and Android.
    /**
     * The percentage of backoff time to randomize by.
     * See
     * http://go/safe-client-behavior#step-1-determine-the-appropriate-retry-interval-to-handle-spike-traffic
     * for context.
     *
     * <p>Visible for testing
     */
    var RANDOM_FACTOR = 0.5;
    /**
     * Based on the backoff method from
     * https://github.com/google/closure-library/blob/master/closure/goog/math/exponentialbackoff.js.
     * Extracted here so we don't need to pass metadata and a stateful ExponentialBackoff object around.
     */
    function calculateBackoffMillis(backoffCount, intervalMillis, backoffFactor) {
        if (intervalMillis === void 0) { intervalMillis = DEFAULT_INTERVAL_MILLIS; }
        if (backoffFactor === void 0) { backoffFactor = DEFAULT_BACKOFF_FACTOR; }
        // Calculates an exponentially increasing value.
        // Deviation: calculates value from count and a constant interval, so we only need to save value
        // and count to restore state.
        var currBaseValue = intervalMillis * Math.pow(backoffFactor, backoffCount);
        // A random "fuzz" to avoid waves of retries.
        // Deviation: randomFactor is required.
        var randomWait = Math.round(
        // A fraction of the backoff value to add/subtract.
        // Deviation: changes multiplication order to improve readability.
        RANDOM_FACTOR *
            currBaseValue *
            // A random float (rounded to int by Math.round above) in the range [-1, 1]. Determines
            // if we add or subtract.
            (Math.random() - 0.5) *
            2);
        // Limits backoff to max to avoid effectively permanent backoff.
        return Math.min(MAX_VALUE_MILLIS, currBaseValue + randomWait);
    }

    /**
     * @license
     * Copyright 2021 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    function getModularInstance(service) {
        if (service && service._delegate) {
            return service._delegate;
        }
        else {
            return service;
        }
    }

    /**
     * Component for service name T, e.g. `auth`, `auth-internal`
     */
    var Component = /** @class */ (function () {
        /**
         *
         * @param name The public service name, e.g. app, auth, firestore, database
         * @param instanceFactory Service factory responsible for creating the public interface
         * @param type whether the service provided by the component is public or private
         */
        function Component(name, instanceFactory, type) {
            this.name = name;
            this.instanceFactory = instanceFactory;
            this.type = type;
            this.multipleInstances = false;
            /**
             * Properties to be added to the service namespace
             */
            this.serviceProps = {};
            this.instantiationMode = "LAZY" /* LAZY */;
            this.onInstanceCreated = null;
        }
        Component.prototype.setInstantiationMode = function (mode) {
            this.instantiationMode = mode;
            return this;
        };
        Component.prototype.setMultipleInstances = function (multipleInstances) {
            this.multipleInstances = multipleInstances;
            return this;
        };
        Component.prototype.setServiceProps = function (props) {
            this.serviceProps = props;
            return this;
        };
        Component.prototype.setInstanceCreatedCallback = function (callback) {
            this.onInstanceCreated = callback;
            return this;
        };
        return Component;
    }());

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    var DEFAULT_ENTRY_NAME$1 = '[DEFAULT]';

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Provider for instance for service name T, e.g. 'auth', 'auth-internal'
     * NameServiceMapping[T] is an alias for the type of the instance
     */
    var Provider = /** @class */ (function () {
        function Provider(name, container) {
            this.name = name;
            this.container = container;
            this.component = null;
            this.instances = new Map();
            this.instancesDeferred = new Map();
            this.onInitCallbacks = new Map();
        }
        /**
         * @param identifier A provider can provide mulitple instances of a service
         * if this.component.multipleInstances is true.
         */
        Provider.prototype.get = function (identifier) {
            // if multipleInstances is not supported, use the default name
            var normalizedIdentifier = this.normalizeInstanceIdentifier(identifier);
            if (!this.instancesDeferred.has(normalizedIdentifier)) {
                var deferred = new Deferred();
                this.instancesDeferred.set(normalizedIdentifier, deferred);
                if (this.isInitialized(normalizedIdentifier) ||
                    this.shouldAutoInitialize()) {
                    // initialize the service if it can be auto-initialized
                    try {
                        var instance = this.getOrInitializeService({
                            instanceIdentifier: normalizedIdentifier
                        });
                        if (instance) {
                            deferred.resolve(instance);
                        }
                    }
                    catch (e) {
                        // when the instance factory throws an exception during get(), it should not cause
                        // a fatal error. We just return the unresolved promise in this case.
                    }
                }
            }
            return this.instancesDeferred.get(normalizedIdentifier).promise;
        };
        Provider.prototype.getImmediate = function (options) {
            var _a;
            // if multipleInstances is not supported, use the default name
            var normalizedIdentifier = this.normalizeInstanceIdentifier(options === null || options === void 0 ? void 0 : options.identifier);
            var optional = (_a = options === null || options === void 0 ? void 0 : options.optional) !== null && _a !== void 0 ? _a : false;
            if (this.isInitialized(normalizedIdentifier) ||
                this.shouldAutoInitialize()) {
                try {
                    return this.getOrInitializeService({
                        instanceIdentifier: normalizedIdentifier
                    });
                }
                catch (e) {
                    if (optional) {
                        return null;
                    }
                    else {
                        throw e;
                    }
                }
            }
            else {
                // In case a component is not initialized and should/can not be auto-initialized at the moment, return null if the optional flag is set, or throw
                if (optional) {
                    return null;
                }
                else {
                    throw Error("Service " + this.name + " is not available");
                }
            }
        };
        Provider.prototype.getComponent = function () {
            return this.component;
        };
        Provider.prototype.setComponent = function (component) {
            var e_1, _a;
            if (component.name !== this.name) {
                throw Error("Mismatching Component " + component.name + " for Provider " + this.name + ".");
            }
            if (this.component) {
                throw Error("Component for " + this.name + " has already been provided");
            }
            this.component = component;
            // return early without attempting to initialize the component if the component requires explicit initialization (calling `Provider.initialize()`)
            if (!this.shouldAutoInitialize()) {
                return;
            }
            // if the service is eager, initialize the default instance
            if (isComponentEager(component)) {
                try {
                    this.getOrInitializeService({ instanceIdentifier: DEFAULT_ENTRY_NAME$1 });
                }
                catch (e) {
                    // when the instance factory for an eager Component throws an exception during the eager
                    // initialization, it should not cause a fatal error.
                    // TODO: Investigate if we need to make it configurable, because some component may want to cause
                    // a fatal error in this case?
                }
            }
            try {
                // Create service instances for the pending promises and resolve them
                // NOTE: if this.multipleInstances is false, only the default instance will be created
                // and all promises with resolve with it regardless of the identifier.
                for (var _b = __values(this.instancesDeferred.entries()), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var _d = __read(_c.value, 2), instanceIdentifier = _d[0], instanceDeferred = _d[1];
                    var normalizedIdentifier = this.normalizeInstanceIdentifier(instanceIdentifier);
                    try {
                        // `getOrInitializeService()` should always return a valid instance since a component is guaranteed. use ! to make typescript happy.
                        var instance = this.getOrInitializeService({
                            instanceIdentifier: normalizedIdentifier
                        });
                        instanceDeferred.resolve(instance);
                    }
                    catch (e) {
                        // when the instance factory throws an exception, it should not cause
                        // a fatal error. We just leave the promise unresolved.
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
        };
        Provider.prototype.clearInstance = function (identifier) {
            if (identifier === void 0) { identifier = DEFAULT_ENTRY_NAME$1; }
            this.instancesDeferred.delete(identifier);
            this.instances.delete(identifier);
        };
        // app.delete() will call this method on every provider to delete the services
        // TODO: should we mark the provider as deleted?
        Provider.prototype.delete = function () {
            return __awaiter(this, void 0, void 0, function () {
                var services;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            services = Array.from(this.instances.values());
                            return [4 /*yield*/, Promise.all(__spreadArray(__spreadArray([], __read(services
                                    .filter(function (service) { return 'INTERNAL' in service; }) // legacy services
                                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                                    .map(function (service) { return service.INTERNAL.delete(); }))), __read(services
                                    .filter(function (service) { return '_delete' in service; }) // modularized services
                                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                                    .map(function (service) { return service._delete(); }))))];
                        case 1:
                            _a.sent();
                            return [2 /*return*/];
                    }
                });
            });
        };
        Provider.prototype.isComponentSet = function () {
            return this.component != null;
        };
        Provider.prototype.isInitialized = function (identifier) {
            if (identifier === void 0) { identifier = DEFAULT_ENTRY_NAME$1; }
            return this.instances.has(identifier);
        };
        Provider.prototype.initialize = function (opts) {
            var e_2, _a;
            if (opts === void 0) { opts = {}; }
            var _b = opts.options, options = _b === void 0 ? {} : _b;
            var normalizedIdentifier = this.normalizeInstanceIdentifier(opts.instanceIdentifier);
            if (this.isInitialized(normalizedIdentifier)) {
                throw Error(this.name + "(" + normalizedIdentifier + ") has already been initialized");
            }
            if (!this.isComponentSet()) {
                throw Error("Component " + this.name + " has not been registered yet");
            }
            var instance = this.getOrInitializeService({
                instanceIdentifier: normalizedIdentifier,
                options: options
            });
            try {
                // resolve any pending promise waiting for the service instance
                for (var _c = __values(this.instancesDeferred.entries()), _d = _c.next(); !_d.done; _d = _c.next()) {
                    var _e = __read(_d.value, 2), instanceIdentifier = _e[0], instanceDeferred = _e[1];
                    var normalizedDeferredIdentifier = this.normalizeInstanceIdentifier(instanceIdentifier);
                    if (normalizedIdentifier === normalizedDeferredIdentifier) {
                        instanceDeferred.resolve(instance);
                    }
                }
            }
            catch (e_2_1) { e_2 = { error: e_2_1 }; }
            finally {
                try {
                    if (_d && !_d.done && (_a = _c.return)) _a.call(_c);
                }
                finally { if (e_2) throw e_2.error; }
            }
            return instance;
        };
        /**
         *
         * @param callback - a function that will be invoked  after the provider has been initialized by calling provider.initialize().
         * The function is invoked SYNCHRONOUSLY, so it should not execute any longrunning tasks in order to not block the program.
         *
         * @param identifier An optional instance identifier
         * @returns a function to unregister the callback
         */
        Provider.prototype.onInit = function (callback, identifier) {
            var _a;
            var normalizedIdentifier = this.normalizeInstanceIdentifier(identifier);
            var existingCallbacks = (_a = this.onInitCallbacks.get(normalizedIdentifier)) !== null && _a !== void 0 ? _a : new Set();
            existingCallbacks.add(callback);
            this.onInitCallbacks.set(normalizedIdentifier, existingCallbacks);
            var existingInstance = this.instances.get(normalizedIdentifier);
            if (existingInstance) {
                callback(existingInstance, normalizedIdentifier);
            }
            return function () {
                existingCallbacks.delete(callback);
            };
        };
        /**
         * Invoke onInit callbacks synchronously
         * @param instance the service instance`
         */
        Provider.prototype.invokeOnInitCallbacks = function (instance, identifier) {
            var e_3, _a;
            var callbacks = this.onInitCallbacks.get(identifier);
            if (!callbacks) {
                return;
            }
            try {
                for (var callbacks_1 = __values(callbacks), callbacks_1_1 = callbacks_1.next(); !callbacks_1_1.done; callbacks_1_1 = callbacks_1.next()) {
                    var callback = callbacks_1_1.value;
                    try {
                        callback(instance, identifier);
                    }
                    catch (_b) {
                        // ignore errors in the onInit callback
                    }
                }
            }
            catch (e_3_1) { e_3 = { error: e_3_1 }; }
            finally {
                try {
                    if (callbacks_1_1 && !callbacks_1_1.done && (_a = callbacks_1.return)) _a.call(callbacks_1);
                }
                finally { if (e_3) throw e_3.error; }
            }
        };
        Provider.prototype.getOrInitializeService = function (_a) {
            var instanceIdentifier = _a.instanceIdentifier, _b = _a.options, options = _b === void 0 ? {} : _b;
            var instance = this.instances.get(instanceIdentifier);
            if (!instance && this.component) {
                instance = this.component.instanceFactory(this.container, {
                    instanceIdentifier: normalizeIdentifierForFactory(instanceIdentifier),
                    options: options
                });
                this.instances.set(instanceIdentifier, instance);
                /**
                 * Invoke onInit listeners.
                 * Note this.component.onInstanceCreated is different, which is used by the component creator,
                 * while onInit listeners are registered by consumers of the provider.
                 */
                this.invokeOnInitCallbacks(instance, instanceIdentifier);
                /**
                 * Order is important
                 * onInstanceCreated() should be called after this.instances.set(instanceIdentifier, instance); which
                 * makes `isInitialized()` return true.
                 */
                if (this.component.onInstanceCreated) {
                    try {
                        this.component.onInstanceCreated(this.container, instanceIdentifier, instance);
                    }
                    catch (_c) {
                        // ignore errors in the onInstanceCreatedCallback
                    }
                }
            }
            return instance || null;
        };
        Provider.prototype.normalizeInstanceIdentifier = function (identifier) {
            if (identifier === void 0) { identifier = DEFAULT_ENTRY_NAME$1; }
            if (this.component) {
                return this.component.multipleInstances ? identifier : DEFAULT_ENTRY_NAME$1;
            }
            else {
                return identifier; // assume multiple instances are supported before the component is provided.
            }
        };
        Provider.prototype.shouldAutoInitialize = function () {
            return (!!this.component &&
                this.component.instantiationMode !== "EXPLICIT" /* EXPLICIT */);
        };
        return Provider;
    }());
    // undefined should be passed to the service factory for the default instance
    function normalizeIdentifierForFactory(identifier) {
        return identifier === DEFAULT_ENTRY_NAME$1 ? undefined : identifier;
    }
    function isComponentEager(component) {
        return component.instantiationMode === "EAGER" /* EAGER */;
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * ComponentContainer that provides Providers for service name T, e.g. `auth`, `auth-internal`
     */
    var ComponentContainer = /** @class */ (function () {
        function ComponentContainer(name) {
            this.name = name;
            this.providers = new Map();
        }
        /**
         *
         * @param component Component being added
         * @param overwrite When a component with the same name has already been registered,
         * if overwrite is true: overwrite the existing component with the new component and create a new
         * provider with the new component. It can be useful in tests where you want to use different mocks
         * for different tests.
         * if overwrite is false: throw an exception
         */
        ComponentContainer.prototype.addComponent = function (component) {
            var provider = this.getProvider(component.name);
            if (provider.isComponentSet()) {
                throw new Error("Component " + component.name + " has already been registered with " + this.name);
            }
            provider.setComponent(component);
        };
        ComponentContainer.prototype.addOrOverwriteComponent = function (component) {
            var provider = this.getProvider(component.name);
            if (provider.isComponentSet()) {
                // delete the existing provider from the container, so we can register the new component
                this.providers.delete(component.name);
            }
            this.addComponent(component);
        };
        /**
         * getProvider provides a type safe interface where it can only be called with a field name
         * present in NameServiceMapping interface.
         *
         * Firebase SDKs providing services should extend NameServiceMapping interface to register
         * themselves.
         */
        ComponentContainer.prototype.getProvider = function (name) {
            if (this.providers.has(name)) {
                return this.providers.get(name);
            }
            // create a Provider for a service that hasn't registered with Firebase
            var provider = new Provider(name, this);
            this.providers.set(name, provider);
            return provider;
        };
        ComponentContainer.prototype.getProviders = function () {
            return Array.from(this.providers.values());
        };
        return ComponentContainer;
    }());

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    var _a;
    /**
     * The JS SDK supports 5 log levels and also allows a user the ability to
     * silence the logs altogether.
     *
     * The order is a follows:
     * DEBUG < VERBOSE < INFO < WARN < ERROR
     *
     * All of the log types above the current log level will be captured (i.e. if
     * you set the log level to `INFO`, errors will still be logged, but `DEBUG` and
     * `VERBOSE` logs will not)
     */
    var LogLevel;
    (function (LogLevel) {
        LogLevel[LogLevel["DEBUG"] = 0] = "DEBUG";
        LogLevel[LogLevel["VERBOSE"] = 1] = "VERBOSE";
        LogLevel[LogLevel["INFO"] = 2] = "INFO";
        LogLevel[LogLevel["WARN"] = 3] = "WARN";
        LogLevel[LogLevel["ERROR"] = 4] = "ERROR";
        LogLevel[LogLevel["SILENT"] = 5] = "SILENT";
    })(LogLevel || (LogLevel = {}));
    var levelStringToEnum = {
        'debug': LogLevel.DEBUG,
        'verbose': LogLevel.VERBOSE,
        'info': LogLevel.INFO,
        'warn': LogLevel.WARN,
        'error': LogLevel.ERROR,
        'silent': LogLevel.SILENT
    };
    /**
     * The default log level
     */
    var defaultLogLevel = LogLevel.INFO;
    /**
     * By default, `console.debug` is not displayed in the developer console (in
     * chrome). To avoid forcing users to have to opt-in to these logs twice
     * (i.e. once for firebase, and once in the console), we are sending `DEBUG`
     * logs to the `console.log` function.
     */
    var ConsoleMethod = (_a = {},
        _a[LogLevel.DEBUG] = 'log',
        _a[LogLevel.VERBOSE] = 'log',
        _a[LogLevel.INFO] = 'info',
        _a[LogLevel.WARN] = 'warn',
        _a[LogLevel.ERROR] = 'error',
        _a);
    /**
     * The default log handler will forward DEBUG, VERBOSE, INFO, WARN, and ERROR
     * messages on to their corresponding console counterparts (if the log method
     * is supported by the current log level)
     */
    var defaultLogHandler = function (instance, logType) {
        var args = [];
        for (var _i = 2; _i < arguments.length; _i++) {
            args[_i - 2] = arguments[_i];
        }
        if (logType < instance.logLevel) {
            return;
        }
        var now = new Date().toISOString();
        var method = ConsoleMethod[logType];
        if (method) {
            console[method].apply(console, __spreadArrays(["[" + now + "]  " + instance.name + ":"], args));
        }
        else {
            throw new Error("Attempted to log a message with an invalid logType (value: " + logType + ")");
        }
    };
    var Logger = /** @class */ (function () {
        /**
         * Gives you an instance of a Logger to capture messages according to
         * Firebase's logging scheme.
         *
         * @param name The name that the logs will be associated with
         */
        function Logger(name) {
            this.name = name;
            /**
             * The log level of the given Logger instance.
             */
            this._logLevel = defaultLogLevel;
            /**
             * The main (internal) log handler for the Logger instance.
             * Can be set to a new function in internal package code but not by user.
             */
            this._logHandler = defaultLogHandler;
            /**
             * The optional, additional, user-defined log handler for the Logger instance.
             */
            this._userLogHandler = null;
        }
        Object.defineProperty(Logger.prototype, "logLevel", {
            get: function () {
                return this._logLevel;
            },
            set: function (val) {
                if (!(val in LogLevel)) {
                    throw new TypeError("Invalid value \"" + val + "\" assigned to `logLevel`");
                }
                this._logLevel = val;
            },
            enumerable: false,
            configurable: true
        });
        // Workaround for setter/getter having to be the same type.
        Logger.prototype.setLogLevel = function (val) {
            this._logLevel = typeof val === 'string' ? levelStringToEnum[val] : val;
        };
        Object.defineProperty(Logger.prototype, "logHandler", {
            get: function () {
                return this._logHandler;
            },
            set: function (val) {
                if (typeof val !== 'function') {
                    throw new TypeError('Value assigned to `logHandler` must be a function');
                }
                this._logHandler = val;
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(Logger.prototype, "userLogHandler", {
            get: function () {
                return this._userLogHandler;
            },
            set: function (val) {
                this._userLogHandler = val;
            },
            enumerable: false,
            configurable: true
        });
        /**
         * The functions below are all based on the `console` interface
         */
        Logger.prototype.debug = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            this._userLogHandler && this._userLogHandler.apply(this, __spreadArrays([this, LogLevel.DEBUG], args));
            this._logHandler.apply(this, __spreadArrays([this, LogLevel.DEBUG], args));
        };
        Logger.prototype.log = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            this._userLogHandler && this._userLogHandler.apply(this, __spreadArrays([this, LogLevel.VERBOSE], args));
            this._logHandler.apply(this, __spreadArrays([this, LogLevel.VERBOSE], args));
        };
        Logger.prototype.info = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            this._userLogHandler && this._userLogHandler.apply(this, __spreadArrays([this, LogLevel.INFO], args));
            this._logHandler.apply(this, __spreadArrays([this, LogLevel.INFO], args));
        };
        Logger.prototype.warn = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            this._userLogHandler && this._userLogHandler.apply(this, __spreadArrays([this, LogLevel.WARN], args));
            this._logHandler.apply(this, __spreadArrays([this, LogLevel.WARN], args));
        };
        Logger.prototype.error = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            this._userLogHandler && this._userLogHandler.apply(this, __spreadArrays([this, LogLevel.ERROR], args));
            this._logHandler.apply(this, __spreadArrays([this, LogLevel.ERROR], args));
        };
        return Logger;
    }());

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    class PlatformLoggerServiceImpl {
        constructor(container) {
            this.container = container;
        }
        // In initial implementation, this will be called by installations on
        // auth token refresh, and installations will send this string.
        getPlatformInfoString() {
            const providers = this.container.getProviders();
            // Loop through providers and get library/version pairs from any that are
            // version components.
            return providers
                .map(provider => {
                if (isVersionServiceProvider(provider)) {
                    const service = provider.getImmediate();
                    return `${service.library}/${service.version}`;
                }
                else {
                    return null;
                }
            })
                .filter(logString => logString)
                .join(' ');
        }
    }
    /**
     *
     * @param provider check if this provider provides a VersionService
     *
     * NOTE: Using Provider<'app-version'> is a hack to indicate that the provider
     * provides VersionService. The provider is not necessarily a 'app-version'
     * provider.
     */
    function isVersionServiceProvider(provider) {
        const component = provider.getComponent();
        return (component === null || component === void 0 ? void 0 : component.type) === "VERSION" /* VERSION */;
    }

    const name$o = "@firebase/app-exp";
    const version$1$1 = "0.0.900-exp.6ef484a04";

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const logger = new Logger('@firebase/app');

    const name$n = "@firebase/app-compat";

    const name$m = "@firebase/analytics-compat";

    const name$l = "@firebase/analytics-exp";

    const name$k = "@firebase/app-check-compat";

    const name$j = "@firebase/app-check-exp";

    const name$i = "@firebase/auth-exp";

    const name$h = "@firebase/auth-compat";

    const name$g = "@firebase/database";

    const name$f = "@firebase/database-compat";

    const name$e = "@firebase/functions-exp";

    const name$d = "@firebase/functions-compat";

    const name$c = "@firebase/installations-exp";

    const name$b = "@firebase/installations-compat";

    const name$a = "@firebase/messaging-exp";

    const name$9 = "@firebase/messaging-compat";

    const name$8 = "@firebase/performance-exp";

    const name$7 = "@firebase/performance-compat";

    const name$6 = "@firebase/remote-config-exp";

    const name$5 = "@firebase/remote-config-compat";

    const name$4 = "@firebase/storage";

    const name$3 = "@firebase/storage-compat";

    const name$2$1 = "@firebase/firestore";

    const name$1$1 = "@firebase/firestore-compat";

    const name$p = "firebase-exp";
    const version$3 = "9.0.0-beta.7";

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * The default app name
     *
     * @internal
     */
    const DEFAULT_ENTRY_NAME = '[DEFAULT]';
    const PLATFORM_LOG_STRING = {
        [name$o]: 'fire-core',
        [name$n]: 'fire-core-compat',
        [name$l]: 'fire-analytics',
        [name$m]: 'fire-analytics-compat',
        [name$j]: 'fire-app-check',
        [name$k]: 'fire-app-check-compat',
        [name$i]: 'fire-auth',
        [name$h]: 'fire-auth-compat',
        [name$g]: 'fire-rtdb',
        [name$f]: 'fire-rtdb-compat',
        [name$e]: 'fire-fn',
        [name$d]: 'fire-fn-compat',
        [name$c]: 'fire-iid',
        [name$b]: 'fire-iid-compat',
        [name$a]: 'fire-fcm',
        [name$9]: 'fire-fcm-compat',
        [name$8]: 'fire-perf',
        [name$7]: 'fire-perf-compat',
        [name$6]: 'fire-rc',
        [name$5]: 'fire-rc-compat',
        [name$4]: 'fire-gcs',
        [name$3]: 'fire-gcs-compat',
        [name$2$1]: 'fire-fst',
        [name$1$1]: 'fire-fst-compat',
        'fire-js': 'fire-js',
        [name$p]: 'fire-js-all'
    };

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * @internal
     */
    const _apps = new Map();
    /**
     * Registered components.
     *
     * @internal
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const _components = new Map();
    /**
     * @param component - the component being added to this app's container
     *
     * @internal
     */
    function _addComponent(app, component) {
        try {
            app.container.addComponent(component);
        }
        catch (e) {
            logger.debug(`Component ${component.name} failed to register with FirebaseApp ${app.name}`, e);
        }
    }
    /**
     *
     * @param component - the component to register
     * @returns whether or not the component is registered successfully
     *
     * @internal
     */
    function _registerComponent(component) {
        const componentName = component.name;
        if (_components.has(componentName)) {
            logger.debug(`There were multiple attempts to register component ${componentName}.`);
            return false;
        }
        _components.set(componentName, component);
        // add the component to existing app instances
        for (const app of _apps.values()) {
            _addComponent(app, component);
        }
        return true;
    }
    /**
     *
     * @param app - FirebaseApp instance
     * @param name - service name
     *
     * @returns the provider for the service with the matching name
     *
     * @internal
     */
    function _getProvider(app, name) {
        return app.container.getProvider(name);
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const ERRORS = {
        ["no-app" /* NO_APP */]: "No Firebase App '{$appName}' has been created - " +
            'call Firebase App.initializeApp()',
        ["bad-app-name" /* BAD_APP_NAME */]: "Illegal App name: '{$appName}",
        ["duplicate-app" /* DUPLICATE_APP */]: "Firebase App named '{$appName}' already exists",
        ["app-deleted" /* APP_DELETED */]: "Firebase App named '{$appName}' already deleted",
        ["invalid-app-argument" /* INVALID_APP_ARGUMENT */]: 'firebase.{$appName}() takes either no argument or a ' +
            'Firebase App instance.',
        ["invalid-log-argument" /* INVALID_LOG_ARGUMENT */]: 'First argument to `onLog` must be null or a function.'
    };
    const ERROR_FACTORY$2 = new ErrorFactory('app', 'Firebase', ERRORS);

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    class FirebaseAppImpl {
        constructor(options, config, container) {
            this._isDeleted = false;
            this._options = Object.assign({}, options);
            this._name = config.name;
            this._automaticDataCollectionEnabled =
                config.automaticDataCollectionEnabled;
            this._container = container;
            this.container.addComponent(new Component('app-exp', () => this, "PUBLIC" /* PUBLIC */));
        }
        get automaticDataCollectionEnabled() {
            this.checkDestroyed();
            return this._automaticDataCollectionEnabled;
        }
        set automaticDataCollectionEnabled(val) {
            this.checkDestroyed();
            this._automaticDataCollectionEnabled = val;
        }
        get name() {
            this.checkDestroyed();
            return this._name;
        }
        get options() {
            this.checkDestroyed();
            return this._options;
        }
        get container() {
            return this._container;
        }
        get isDeleted() {
            return this._isDeleted;
        }
        set isDeleted(val) {
            this._isDeleted = val;
        }
        /**
         * This function will throw an Error if the App has already been deleted -
         * use before performing API actions on the App.
         */
        checkDestroyed() {
            if (this.isDeleted) {
                throw ERROR_FACTORY$2.create("app-deleted" /* APP_DELETED */, { appName: this._name });
            }
        }
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * The current SDK version.
     *
     * @public
     */
    const SDK_VERSION = version$3;
    function initializeApp(options, rawConfig = {}) {
        if (typeof rawConfig !== 'object') {
            const name = rawConfig;
            rawConfig = { name };
        }
        const config = Object.assign({ name: DEFAULT_ENTRY_NAME, automaticDataCollectionEnabled: false }, rawConfig);
        const name = config.name;
        if (typeof name !== 'string' || !name) {
            throw ERROR_FACTORY$2.create("bad-app-name" /* BAD_APP_NAME */, {
                appName: String(name)
            });
        }
        if (_apps.has(name)) {
            throw ERROR_FACTORY$2.create("duplicate-app" /* DUPLICATE_APP */, { appName: name });
        }
        const container = new ComponentContainer(name);
        for (const component of _components.values()) {
            container.addComponent(component);
        }
        const newApp = new FirebaseAppImpl(options, config, container);
        _apps.set(name, newApp);
        return newApp;
    }
    /**
     * Retrieves a FirebaseApp instance.
     *
     * When called with no arguments, the default app is returned. When an app name
     * is provided, the app corresponding to that name is returned.
     *
     * An exception is thrown if the app being retrieved has not yet been
     * initialized.
     *
     * @example
     * ```javascript
     * // Return the default app
     * const app = getApp();
     * ```
     *
     * @example
     * ```javascript
     * // Return a named app
     * const otherApp = getApp("otherApp");
     * ```
     *
     * @param name - Optional name of the app to return. If no name is
     *   provided, the default is `"[DEFAULT]"`.
     *
     * @returns The app corresponding to the provided app name.
     *   If no app name is provided, the default app is returned.
     *
     * @public
     */
    function getApp(name = DEFAULT_ENTRY_NAME) {
        const app = _apps.get(name);
        if (!app) {
            throw ERROR_FACTORY$2.create("no-app" /* NO_APP */, { appName: name });
        }
        return app;
    }
    /**
     * Registers a library's name and version for platform logging purposes.
     * @param library - Name of 1p or 3p library (e.g. firestore, angularfire)
     * @param version - Current version of that library.
     * @param variant - Bundle variant, e.g., node, rn, etc.
     *
     * @public
     */
    function registerVersion(libraryKeyOrName, version, variant) {
        var _a;
        // TODO: We can use this check to whitelist strings when/if we set up
        // a good whitelist system.
        let library = (_a = PLATFORM_LOG_STRING[libraryKeyOrName]) !== null && _a !== void 0 ? _a : libraryKeyOrName;
        if (variant) {
            library += `-${variant}`;
        }
        const libraryMismatch = library.match(/\s|\//);
        const versionMismatch = version.match(/\s|\//);
        if (libraryMismatch || versionMismatch) {
            const warning = [
                `Unable to register library "${library}" with version "${version}":`
            ];
            if (libraryMismatch) {
                warning.push(`library name "${library}" contains illegal characters (whitespace or "/")`);
            }
            if (libraryMismatch && versionMismatch) {
                warning.push('and');
            }
            if (versionMismatch) {
                warning.push(`version name "${version}" contains illegal characters (whitespace or "/")`);
            }
            logger.warn(warning.join(' '));
            return;
        }
        _registerComponent(new Component(`${library}-version`, () => ({ library, version }), "VERSION" /* VERSION */));
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    function registerCoreComponents(variant) {
        _registerComponent(new Component('platform-logger', container => new PlatformLoggerServiceImpl(container), "PRIVATE" /* PRIVATE */));
        // Register `app` package.
        registerVersion(name$o, version$1$1, variant);
        // Register platform SDK identifier (no version).
        registerVersion('fire-js', '');
    }

    /**
     * Firebase App
     *
     * @remarks This package coordinates the communication between the different Firebase components
     * @packageDocumentation
     */
    registerCoreComponents();

    var name$2 = "firebase-exp";
    var version$2 = "9.0.0-beta.7";

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    registerVersion(name$2, version$2, 'app');

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    let l$2 = "8.7.1";

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Simple wrapper around a nullable UID. Mostly exists to make code more
     * readable.
     */
    class f$2 {
        constructor(t) {
            this.uid = t;
        }
        isAuthenticated() {
            return null != this.uid;
        }
        /**
         * Returns a key representing this user, suitable for inclusion in a
         * dictionary.
         */    toKey() {
            return this.isAuthenticated() ? "uid:" + this.uid : "anonymous-user";
        }
        isEqual(t) {
            return t.uid === this.uid;
        }
    }

    /** A user with a null UID. */ f$2.UNAUTHENTICATED = new f$2(null), 
    // TODO(mikelehen): Look into getting a proper uid-equivalent for
    // non-FirebaseAuth providers.
    f$2.GOOGLE_CREDENTIALS = new f$2("google-credentials-uid"), f$2.FIRST_PARTY = new f$2("first-party-uid");

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const d$2 = new Logger("@firebase/firestore");

    function m$2(t, ...e) {
        if (d$2.logLevel <= LogLevel.DEBUG) {
            const n = e.map(_$1);
            d$2.debug(`Firestore (${l$2}): ${t}`, ...n);
        }
    }

    function p$2(t, ...e) {
        if (d$2.logLevel <= LogLevel.ERROR) {
            const n = e.map(_$1);
            d$2.error(`Firestore (${l$2}): ${t}`, ...n);
        }
    }

    function y$2(t, ...e) {
        if (d$2.logLevel <= LogLevel.WARN) {
            const n = e.map(_$1);
            d$2.warn(`Firestore (${l$2}): ${t}`, ...n);
        }
    }

    /**
     * Converts an additional log parameter to a string representation.
     */ function _$1(t) {
        if ("string" == typeof t) return t;
        try {
            return e = t, JSON.stringify(e);
        } catch (e) {
            // Converting to JSON failed, just log the object directly
            return t;
        }
        /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
        /** Formats an object as a JSON string, suitable for logging. */
        var e;
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Unconditionally fails, throwing an Error with the given message.
     * Messages are stripped in production builds.
     *
     * Returns `never` and can be used in expressions:
     * @example
     * let futureVar = fail('not implemented yet');
     */ function g$3(t = "Unexpected state") {
        // Log the failure in addition to throw an exception, just in case the
        // exception is swallowed.
        const e = `FIRESTORE (${l$2}) INTERNAL ASSERTION FAILED: ` + t;
        // NOTE: We don't use FirestoreError here because these are internal failures
        // that cannot be handled by the user. (Also it would create a circular
        // dependency between the error and assert modules which doesn't work.)
        throw p$2(e), new Error(e);
    }

    /**
     * Fails if the given assertion condition is false, throwing an Error with the
     * given message if it did.
     *
     * Messages are stripped in production builds.
     */ function b$2(t, e) {
        t || g$3();
    }

    /**
     * Casts `obj` to `T`. In non-production builds, verifies that `obj` is an
     * instance of `T` before casting.
     */ function v$2(t, 
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    e) {
        return t;
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */ const E$2 = "ok", T$3 = "cancelled", I$2 = "unknown", A$3 = "invalid-argument", P$2 = "deadline-exceeded", R$2 = "not-found", N$2 = "permission-denied", D$2 = "unauthenticated", $$3 = "resource-exhausted", F$3 = "failed-precondition", S$2 = "aborted", x$3 = "out-of-range", q$2 = "unimplemented", O$2 = "internal", C$2 = "unavailable";

    /** An error returned by a Firestore operation. */ class U$2 extends Error {
        /** @hideconstructor */
        constructor(
        /**
         * The backend error code associated with this error.
         */
        t, 
        /**
         * A custom error description.
         */
        e) {
            super(e), this.code = t, this.message = e, 
            /** The custom name for all FirestoreErrors. */
            this.name = "FirebaseError", 
            // HACK: We write a toString property directly because Error is not a real
            // class and so inheritance does not work correctly. We could alternatively
            // do the same "back-door inheritance" trick that FirebaseError does.
            this.toString = () => `${this.name}: [code=${this.code}]: ${this.message}`;
        }
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */ class j$3 {
        constructor() {
            this.promise = new Promise(((t, e) => {
                this.resolve = t, this.reject = e;
            }));
        }
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */ class k$3 {
        constructor(t, e) {
            this.user = e, this.type = "OAuth", this.authHeaders = {}, 
            // Set the headers using Object Literal notation to avoid minification
            this.authHeaders.Authorization = `Bearer ${t}`;
        }
    }

    /** A CredentialsProvider that always yields an empty token. */ class M$2 {
        constructor() {
            /**
             * Stores the listener registered with setChangeListener()
             * This isn't actually necessary since the UID never changes, but we use this
             * to verify the listen contract is adhered to in tests.
             */
            this.changeListener = null;
        }
        getToken() {
            return Promise.resolve(null);
        }
        invalidateToken() {}
        setChangeListener(t, e) {
            this.changeListener = e, 
            // Fire with initial user.
            t.enqueueRetryable((() => e(f$2.UNAUTHENTICATED)));
        }
        removeChangeListener() {
            this.changeListener = null;
        }
    }

    class Q$2 {
        constructor(t) {
            /** Tracks the current User. */
            this.currentUser = f$2.UNAUTHENTICATED, 
            /** Promise that allows blocking on the initialization of Firebase Auth. */
            this.t = new j$3, 
            /**
             * Counter used to detect if the token changed while a getToken request was
             * outstanding.
             */
            this.i = 0, this.forceRefresh = !1, this.auth = null, this.asyncQueue = null, this.o = () => {
                this.i++, this.currentUser = this.u(), this.t.resolve(), this.changeListener && this.asyncQueue.enqueueRetryable((() => this.changeListener(this.currentUser)));
            };
            const e = t => {
                m$2("FirebaseCredentialsProvider", "Auth detected"), this.auth = t, this.auth.addAuthTokenListener(this.o);
            };
            t.onInit((t => e(t))), 
            // Our users can initialize Auth right after Firestore, so we give it
            // a chance to register itself with the component framework before we
            // determine whether to start up in unauthenticated mode.
            setTimeout((() => {
                if (!this.auth) {
                    const n = t.getImmediate({
                        optional: !0
                    });
                    n ? e(n) : (
                    // If auth is still not available, proceed with `null` user
                    m$2("FirebaseCredentialsProvider", "Auth not yet detected"), this.t.resolve());
                }
            }), 0);
        }
        getToken() {
            // Take note of the current value of the tokenCounter so that this method
            // can fail (with an ABORTED error) if there is a token change while the
            // request is outstanding.
            const t = this.i, e = this.forceRefresh;
            return this.forceRefresh = !1, this.auth ? this.auth.getToken(e).then((e => 
            // Cancel the request since the token changed while the request was
            // outstanding so the response is potentially for a previous user (which
            // user, we can't be sure).
            this.i !== t ? (m$2("FirebaseCredentialsProvider", "getToken aborted due to token change."), 
            this.getToken()) : e ? (b$2("string" == typeof e.accessToken), new k$3(e.accessToken, this.currentUser)) : null)) : Promise.resolve(null);
        }
        invalidateToken() {
            this.forceRefresh = !0;
        }
        setChangeListener(t, e) {
            this.asyncQueue = t, 
            // Blocks the AsyncQueue until the next user is available.
            this.asyncQueue.enqueueRetryable((async () => {
                await this.t.promise, await e(this.currentUser), this.changeListener = e;
            }));
        }
        removeChangeListener() {
            this.auth && this.auth.removeAuthTokenListener(this.o), this.changeListener = () => Promise.resolve();
        }
        // Auth.getUid() can return null even with a user logged in. It is because
        // getUid() is synchronous, but the auth code populating Uid is asynchronous.
        // This method should only be called in the AuthTokenListener callback
        // to guarantee to get the actual user.
        u() {
            const t = this.auth && this.auth.getUid();
            return b$2(null === t || "string" == typeof t), new f$2(t);
        }
    }

    /*
     * FirstPartyToken provides a fresh token each time its value
     * is requested, because if the token is too old, requests will be rejected.
     * Technically this may no longer be necessary since the SDK should gracefully
     * recover from unauthenticated errors (see b/33147818 for context), but it's
     * safer to keep the implementation as-is.
     */ class z$2 {
        constructor(t, e, n) {
            this.h = t, this.l = e, this.m = n, this.type = "FirstParty", this.user = f$2.FIRST_PARTY;
        }
        get authHeaders() {
            const t = {
                "X-Goog-AuthUser": this.l
            }, e = this.h.auth.getAuthHeaderValueForFirstParty([]);
            // Use array notation to prevent minification
                    return e && (t.Authorization = e), this.m && (t["X-Goog-Iam-Authorization-Token"] = this.m), 
            t;
        }
    }

    /*
     * Provides user credentials required for the Firestore JavaScript SDK
     * to authenticate the user, using technique that is only available
     * to applications hosted by Google.
     */ class W$2 {
        constructor(t, e, n) {
            this.h = t, this.l = e, this.m = n;
        }
        getToken() {
            return Promise.resolve(new z$2(this.h, this.l, this.m));
        }
        setChangeListener(t, e) {
            // Fire with initial uid.
            t.enqueueRetryable((() => e(f$2.FIRST_PARTY)));
        }
        removeChangeListener() {}
        invalidateToken() {}
    }

    /**
     * Builds a CredentialsProvider depending on the type of
     * the credentials passed in.
     */
    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    class G$2 {
        /**
         * Constructs a DatabaseInfo using the provided host, databaseId and
         * persistenceKey.
         *
         * @param databaseId - The database to use.
         * @param appId - The Firebase App Id.
         * @param persistenceKey - A unique identifier for this Firestore's local
         * storage (used in conjunction with the databaseId).
         * @param host - The Firestore backend host to connect to.
         * @param ssl - Whether to use SSL when connecting.
         * @param forceLongPolling - Whether to use the forceLongPolling option
         * when using WebChannel as the network transport.
         * @param autoDetectLongPolling - Whether to use the detectBufferingProxy
         * option when using WebChannel as the network transport.
         * @param useFetchStreams Whether to use the Fetch API instead of
         * XMLHTTPRequest
         */
        constructor(t, e, n, r, s, i, o, u) {
            this.databaseId = t, this.appId = e, this.persistenceKey = n, this.host = r, this.ssl = s, 
            this.forceLongPolling = i, this.autoDetectLongPolling = o, this.useFetchStreams = u;
        }
    }

    /** The default database name for a project. */
    /** Represents the database ID a Firestore client is associated with. */
    class H$2 {
        constructor(t, e) {
            this.projectId = t, this.database = e || "(default)";
        }
        get isDefaultDatabase() {
            return "(default)" === this.database;
        }
        isEqual(t) {
            return t instanceof H$2 && t.projectId === this.projectId && t.database === this.database;
        }
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Path represents an ordered sequence of string segments.
     */
    class Y$2 {
        constructor(t, e, n) {
            void 0 === e ? e = 0 : e > t.length && g$3(), void 0 === n ? n = t.length - e : n > t.length - e && g$3(), 
            this.segments = t, this.offset = e, this.len = n;
        }
        get length() {
            return this.len;
        }
        isEqual(t) {
            return 0 === Y$2.comparator(this, t);
        }
        child(t) {
            const e = this.segments.slice(this.offset, this.limit());
            return t instanceof Y$2 ? t.forEach((t => {
                e.push(t);
            })) : e.push(t), this.construct(e);
        }
        /** The index of one past the last segment of the path. */    limit() {
            return this.offset + this.length;
        }
        popFirst(t) {
            return t = void 0 === t ? 1 : t, this.construct(this.segments, this.offset + t, this.length - t);
        }
        popLast() {
            return this.construct(this.segments, this.offset, this.length - 1);
        }
        firstSegment() {
            return this.segments[this.offset];
        }
        lastSegment() {
            return this.get(this.length - 1);
        }
        get(t) {
            return this.segments[this.offset + t];
        }
        isEmpty() {
            return 0 === this.length;
        }
        isPrefixOf(t) {
            if (t.length < this.length) return !1;
            for (let e = 0; e < this.length; e++) if (this.get(e) !== t.get(e)) return !1;
            return !0;
        }
        isImmediateParentOf(t) {
            if (this.length + 1 !== t.length) return !1;
            for (let e = 0; e < this.length; e++) if (this.get(e) !== t.get(e)) return !1;
            return !0;
        }
        forEach(t) {
            for (let e = this.offset, n = this.limit(); e < n; e++) t(this.segments[e]);
        }
        toArray() {
            return this.segments.slice(this.offset, this.limit());
        }
        static comparator(t, e) {
            const n = Math.min(t.length, e.length);
            for (let r = 0; r < n; r++) {
                const n = t.get(r), s = e.get(r);
                if (n < s) return -1;
                if (n > s) return 1;
            }
            return t.length < e.length ? -1 : t.length > e.length ? 1 : 0;
        }
    }

    /**
     * A slash-separated path for navigating resources (documents and collections)
     * within Firestore.
     */ class K$2 extends Y$2 {
        construct(t, e, n) {
            return new K$2(t, e, n);
        }
        canonicalString() {
            // NOTE: The client is ignorant of any path segments containing escape
            // sequences (e.g. __id123__) and just passes them through raw (they exist
            // for legacy reasons and should not be used frequently).
            return this.toArray().join("/");
        }
        toString() {
            return this.canonicalString();
        }
        /**
         * Creates a resource path from the given slash-delimited string. If multiple
         * arguments are provided, all components are combined. Leading and trailing
         * slashes from all components are ignored.
         */    static fromString(...t) {
            // NOTE: The client is ignorant of any path segments containing escape
            // sequences (e.g. __id123__) and just passes them through raw (they exist
            // for legacy reasons and should not be used frequently).
            const e = [];
            for (const n of t) {
                if (n.indexOf("//") >= 0) throw new U$2(A$3, `Invalid segment (${n}). Paths must not contain // in them.`);
                // Strip leading and traling slashed.
                            e.push(...n.split("/").filter((t => t.length > 0)));
            }
            return new K$2(e);
        }
        static emptyPath() {
            return new K$2([]);
        }
    }

    const J$2 = /^[_a-zA-Z][_a-zA-Z0-9]*$/;

    /** A dot-separated path for navigating sub-objects within a document. */ class Z$2 extends Y$2 {
        construct(t, e, n) {
            return new Z$2(t, e, n);
        }
        /**
         * Returns true if the string could be used as a segment in a field path
         * without escaping.
         */    static isValidIdentifier(t) {
            return J$2.test(t);
        }
        canonicalString() {
            return this.toArray().map((t => (t = t.replace(/\\/g, "\\\\").replace(/`/g, "\\`"), 
            Z$2.isValidIdentifier(t) || (t = "`" + t + "`"), t))).join(".");
        }
        toString() {
            return this.canonicalString();
        }
        /**
         * Returns true if this field references the key of a document.
         */    isKeyField() {
            return 1 === this.length && "__name__" === this.get(0);
        }
        /**
         * The field designating the key of a document.
         */    static keyField() {
            return new Z$2([ "__name__" ]);
        }
        /**
         * Parses a field string from the given server-formatted string.
         *
         * - Splitting the empty string is not allowed (for now at least).
         * - Empty segments within the string (e.g. if there are two consecutive
         *   separators) are not allowed.
         *
         * TODO(b/37244157): we should make this more strict. Right now, it allows
         * non-identifier path components, even if they aren't escaped.
         */    static fromServerFormat(t) {
            const e = [];
            let n = "", r = 0;
            const s = () => {
                if (0 === n.length) throw new U$2(A$3, `Invalid field path (${t}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);
                e.push(n), n = "";
            };
            let i = !1;
            for (;r < t.length; ) {
                const e = t[r];
                if ("\\" === e) {
                    if (r + 1 === t.length) throw new U$2(A$3, "Path has trailing escape character: " + t);
                    const e = t[r + 1];
                    if ("\\" !== e && "." !== e && "`" !== e) throw new U$2(A$3, "Path has invalid escape sequence: " + t);
                    n += e, r += 2;
                } else "`" === e ? (i = !i, r++) : "." !== e || i ? (n += e, r++) : (s(), r++);
            }
            if (s(), i) throw new U$2(A$3, "Unterminated ` in path: " + t);
            return new Z$2(e);
        }
        static emptyPath() {
            return new Z$2([]);
        }
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */ class X$1 {
        constructor(t) {
            this.path = t;
        }
        static fromPath(t) {
            return new X$1(K$2.fromString(t));
        }
        static fromName(t) {
            return new X$1(K$2.fromString(t).popFirst(5));
        }
        /** Returns true if the document is in the specified collectionId. */    hasCollectionId(t) {
            return this.path.length >= 2 && this.path.get(this.path.length - 2) === t;
        }
        isEqual(t) {
            return null !== t && 0 === K$2.comparator(this.path, t.path);
        }
        toString() {
            return this.path.toString();
        }
        static comparator(t, e) {
            return K$2.comparator(t.path, e.path);
        }
        static isDocumentKey(t) {
            return t.length % 2 == 0;
        }
        /**
         * Creates and returns a new document key with the given segments.
         *
         * @param segments - The segments of the path to the document
         * @returns A new instance of DocumentKey
         */    static fromSegments(t) {
            return new X$1(new K$2(t.slice()));
        }
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */ function tt(t, e, n) {
        if (!n) throw new U$2(A$3, `Function ${t}() cannot be called with an empty ${e}.`);
    }

    /**
     * Validates that two boolean options are not set at the same time.
     */
    /**
     * Validates that `path` refers to a document (indicated by the fact it contains
     * an even numbers of segments).
     */
    function et(t) {
        if (!X$1.isDocumentKey(t)) throw new U$2(A$3, `Invalid document reference. Document references must have an even number of segments, but ${t} has ${t.length}.`);
    }

    /**
     * Returns true if it's a non-null object without a custom prototype
     * (i.e. excludes Array, Date, etc.).
     */
    /** Returns a string describing the type / value of the provided input. */
    function rt(t) {
        if (void 0 === t) return "undefined";
        if (null === t) return "null";
        if ("string" == typeof t) return t.length > 20 && (t = `${t.substring(0, 20)}...`), 
        JSON.stringify(t);
        if ("number" == typeof t || "boolean" == typeof t) return "" + t;
        if ("object" == typeof t) {
            if (t instanceof Array) return "an array";
            {
                const e = 
                /** Hacky method to try to get the constructor name for an object. */
                function(t) {
                    if (t.constructor) {
                        const e = /function\s+([^\s(]+)\s*\(/.exec(t.constructor.toString());
                        if (e && e.length > 1) return e[1];
                    }
                    return null;
                }
                /**
     * Casts `obj` to `T`, optionally unwrapping Compat types to expose the
     * underlying instance. Throws if  `obj` is not an instance of `T`.
     *
     * This cast is used in the Lite and Full SDK to verify instance types for
     * arguments passed to the public API.
     */ (t);
                return e ? `a custom ${e} object` : "an object";
            }
        }
        return "function" == typeof t ? "a function" : g$3();
    }

    function st(t, 
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    e) {
        if ("_delegate" in t && (
        // Unwrap Compat types
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        t = t._delegate), !(t instanceof e)) {
            if (e.name === t.constructor.name) throw new U$2(A$3, "Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");
            {
                const n = rt(t);
                throw new U$2(A$3, `Expected type '${e.name}', but it was: ${n}`);
            }
        }
        return t;
    }

    /** Returns whether the value represents -0. */ function ut(t) {
        // Detect if the value is -0.0. Based on polyfill from
        // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
        return 0 === t && 1 / t == -1 / 0;
    }

    /**
     * Returns whether a value is an integer and in the safe integer range
     * @param value - The value to test for being an integer and in the safe range
     */
    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const ct = {
        BatchGetDocuments: "batchGet",
        Commit: "commit",
        RunQuery: "runQuery"
    };

    /**
     * Maps RPC names to the corresponding REST endpoint name.
     *
     * We use array notation to avoid mangling.
     */
    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Error Codes describing the different ways GRPC can fail. These are copied
     * directly from GRPC's sources here:
     *
     * https://github.com/grpc/grpc/blob/bceec94ea4fc5f0085d81235d8e1c06798dc341a/include/grpc%2B%2B/impl/codegen/status_code_enum.h
     *
     * Important! The names of these identifiers matter because the string forms
     * are used for reverse lookups from the webchannel stream. Do NOT change the
     * names of these identifiers or change this into a const enum.
     */
    var at, ht;

    /**
     * Converts an HTTP Status Code to the equivalent error code.
     *
     * @param status - An HTTP Status Code, like 200, 404, 503, etc.
     * @returns The equivalent Code. Unknown status codes are mapped to
     *     Code.UNKNOWN.
     */
    function lt(t) {
        if (void 0 === t) return p$2("RPC_ERROR", "HTTP error has no status"), I$2;
        // The canonical error codes for Google APIs [1] specify mapping onto HTTP
        // status codes but the mapping is not bijective. In each case of ambiguity
        // this function chooses a primary error.
        
        // [1]
        // https://github.com/googleapis/googleapis/blob/master/google/rpc/code.proto
            switch (t) {
          case 200:
            // OK
            return E$2;

          case 400:
            // Bad Request
            return F$3;

            // Other possibilities based on the forward mapping
            // return Code.INVALID_ARGUMENT;
            // return Code.OUT_OF_RANGE;
                  case 401:
            // Unauthorized
            return D$2;

          case 403:
            // Forbidden
            return N$2;

          case 404:
            // Not Found
            return R$2;

          case 409:
            // Conflict
            return S$2;

            // Other possibilities:
            // return Code.ALREADY_EXISTS;
                  case 416:
            // Range Not Satisfiable
            return x$3;

          case 429:
            // Too Many Requests
            return $$3;

          case 499:
            // Client Closed Request
            return T$3;

          case 500:
            // Internal Server Error
            return I$2;

            // Other possibilities:
            // return Code.INTERNAL;
            // return Code.DATA_LOSS;
                  case 501:
            // Unimplemented
            return q$2;

          case 503:
            // Service Unavailable
            return C$2;

          case 504:
            // Gateway Timeout
            return P$2;

          default:
            return t >= 200 && t < 300 ? E$2 : t >= 400 && t < 500 ? F$3 : t >= 500 && t < 600 ? O$2 : I$2;
        }
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * A Rest-based connection that relies on the native HTTP stack
     * (e.g. `fetch` or a polyfill).
     */ (ht = at || (at = {}))[ht.OK = 0] = "OK", ht[ht.CANCELLED = 1] = "CANCELLED", 
    ht[ht.UNKNOWN = 2] = "UNKNOWN", ht[ht.INVALID_ARGUMENT = 3] = "INVALID_ARGUMENT", 
    ht[ht.DEADLINE_EXCEEDED = 4] = "DEADLINE_EXCEEDED", ht[ht.NOT_FOUND = 5] = "NOT_FOUND", 
    ht[ht.ALREADY_EXISTS = 6] = "ALREADY_EXISTS", ht[ht.PERMISSION_DENIED = 7] = "PERMISSION_DENIED", 
    ht[ht.UNAUTHENTICATED = 16] = "UNAUTHENTICATED", ht[ht.RESOURCE_EXHAUSTED = 8] = "RESOURCE_EXHAUSTED", 
    ht[ht.FAILED_PRECONDITION = 9] = "FAILED_PRECONDITION", ht[ht.ABORTED = 10] = "ABORTED", 
    ht[ht.OUT_OF_RANGE = 11] = "OUT_OF_RANGE", ht[ht.UNIMPLEMENTED = 12] = "UNIMPLEMENTED", 
    ht[ht.INTERNAL = 13] = "INTERNAL", ht[ht.UNAVAILABLE = 14] = "UNAVAILABLE", ht[ht.DATA_LOSS = 15] = "DATA_LOSS";

    class ft extends 
    /**
     * Base class for all Rest-based connections to the backend (WebChannel and
     * HTTP).
     */
    class {
        constructor(t) {
            this.databaseInfo = t, this.databaseId = t.databaseId;
            const e = t.ssl ? "https" : "http";
            this.p = e + "://" + t.host, this.g = "projects/" + this.databaseId.projectId + "/databases/" + this.databaseId.database + "/documents";
        }
        v(t, e, n, r) {
            const s = this.T(t, e);
            m$2("RestConnection", "Sending: ", s, n);
            const i = {};
            return this.I(i, r), this.A(t, s, i, n).then((t => (m$2("RestConnection", "Received: ", t), 
            t)), (e => {
                throw y$2("RestConnection", `${t} failed with error: `, e, "url: ", s, "request:", n), 
                e;
            }));
        }
        P(t, e, n, r) {
            // The REST API automatically aggregates all of the streamed results, so we
            // can just use the normal invoke() method.
            return this.v(t, e, n, r);
        }
        /**
         * Modifies the headers for a request, adding any authorization token if
         * present and any additional headers for the request.
         */    I(t, e) {
            if (t["X-Goog-Api-Client"] = "gl-js/ fire/" + l$2, 
            // Content-Type: text/plain will avoid preflight requests which might
            // mess with CORS and redirects by proxies. If we add custom headers
            // we will need to change this code to potentially use the $httpOverwrite
            // parameter supported by ESF to avoid triggering preflight requests.
            t["Content-Type"] = "text/plain", this.databaseInfo.appId && (t["X-Firebase-GMPID"] = this.databaseInfo.appId), 
            e) for (const n in e.authHeaders) e.authHeaders.hasOwnProperty(n) && (t[n] = e.authHeaders[n]);
        }
        T(t, e) {
            const n = ct[t];
            return `${this.p}/v1/${e}:${n}`;
        }
    } {
        /**
         * @param databaseInfo - The connection info.
         * @param fetchImpl - `fetch` or a Polyfill that implements the fetch API.
         */
        constructor(t, e) {
            super(t), this.R = e;
        }
        V(t, e) {
            throw new Error("Not supported by FetchConnection");
        }
        async A(t, e, n, r) {
            const s = JSON.stringify(r);
            let i;
            try {
                i = await this.R(e, {
                    method: "POST",
                    headers: n,
                    body: s
                });
            } catch (t) {
                throw new U$2(lt(t.status), "Request failed with error: " + t.statusText);
            }
            if (!i.ok) throw new U$2(lt(i.status), "Request failed with error: " + i.statusText);
            return i.json();
        }
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /** Initializes the HTTP connection for the REST API. */
    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Generates `nBytes` of random bytes.
     *
     * If `nBytes < 0` , an error will be thrown.
     */
    function dt(t) {
        // Polyfills for IE and WebWorker by using `self` and `msCrypto` when `crypto` is not available.
        const e = 
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        "undefined" != typeof self && (self.crypto || self.msCrypto), n = new Uint8Array(t);
        if (e && "function" == typeof e.getRandomValues) e.getRandomValues(n); else 
        // Falls back to Math.random
        for (let e = 0; e < t; e++) n[e] = Math.floor(256 * Math.random());
        return n;
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */ class wt {
        static N() {
            // Alphanumeric characters
            const t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", e = Math.floor(256 / t.length) * t.length;
            // The largest byte value that is a multiple of `char.length`.
                    let n = "";
            for (;n.length < 20; ) {
                const r = dt(40);
                for (let s = 0; s < r.length; ++s) 
                // Only accept values that are [0, maxMultiple), this ensures they can
                // be evenly mapped to indices of `chars` via a modulo operation.
                n.length < 20 && r[s] < e && (n += t.charAt(r[s] % t.length));
            }
            return n;
        }
    }

    function mt(t, e) {
        return t < e ? -1 : t > e ? 1 : 0;
    }

    /** Helper to compare arrays using isEqual(). */ function pt(t, e, n) {
        return t.length === e.length && t.every(((t, r) => n(t, e[r])));
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    // The earliest date supported by Firestore timestamps (0001-01-01T00:00:00Z).
    /**
     * A `Timestamp` represents a point in time independent of any time zone or
     * calendar, represented as seconds and fractions of seconds at nanosecond
     * resolution in UTC Epoch time.
     *
     * It is encoded using the Proleptic Gregorian Calendar which extends the
     * Gregorian calendar backwards to year one. It is encoded assuming all minutes
     * are 60 seconds long, i.e. leap seconds are "smeared" so that no leap second
     * table is needed for interpretation. Range is from 0001-01-01T00:00:00Z to
     * 9999-12-31T23:59:59.999999999Z.
     *
     * For examples and further specifications, refer to the
     * {@link https://github.com/google/protobuf/blob/master/src/google/protobuf/timestamp.proto | Timestamp definition}.
     */
    class yt {
        /**
         * Creates a new timestamp.
         *
         * @param seconds - The number of seconds of UTC time since Unix epoch
         *     1970-01-01T00:00:00Z. Must be from 0001-01-01T00:00:00Z to
         *     9999-12-31T23:59:59Z inclusive.
         * @param nanoseconds - The non-negative fractions of a second at nanosecond
         *     resolution. Negative second values with fractions must still have
         *     non-negative nanoseconds values that count forward in time. Must be
         *     from 0 to 999,999,999 inclusive.
         */
        constructor(
        /**
         * The number of seconds of UTC time since Unix epoch 1970-01-01T00:00:00Z.
         */
        t, 
        /**
         * The fractions of a second at nanosecond resolution.*
         */
        e) {
            if (this.seconds = t, this.nanoseconds = e, e < 0) throw new U$2(A$3, "Timestamp nanoseconds out of range: " + e);
            if (e >= 1e9) throw new U$2(A$3, "Timestamp nanoseconds out of range: " + e);
            if (t < -62135596800) throw new U$2(A$3, "Timestamp seconds out of range: " + t);
            // This will break in the year 10,000.
                    if (t >= 253402300800) throw new U$2(A$3, "Timestamp seconds out of range: " + t);
        }
        /**
         * Creates a new timestamp with the current date, with millisecond precision.
         *
         * @returns a new timestamp representing the current date.
         */    static now() {
            return yt.fromMillis(Date.now());
        }
        /**
         * Creates a new timestamp from the given date.
         *
         * @param date - The date to initialize the `Timestamp` from.
         * @returns A new `Timestamp` representing the same point in time as the given
         *     date.
         */    static fromDate(t) {
            return yt.fromMillis(t.getTime());
        }
        /**
         * Creates a new timestamp from the given number of milliseconds.
         *
         * @param milliseconds - Number of milliseconds since Unix epoch
         *     1970-01-01T00:00:00Z.
         * @returns A new `Timestamp` representing the same point in time as the given
         *     number of milliseconds.
         */    static fromMillis(t) {
            const e = Math.floor(t / 1e3), n = Math.floor(1e6 * (t - 1e3 * e));
            return new yt(e, n);
        }
        /**
         * Converts a `Timestamp` to a JavaScript `Date` object. This conversion
         * causes a loss of precision since `Date` objects only support millisecond
         * precision.
         *
         * @returns JavaScript `Date` object representing the same point in time as
         *     this `Timestamp`, with millisecond precision.
         */    toDate() {
            return new Date(this.toMillis());
        }
        /**
         * Converts a `Timestamp` to a numeric timestamp (in milliseconds since
         * epoch). This operation causes a loss of precision.
         *
         * @returns The point in time corresponding to this timestamp, represented as
         *     the number of milliseconds since Unix epoch 1970-01-01T00:00:00Z.
         */    toMillis() {
            return 1e3 * this.seconds + this.nanoseconds / 1e6;
        }
        _compareTo(t) {
            return this.seconds === t.seconds ? mt(this.nanoseconds, t.nanoseconds) : mt(this.seconds, t.seconds);
        }
        /**
         * Returns true if this `Timestamp` is equal to the provided one.
         *
         * @param other - The `Timestamp` to compare against.
         * @returns true if this `Timestamp` is equal to the provided one.
         */    isEqual(t) {
            return t.seconds === this.seconds && t.nanoseconds === this.nanoseconds;
        }
        /** Returns a textual representation of this Timestamp. */    toString() {
            return "Timestamp(seconds=" + this.seconds + ", nanoseconds=" + this.nanoseconds + ")";
        }
        /** Returns a JSON-serializable representation of this Timestamp. */    toJSON() {
            return {
                seconds: this.seconds,
                nanoseconds: this.nanoseconds
            };
        }
        /**
         * Converts this object to a primitive string, which allows Timestamp objects
         * to be compared using the `>`, `<=`, `>=` and `>` operators.
         */    valueOf() {
            // This method returns a string of the form <seconds>.<nanoseconds> where
            // <seconds> is translated to have a non-negative value and both <seconds>
            // and <nanoseconds> are left-padded with zeroes to be a consistent length.
            // Strings with this format then have a lexiographical ordering that matches
            // the expected ordering. The <seconds> translation is done to avoid having
            // a leading negative sign (i.e. a leading '-' character) in its string
            // representation, which would affect its lexiographical ordering.
            const t = this.seconds - -62135596800;
            // Note: Up to 12 decimal digits are required to represent all valid
            // 'seconds' values.
                    return String(t).padStart(12, "0") + "." + String(this.nanoseconds).padStart(9, "0");
        }
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * A version of a document in Firestore. This corresponds to the version
     * timestamp, such as update_time or read_time.
     */ class _t {
        constructor(t) {
            this.timestamp = t;
        }
        static fromTimestamp(t) {
            return new _t(t);
        }
        static min() {
            return new _t(new yt(0, 0));
        }
        compareTo(t) {
            return this.timestamp._compareTo(t.timestamp);
        }
        isEqual(t) {
            return this.timestamp.isEqual(t.timestamp);
        }
        /** Returns a number representation of the version for use in spec tests. */    toMicroseconds() {
            // Convert to microseconds.
            return 1e6 * this.timestamp.seconds + this.timestamp.nanoseconds / 1e3;
        }
        toString() {
            return "SnapshotVersion(" + this.timestamp.toString() + ")";
        }
        toTimestamp() {
            return this.timestamp;
        }
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */ function gt(t) {
        let e = 0;
        for (const n in t) Object.prototype.hasOwnProperty.call(t, n) && e++;
        return e;
    }

    function bt(t, e) {
        for (const n in t) Object.prototype.hasOwnProperty.call(t, n) && e(n, t[n]);
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Provides a set of fields that can be used to partially patch a document.
     * FieldMask is used in conjunction with ObjectValue.
     * Examples:
     *   foo - Overwrites foo entirely with the provided value. If foo is not
     *         present in the companion ObjectValue, the field is deleted.
     *   foo.bar - Overwrites only the field bar of the object foo.
     *             If foo is not an object, foo is replaced with an object
     *             containing foo
     */
    class vt {
        constructor(t) {
            this.fields = t, 
            // TODO(dimond): validation of FieldMask
            // Sort the field mask to support `FieldMask.isEqual()` and assert below.
            t.sort(Z$2.comparator);
        }
        /**
         * Verifies that `fieldPath` is included by at least one field in this field
         * mask.
         *
         * This is an O(n) operation, where `n` is the size of the field mask.
         */    covers(t) {
            for (const e of this.fields) if (e.isPrefixOf(t)) return !0;
            return !1;
        }
        isEqual(t) {
            return pt(this.fields, t.fields, ((t, e) => t.isEqual(e)));
        }
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /** Converts a Base64 encoded string to a binary string. */
    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Immutable class that represents a "proto" byte string.
     *
     * Proto byte strings can either be Base64-encoded strings or Uint8Arrays when
     * sent on the wire. This class abstracts away this differentiation by holding
     * the proto byte string in a common class that must be converted into a string
     * before being sent as a proto.
     */
    class Et {
        constructor(t) {
            this.binaryString = t;
        }
        static fromBase64String(t) {
            const e = atob(t);
            return new Et(e);
        }
        static fromUint8Array(t) {
            const e = 
            /**
     * Helper function to convert an Uint8array to a binary string.
     */
            function(t) {
                let e = "";
                for (let n = 0; n < t.length; ++n) e += String.fromCharCode(t[n]);
                return e;
            }
            /**
     * Helper function to convert a binary string to an Uint8Array.
     */ (t);
            return new Et(e);
        }
        toBase64() {
            return t = this.binaryString, btoa(t);
            /** Converts a binary string to a Base64 encoded string. */
            var t;
        }
        toUint8Array() {
            return function(t) {
                const e = new Uint8Array(t.length);
                for (let n = 0; n < t.length; n++) e[n] = t.charCodeAt(n);
                return e;
            }
            /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
            // A RegExp matching ISO 8601 UTC timestamps with optional fraction.
            (this.binaryString);
        }
        approximateByteSize() {
            return 2 * this.binaryString.length;
        }
        compareTo(t) {
            return mt(this.binaryString, t.binaryString);
        }
        isEqual(t) {
            return this.binaryString === t.binaryString;
        }
    }

    Et.EMPTY_BYTE_STRING = new Et("");

    const Tt = new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);

    /**
     * Converts the possible Proto values for a timestamp value into a "seconds and
     * nanos" representation.
     */ function It(t) {
        // The json interface (for the browser) will return an iso timestamp string,
        // while the proto js library (for node) will return a
        // google.protobuf.Timestamp instance.
        if (b$2(!!t), "string" == typeof t) {
            // The date string can have higher precision (nanos) than the Date class
            // (millis), so we do some custom parsing here.
            // Parse the nanos right out of the string.
            let e = 0;
            const n = Tt.exec(t);
            if (b$2(!!n), n[1]) {
                // Pad the fraction out to 9 digits (nanos).
                let t = n[1];
                t = (t + "000000000").substr(0, 9), e = Number(t);
            }
            // Parse the date to get the seconds.
                    const r = new Date(t);
            return {
                seconds: Math.floor(r.getTime() / 1e3),
                nanos: e
            };
        }
        return {
            seconds: At(t.seconds),
            nanos: At(t.nanos)
        };
    }

    /**
     * Converts the possible Proto types for numbers into a JavaScript number.
     * Returns 0 if the value is not numeric.
     */ function At(t) {
        // TODO(bjornick): Handle int64 greater than 53 bits.
        return "number" == typeof t ? t : "string" == typeof t ? Number(t) : 0;
    }

    /** Converts the possible Proto types for Blobs into a ByteString. */ function Pt(t) {
        return "string" == typeof t ? Et.fromBase64String(t) : Et.fromUint8Array(t);
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Represents a locally-applied ServerTimestamp.
     *
     * Server Timestamps are backed by MapValues that contain an internal field
     * `__type__` with a value of `server_timestamp`. The previous value and local
     * write time are stored in its `__previous_value__` and `__local_write_time__`
     * fields respectively.
     *
     * Notes:
     * - ServerTimestampValue instances are created as the result of applying a
     *   transform. They can only exist in the local view of a document. Therefore
     *   they do not need to be parsed or serialized.
     * - When evaluated locally (e.g. for snapshot.data()), they by default
     *   evaluate to `null`. This behavior can be configured by passing custom
     *   FieldValueOptions to value().
     * - With respect to other ServerTimestampValues, they sort by their
     *   localWriteTime.
     */ function Rt(t) {
        var e, n;
        return "server_timestamp" === (null === (n = ((null === (e = null == t ? void 0 : t.mapValue) || void 0 === e ? void 0 : e.fields) || {}).__type__) || void 0 === n ? void 0 : n.stringValue);
    }

    /**
     * Returns the value of the field before this ServerTimestamp was set.
     *
     * Preserving the previous values allows the user to display the last resoled
     * value until the backend responds with the timestamp.
     */ function Vt(t) {
        const e = t.mapValue.fields.__previous_value__;
        return Rt(e) ? Vt(e) : e;
    }

    /**
     * Returns the local time at which this timestamp was first set.
     */ function Nt(t) {
        const e = It(t.mapValue.fields.__local_write_time__.timestampValue);
        return new yt(e.seconds, e.nanos);
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /** Extracts the backend's type order for the provided value. */ function Dt(t) {
        return "nullValue" in t ? 0 /* NullValue */ : "booleanValue" in t ? 1 /* BooleanValue */ : "integerValue" in t || "doubleValue" in t ? 2 /* NumberValue */ : "timestampValue" in t ? 3 /* TimestampValue */ : "stringValue" in t ? 5 /* StringValue */ : "bytesValue" in t ? 6 /* BlobValue */ : "referenceValue" in t ? 7 /* RefValue */ : "geoPointValue" in t ? 8 /* GeoPointValue */ : "arrayValue" in t ? 9 /* ArrayValue */ : "mapValue" in t ? Rt(t) ? 4 /* ServerTimestampValue */ : 10 /* ObjectValue */ : g$3();
    }

    /** Tests `left` and `right` for equality based on the backend semantics. */ function $t(t, e) {
        const n = Dt(t);
        if (n !== Dt(e)) return !1;
        switch (n) {
          case 0 /* NullValue */ :
            return !0;

          case 1 /* BooleanValue */ :
            return t.booleanValue === e.booleanValue;

          case 4 /* ServerTimestampValue */ :
            return Nt(t).isEqual(Nt(e));

          case 3 /* TimestampValue */ :
            return function(t, e) {
                if ("string" == typeof t.timestampValue && "string" == typeof e.timestampValue && t.timestampValue.length === e.timestampValue.length) 
                // Use string equality for ISO 8601 timestamps
                return t.timestampValue === e.timestampValue;
                const n = It(t.timestampValue), r = It(e.timestampValue);
                return n.seconds === r.seconds && n.nanos === r.nanos;
            }(t, e);

          case 5 /* StringValue */ :
            return t.stringValue === e.stringValue;

          case 6 /* BlobValue */ :
            return function(t, e) {
                return Pt(t.bytesValue).isEqual(Pt(e.bytesValue));
            }(t, e);

          case 7 /* RefValue */ :
            return t.referenceValue === e.referenceValue;

          case 8 /* GeoPointValue */ :
            return function(t, e) {
                return At(t.geoPointValue.latitude) === At(e.geoPointValue.latitude) && At(t.geoPointValue.longitude) === At(e.geoPointValue.longitude);
            }(t, e);

          case 2 /* NumberValue */ :
            return function(t, e) {
                if ("integerValue" in t && "integerValue" in e) return At(t.integerValue) === At(e.integerValue);
                if ("doubleValue" in t && "doubleValue" in e) {
                    const n = At(t.doubleValue), r = At(e.doubleValue);
                    return n === r ? ut(n) === ut(r) : isNaN(n) && isNaN(r);
                }
                return !1;
            }(t, e);

          case 9 /* ArrayValue */ :
            return pt(t.arrayValue.values || [], e.arrayValue.values || [], $t);

          case 10 /* ObjectValue */ :
            return function(t, e) {
                const n = t.mapValue.fields || {}, r = e.mapValue.fields || {};
                if (gt(n) !== gt(r)) return !1;
                for (const t in n) if (n.hasOwnProperty(t) && (void 0 === r[t] || !$t(n[t], r[t]))) return !1;
                return !0;
            }
            /** Returns true if the ArrayValue contains the specified element. */ (t, e);

          default:
            return g$3();
        }
    }

    /** Returns true if `value` is a MapValue. */ function Ut(t) {
        return !!t && "mapValue" in t;
    }

    /** Creates a deep copy of `source`. */ function jt(t) {
        if (t.geoPointValue) return {
            geoPointValue: Object.assign({}, t.geoPointValue)
        };
        if (t.timestampValue && "object" == typeof t.timestampValue) return {
            timestampValue: Object.assign({}, t.timestampValue)
        };
        if (t.mapValue) {
            const e = {
                mapValue: {
                    fields: {}
                }
            };
            return bt(t.mapValue.fields, ((t, n) => e.mapValue.fields[t] = jt(n))), e;
        }
        if (t.arrayValue) {
            const e = {
                arrayValue: {
                    values: []
                }
            };
            for (let n = 0; n < (t.arrayValue.values || []).length; ++n) e.arrayValue.values[n] = jt(t.arrayValue.values[n]);
            return e;
        }
        return Object.assign({}, t);
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * An ObjectValue represents a MapValue in the Firestore Proto and offers the
     * ability to add and remove fields (via the ObjectValueBuilder).
     */ class kt {
        constructor(t) {
            this.value = t;
        }
        static empty() {
            return new kt({
                mapValue: {}
            });
        }
        /**
         * Returns the value at the given path or null.
         *
         * @param path - the path to search
         * @returns The value at the path or null if the path is not set.
         */    field(t) {
            if (t.isEmpty()) return this.value;
            {
                let e = this.value;
                for (let n = 0; n < t.length - 1; ++n) if (e = (e.mapValue.fields || {})[t.get(n)], 
                !Ut(e)) return null;
                return e = (e.mapValue.fields || {})[t.lastSegment()], e || null;
            }
        }
        /**
         * Sets the field to the provided value.
         *
         * @param path - The field path to set.
         * @param value - The value to set.
         */    set(t, e) {
            this.getFieldsMap(t.popLast())[t.lastSegment()] = jt(e);
        }
        /**
         * Sets the provided fields to the provided values.
         *
         * @param data - A map of fields to values (or null for deletes).
         */    setAll(t) {
            let e = Z$2.emptyPath(), n = {}, r = [];
            t.forEach(((t, s) => {
                if (!e.isImmediateParentOf(s)) {
                    // Insert the accumulated changes at this parent location
                    const t = this.getFieldsMap(e);
                    this.applyChanges(t, n, r), n = {}, r = [], e = s.popLast();
                }
                t ? n[s.lastSegment()] = jt(t) : r.push(s.lastSegment());
            }));
            const s = this.getFieldsMap(e);
            this.applyChanges(s, n, r);
        }
        /**
         * Removes the field at the specified path. If there is no field at the
         * specified path, nothing is changed.
         *
         * @param path - The field path to remove.
         */    delete(t) {
            const e = this.field(t.popLast());
            Ut(e) && e.mapValue.fields && delete e.mapValue.fields[t.lastSegment()];
        }
        isEqual(t) {
            return $t(this.value, t.value);
        }
        /**
         * Returns the map that contains the leaf element of `path`. If the parent
         * entry does not yet exist, or if it is not a map, a new map will be created.
         */    getFieldsMap(t) {
            let e = this.value;
            e.mapValue.fields || (e.mapValue = {
                fields: {}
            });
            for (let n = 0; n < t.length; ++n) {
                let r = e.mapValue.fields[t.get(n)];
                Ut(r) && r.mapValue.fields || (r = {
                    mapValue: {
                        fields: {}
                    }
                }, e.mapValue.fields[t.get(n)] = r), e = r;
            }
            return e.mapValue.fields;
        }
        /**
         * Modifies `fieldsMap` by adding, replacing or deleting the specified
         * entries.
         */    applyChanges(t, e, n) {
            bt(e, ((e, n) => t[e] = n));
            for (const e of n) delete t[e];
        }
        clone() {
            return new kt(jt(this.value));
        }
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Represents a document in Firestore with a key, version, data and whether it
     * has local mutations applied to it.
     *
     * Documents can transition between states via `convertToFoundDocument()`,
     * `convertToNoDocument()` and `convertToUnknownDocument()`. If a document does
     * not transition to one of these states even after all mutations have been
     * applied, `isValidDocument()` returns false and the document should be removed
     * from all views.
     */ class Mt {
        constructor(t, e, n, r, s) {
            this.key = t, this.documentType = e, this.version = n, this.data = r, this.documentState = s;
        }
        /**
         * Creates a document with no known version or data, but which can serve as
         * base document for mutations.
         */    static newInvalidDocument(t) {
            return new Mt(t, 0 /* INVALID */ , _t.min(), kt.empty(), 0 /* SYNCED */);
        }
        /**
         * Creates a new document that is known to exist with the given data at the
         * given version.
         */    static newFoundDocument(t, e, n) {
            return new Mt(t, 1 /* FOUND_DOCUMENT */ , e, n, 0 /* SYNCED */);
        }
        /** Creates a new document that is known to not exist at the given version. */    static newNoDocument(t, e) {
            return new Mt(t, 2 /* NO_DOCUMENT */ , e, kt.empty(), 0 /* SYNCED */);
        }
        /**
         * Creates a new document that is known to exist at the given version but
         * whose data is not known (e.g. a document that was updated without a known
         * base document).
         */    static newUnknownDocument(t, e) {
            return new Mt(t, 3 /* UNKNOWN_DOCUMENT */ , e, kt.empty(), 2 /* HAS_COMMITTED_MUTATIONS */);
        }
        /**
         * Changes the document type to indicate that it exists and that its version
         * and data are known.
         */    convertToFoundDocument(t, e) {
            return this.version = t, this.documentType = 1 /* FOUND_DOCUMENT */ , this.data = e, 
            this.documentState = 0 /* SYNCED */ , this;
        }
        /**
         * Changes the document type to indicate that it doesn't exist at the given
         * version.
         */    convertToNoDocument(t) {
            return this.version = t, this.documentType = 2 /* NO_DOCUMENT */ , this.data = kt.empty(), 
            this.documentState = 0 /* SYNCED */ , this;
        }
        /**
         * Changes the document type to indicate that it exists at a given version but
         * that its data is not known (e.g. a document that was updated without a known
         * base document).
         */    convertToUnknownDocument(t) {
            return this.version = t, this.documentType = 3 /* UNKNOWN_DOCUMENT */ , this.data = kt.empty(), 
            this.documentState = 2 /* HAS_COMMITTED_MUTATIONS */ , this;
        }
        setHasCommittedMutations() {
            return this.documentState = 2 /* HAS_COMMITTED_MUTATIONS */ , this;
        }
        setHasLocalMutations() {
            return this.documentState = 1 /* HAS_LOCAL_MUTATIONS */ , this;
        }
        get hasLocalMutations() {
            return 1 /* HAS_LOCAL_MUTATIONS */ === this.documentState;
        }
        get hasCommittedMutations() {
            return 2 /* HAS_COMMITTED_MUTATIONS */ === this.documentState;
        }
        get hasPendingWrites() {
            return this.hasLocalMutations || this.hasCommittedMutations;
        }
        isValidDocument() {
            return 0 /* INVALID */ !== this.documentType;
        }
        isFoundDocument() {
            return 1 /* FOUND_DOCUMENT */ === this.documentType;
        }
        isNoDocument() {
            return 2 /* NO_DOCUMENT */ === this.documentType;
        }
        isUnknownDocument() {
            return 3 /* UNKNOWN_DOCUMENT */ === this.documentType;
        }
        isEqual(t) {
            return t instanceof Mt && this.key.isEqual(t.key) && this.version.isEqual(t.version) && this.documentType === t.documentType && this.documentState === t.documentState && this.data.isEqual(t.data);
        }
        clone() {
            return new Mt(this.key, this.documentType, this.version, this.data.clone(), this.documentState);
        }
        toString() {
            return `Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`;
        }
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Query encapsulates all the query attributes we support in the SDK. It can
     * be run against the LocalStore, as well as be converted to a `Target` to
     * query the RemoteStore results.
     *
     * Visible for testing.
     */ class se {
        /**
         * Initializes a Query with a path and optional additional query constraints.
         * Path must currently be empty if this is a collection group query.
         */
        constructor(t, e = null, n = [], r = [], s = null, i = "F" /* First */ , o = null, u = null) {
            this.path = t, this.collectionGroup = e, this.explicitOrderBy = n, this.filters = r, 
            this.limit = s, this.limitType = i, this.startAt = o, this.endAt = u, this.q = null, 
            // The corresponding `Target` of this `Query` instance.
            this.O = null, this.startAt, this.endAt;
        }
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Returns an DoubleValue for `value` that is encoded based the serializer's
     * `useProto3Json` setting.
     */
    /**
     * Returns a value for a number that's appropriate to put into a proto.
     * The return value is an IntegerValue if it can safely represent the value,
     * otherwise a DoubleValue is returned.
     */
    function fe(t, e) {
        return function(t) {
            return "number" == typeof t && Number.isInteger(t) && !ut(t) && t <= Number.MAX_SAFE_INTEGER && t >= Number.MIN_SAFE_INTEGER;
        }(e) ? 
        /**
     * Returns an IntegerValue for `value`.
     */
        function(t) {
            return {
                integerValue: "" + t
            };
        }(e) : function(t, e) {
            if (t.C) {
                if (isNaN(e)) return {
                    doubleValue: "NaN"
                };
                if (e === 1 / 0) return {
                    doubleValue: "Infinity"
                };
                if (e === -1 / 0) return {
                    doubleValue: "-Infinity"
                };
            }
            return {
                doubleValue: ut(e) ? "-0" : e
            };
        }(t, e);
    }

    /**
     * @license
     * Copyright 2018 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /** Used to represent a field transform on a mutation. */ class de {
        constructor() {
            // Make sure that the structural type of `TransformOperation` is unique.
            // See https://github.com/microsoft/TypeScript/issues/5451
            this._ = void 0;
        }
    }

    /** Transforms a value into a server-generated timestamp. */ class we extends de {}

    /** Transforms an array value via a union operation. */ class me extends de {
        constructor(t) {
            super(), this.elements = t;
        }
    }

    /** Transforms an array value via a remove operation. */ class pe extends de {
        constructor(t) {
            super(), this.elements = t;
        }
    }

    /**
     * Implements the backend semantics for locally computed NUMERIC_ADD (increment)
     * transforms. Converts all field values to integers or doubles, but unlike the
     * backend does not cap integer values at 2^63. Instead, JavaScript number
     * arithmetic is used and precision loss can occur for values greater than 2^53.
     */ class ye extends de {
        constructor(t, e) {
            super(), this.L = t, this.U = e;
        }
    }

    /**
     * Encodes a precondition for a mutation. This follows the model that the
     * backend accepts with the special case of an explicit "empty" precondition
     * (meaning no precondition).
     */ class ge {
        constructor(t, e) {
            this.updateTime = t, this.exists = e;
        }
        /** Creates a new empty Precondition. */    static none() {
            return new ge;
        }
        /** Creates a new Precondition with an exists flag. */    static exists(t) {
            return new ge(void 0, t);
        }
        /** Creates a new Precondition based on a version a document exists at. */    static updateTime(t) {
            return new ge(t);
        }
        /** Returns whether this Precondition is empty. */    get isNone() {
            return void 0 === this.updateTime && void 0 === this.exists;
        }
        isEqual(t) {
            return this.exists === t.exists && (this.updateTime ? !!t.updateTime && this.updateTime.isEqual(t.updateTime) : !t.updateTime);
        }
    }

    /**
     * A mutation describes a self-contained change to a document. Mutations can
     * create, replace, delete, and update subsets of documents.
     *
     * Mutations not only act on the value of the document but also its version.
     *
     * For local mutations (mutations that haven't been committed yet), we preserve
     * the existing version for Set and Patch mutations. For Delete mutations, we
     * reset the version to 0.
     *
     * Here's the expected transition table.
     *
     * MUTATION           APPLIED TO            RESULTS IN
     *
     * SetMutation        Document(v3)          Document(v3)
     * SetMutation        NoDocument(v3)        Document(v0)
     * SetMutation        InvalidDocument(v0)   Document(v0)
     * PatchMutation      Document(v3)          Document(v3)
     * PatchMutation      NoDocument(v3)        NoDocument(v3)
     * PatchMutation      InvalidDocument(v0)   UnknownDocument(v3)
     * DeleteMutation     Document(v3)          NoDocument(v0)
     * DeleteMutation     NoDocument(v3)        NoDocument(v0)
     * DeleteMutation     InvalidDocument(v0)   NoDocument(v0)
     *
     * For acknowledged mutations, we use the updateTime of the WriteResponse as
     * the resulting version for Set and Patch mutations. As deletes have no
     * explicit update time, we use the commitTime of the WriteResponse for
     * Delete mutations.
     *
     * If a mutation is acknowledged by the backend but fails the precondition check
     * locally, we transition to an `UnknownDocument` and rely on Watch to send us
     * the updated version.
     *
     * Field transforms are used only with Patch and Set Mutations. We use the
     * `updateTransforms` message to store transforms, rather than the `transforms`s
     * messages.
     *
     * ## Subclassing Notes
     *
     * Every type of mutation needs to implement its own applyToRemoteDocument() and
     * applyToLocalView() to implement the actual behavior of applying the mutation
     * to some source document (see `applySetMutationToRemoteDocument()` for an
     * example).
     */ class be {}

    /**
     * A mutation that creates or replaces the document at the given key with the
     * object value contents.
     */ class ve extends be {
        constructor(t, e, n, r = []) {
            super(), this.key = t, this.value = e, this.precondition = n, this.fieldTransforms = r, 
            this.type = 0 /* Set */;
        }
    }

    /**
     * A mutation that modifies fields of the document at the given key with the
     * given values. The values are applied through a field mask:
     *
     *  * When a field is in both the mask and the values, the corresponding field
     *    is updated.
     *  * When a field is in neither the mask nor the values, the corresponding
     *    field is unmodified.
     *  * When a field is in the mask but not in the values, the corresponding field
     *    is deleted.
     *  * When a field is not in the mask but is in the values, the values map is
     *    ignored.
     */ class Ee extends be {
        constructor(t, e, n, r, s = []) {
            super(), this.key = t, this.data = e, this.fieldMask = n, this.precondition = r, 
            this.fieldTransforms = s, this.type = 1 /* Patch */;
        }
    }

    /** A mutation that deletes the document at the given key. */ class Te extends be {
        constructor(t, e) {
            super(), this.key = t, this.precondition = e, this.type = 2 /* Delete */ , this.fieldTransforms = [];
        }
    }

    /**
     * A mutation that verifies the existence of the document at the given key with
     * the provided precondition.
     *
     * The `verify` operation is only used in Transactions, and this class serves
     * primarily to facilitate serialization into protos.
     */ class Ie extends be {
        constructor(t, e) {
            super(), this.key = t, this.precondition = e, this.type = 3 /* Verify */ , this.fieldTransforms = [];
        }
    }

    /**
     * This class generates JsonObject values for the Datastore API suitable for
     * sending to either GRPC stub methods or via the JSON/HTTP REST API.
     *
     * The serializer supports both Protobuf.js and Proto3 JSON formats. By
     * setting `useProto3Json` to true, the serializer will use the Proto3 JSON
     * format.
     *
     * For a description of the Proto3 JSON format check
     * https://developers.google.com/protocol-buffers/docs/proto3#json
     *
     * TODO(klimt): We can remove the databaseId argument if we keep the full
     * resource name in documents.
     */
    class Re {
        constructor(t, e) {
            this.databaseId = t, this.C = e;
        }
    }

    /**
     * Returns a value for a number (or null) that's appropriate to put into
     * a google.protobuf.Int32Value proto.
     * DO NOT USE THIS FOR ANYTHING ELSE.
     * This method cheats. It's typed as returning "number" because that's what
     * our generated proto interfaces say Int32Value must be. But GRPC actually
     * expects a { value: <number> } struct.
     */
    /**
     * Returns a value for a Date that's appropriate to put into a proto.
     */
    function Ve(t, e) {
        if (t.C) {
            return `${new Date(1e3 * e.seconds).toISOString().replace(/\.\d*/, "").replace("Z", "")}.${("000000000" + e.nanoseconds).slice(-9)}Z`;
        }
        return {
            seconds: "" + e.seconds,
            nanos: e.nanoseconds
        };
    }

    /**
     * Returns a value for bytes that's appropriate to put in a proto.
     *
     * Visible for testing.
     */
    function Ne(t, e) {
        return t.C ? e.toBase64() : e.toUint8Array();
    }

    function De(t, e) {
        return Ve(t, e.toTimestamp());
    }

    function $e(t) {
        return b$2(!!t), _t.fromTimestamp(function(t) {
            const e = It(t);
            return new yt(e.seconds, e.nanos);
        }(t));
    }

    function Fe(t, e) {
        return function(t) {
            return new K$2([ "projects", t.projectId, "databases", t.database ]);
        }(t).child("documents").child(e).canonicalString();
    }

    function Se(t, e) {
        return Fe(t.databaseId, e.path);
    }

    function xe(t, e) {
        const n = function(t) {
            const e = K$2.fromString(t);
            return b$2(We(e)), e;
        }(e);
        if (n.get(1) !== t.databaseId.projectId) throw new U$2(A$3, "Tried to deserialize key from different project: " + n.get(1) + " vs " + t.databaseId.projectId);
        if (n.get(3) !== t.databaseId.database) throw new U$2(A$3, "Tried to deserialize key from different database: " + n.get(3) + " vs " + t.databaseId.database);
        return new X$1((b$2((r = n).length > 4 && "documents" === r.get(4)), r.popFirst(5)));
        var r;
        /** Creates a Document proto from key and fields (but no create/update time) */}

    function Oe(t) {
        return new K$2([ "projects", t.databaseId.projectId, "databases", t.databaseId.database ]).canonicalString();
    }

    function Ce(t, e, n) {
        return {
            name: Se(t, e),
            fields: n.value.mapValue.fields
        };
    }

    function Le(t, e) {
        return "found" in e ? function(t, e) {
            b$2(!!e.found), e.found.name, e.found.updateTime;
            const n = xe(t, e.found.name), r = $e(e.found.updateTime), s = new kt({
                mapValue: {
                    fields: e.found.fields
                }
            });
            return Mt.newFoundDocument(n, r, s);
        }(t, e) : "missing" in e ? function(t, e) {
            b$2(!!e.missing), b$2(!!e.readTime);
            const n = xe(t, e.missing), r = $e(e.readTime);
            return Mt.newNoDocument(n, r);
        }(t, e) : g$3();
    }

    function Ue(t, e) {
        let n;
        if (e instanceof ve) n = {
            update: Ce(t, e.key, e.value)
        }; else if (e instanceof Te) n = {
            delete: Se(t, e.key)
        }; else if (e instanceof Ee) n = {
            update: Ce(t, e.key, e.data),
            updateMask: ze(e.fieldMask)
        }; else {
            if (!(e instanceof Ie)) return g$3();
            n = {
                verify: Se(t, e.key)
            };
        }
        return e.fieldTransforms.length > 0 && (n.updateTransforms = e.fieldTransforms.map((t => function(t, e) {
            const n = e.transform;
            if (n instanceof we) return {
                fieldPath: e.field.canonicalString(),
                setToServerValue: "REQUEST_TIME"
            };
            if (n instanceof me) return {
                fieldPath: e.field.canonicalString(),
                appendMissingElements: {
                    values: n.elements
                }
            };
            if (n instanceof pe) return {
                fieldPath: e.field.canonicalString(),
                removeAllFromArray: {
                    values: n.elements
                }
            };
            if (n instanceof ye) return {
                fieldPath: e.field.canonicalString(),
                increment: n.U
            };
            throw g$3();
        }(0, t)))), e.precondition.isNone || (n.currentDocument = function(t, e) {
            return void 0 !== e.updateTime ? {
                updateTime: De(t, e.updateTime)
            } : void 0 !== e.exists ? {
                exists: e.exists
            } : g$3();
        }(t, e.precondition)), n;
    }

    function ze(t) {
        const e = [];
        return t.fields.forEach((t => e.push(t.canonicalString()))), {
            fieldPaths: e
        };
    }

    function We(t) {
        // Resource names have at least 4 components (project ID, database ID)
        return t.length >= 4 && "projects" === t.get(0) && "databases" === t.get(2);
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */ function Ge(t) {
        return new Re(t, /* useProto3Json= */ !0);
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Datastore and its related methods are a wrapper around the external Google
     * Cloud Datastore grpc API, which provides an interface that is more convenient
     * for the rest of the client SDK architecture to consume.
     */
    /**
     * An implementation of Datastore that exposes additional state for internal
     * consumption.
     */
    class Ye extends class {} {
        constructor(t, e, n) {
            super(), this.credentials = t, this.X = e, this.L = n, this.tt = !1;
        }
        et() {
            if (this.tt) throw new U$2(F$3, "The client has already been terminated.");
        }
        /** Gets an auth token and invokes the provided RPC. */    v(t, e, n) {
            return this.et(), this.credentials.getToken().then((r => this.X.v(t, e, n, r))).catch((t => {
                throw "FirebaseError" === t.name ? (t.code === D$2 && this.credentials.invalidateToken(), 
                t) : new U$2(I$2, t.toString());
            }));
        }
        /** Gets an auth token and invokes the provided RPC with streamed results. */    P(t, e, n) {
            return this.et(), this.credentials.getToken().then((r => this.X.P(t, e, n, r))).catch((t => {
                throw "FirebaseError" === t.name ? (t.code === D$2 && this.credentials.invalidateToken(), 
                t) : new U$2(I$2, t.toString());
            }));
        }
        terminate() {
            this.tt = !0;
        }
    }

    // TODO(firestorexp): Make sure there is only one Datastore instance per
    // firestore-exp client.
    async function Ke(t, e) {
        const n = v$2(t), r = Oe(n.L) + "/documents", s = {
            writes: e.map((t => Ue(n.L, t)))
        };
        await n.v("Commit", r, s);
    }

    async function Je(t, e) {
        const n = v$2(t), r = Oe(n.L) + "/documents", s = {
            documents: e.map((t => Se(n.L, t)))
        }, i = await n.P("BatchGetDocuments", r, s), o = new Map;
        i.forEach((t => {
            const e = Le(n.L, t);
            o.set(e.key.toString(), e);
        }));
        const u = [];
        return e.forEach((t => {
            const e = o.get(t.toString());
            b$2(!!e), u.push(e);
        })), u;
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */ const Xe = new Map;

    /**
     * An instance map that ensures only one Datastore exists per Firestore
     * instance.
     */
    /**
     * Returns an initialized and started Datastore for the given Firestore
     * instance. Callers must invoke removeComponents() when the Firestore
     * instance is terminated.
     */
    function tn$1(t) {
        if (t._terminated) throw new U$2(F$3, "The client has already been terminated.");
        if (!Xe.has(t)) {
            m$2("ComponentProvider", "Initializing Datastore");
            const i = function(t) {
                return new ft(t, fetch.bind(null));
            }((e = t._databaseId, n = t.app.options.appId || "", r = t._persistenceKey, s = t._freezeSettings(), 
            new G$2(e, n, r, s.host, s.ssl, s.experimentalForceLongPolling, s.experimentalAutoDetectLongPolling, s.useFetchStreams))), o = Ge(t._databaseId), u = function(t, e, n) {
                return new Ye(t, e, n);
            }(t._credentials, i, o);
            Xe.set(t, u);
        }
        var e, n, r, s;
        /**
     * @license
     * Copyright 2018 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */    return Xe.get(t);
    }

    /**
     * Removes all components associated with the provided instance. Must be called
     * when the `Firestore` instance is terminated.
     */
    /**
     * A concrete type describing all the values that can be applied via a
     * user-supplied firestore.Settings object. This is a separate type so that
     * defaults can be supplied and the value can be checked for equality.
     */
    class en$1 {
        constructor(t) {
            var e;
            if (void 0 === t.host) {
                if (void 0 !== t.ssl) throw new U$2(A$3, "Can't provide ssl option if host option is not set");
                this.host = "firestore.googleapis.com", this.ssl = true;
            } else this.host = t.host, this.ssl = null === (e = t.ssl) || void 0 === e || e;
            if (this.credentials = t.credentials, this.ignoreUndefinedProperties = !!t.ignoreUndefinedProperties, 
            void 0 === t.cacheSizeBytes) this.cacheSizeBytes = 41943040; else {
                if (-1 !== t.cacheSizeBytes && t.cacheSizeBytes < 1048576) throw new U$2(A$3, "cacheSizeBytes must be at least 1048576");
                this.cacheSizeBytes = t.cacheSizeBytes;
            }
            this.experimentalForceLongPolling = !!t.experimentalForceLongPolling, this.experimentalAutoDetectLongPolling = !!t.experimentalAutoDetectLongPolling, 
            this.useFetchStreams = !!t.useFetchStreams, function(t, e, n, r) {
                if (!0 === e && !0 === r) throw new U$2(A$3, `${t} and ${n} cannot be used together.`);
            }("experimentalForceLongPolling", t.experimentalForceLongPolling, "experimentalAutoDetectLongPolling", t.experimentalAutoDetectLongPolling);
        }
        isEqual(t) {
            return this.host === t.host && this.ssl === t.ssl && this.credentials === t.credentials && this.cacheSizeBytes === t.cacheSizeBytes && this.experimentalForceLongPolling === t.experimentalForceLongPolling && this.experimentalAutoDetectLongPolling === t.experimentalAutoDetectLongPolling && this.ignoreUndefinedProperties === t.ignoreUndefinedProperties && this.useFetchStreams === t.useFetchStreams;
        }
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * The Cloud Firestore service interface.
     *
     * Do not call this constructor directly. Instead, use {@link getFirestore}.
     */ class nn$1 {
        /** @hideconstructor */
        constructor(t, e) {
            this.type = "firestore-lite", this._persistenceKey = "(lite)", this._settings = new en$1({}), 
            this._settingsFrozen = !1, t instanceof H$2 ? (this._databaseId = t, this._credentials = new M$2) : (this._app = t, 
            this._databaseId = function(t) {
                if (!Object.prototype.hasOwnProperty.apply(t.options, [ "projectId" ])) throw new U$2(A$3, '"projectId" not provided in firebase.initializeApp.');
                return new H$2(t.options.projectId);
            }
            /**
     * Initializes a new instance of Cloud Firestore with the provided settings.
     * Can only be called before any other functions, including
     * {@link getFirestore}. If the custom settings are empty, this function is
     * equivalent to calling {@link getFirestore}.
     *
     * @param app - The {@link @firebase/app#FirebaseApp} with which the `Firestore` instance will
     * be associated.
     * @param settings - A settings object to configure the `Firestore` instance.
     * @returns A newly initialized Firestore instance.
     */ (t), this._credentials = new Q$2(e));
        }
        /**
         * The {@link @firebase/app#FirebaseApp} associated with this `Firestore` service
         * instance.
         */    get app() {
            if (!this._app) throw new U$2(F$3, "Firestore was not initialized using the Firebase SDK. 'app' is not available");
            return this._app;
        }
        get _initialized() {
            return this._settingsFrozen;
        }
        get _terminated() {
            return void 0 !== this._terminateTask;
        }
        _setSettings(t) {
            if (this._settingsFrozen) throw new U$2(F$3, "Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");
            this._settings = new en$1(t), void 0 !== t.credentials && (this._credentials = function(t) {
                if (!t) return new M$2;
                switch (t.type) {
                  case "gapi":
                    const e = t.client;
                    // Make sure this really is a Gapi client.
                                    return b$2(!("object" != typeof e || null === e || !e.auth || !e.auth.getAuthHeaderValueForFirstParty)), 
                    new W$2(e, t.sessionIndex || "0", t.iamToken || null);

                  case "provider":
                    return t.client;

                  default:
                    throw new U$2(A$3, "makeCredentialsProvider failed due to invalid credential type");
                }
            }(t.credentials));
        }
        _getSettings() {
            return this._settings;
        }
        _freezeSettings() {
            return this._settingsFrozen = !0, this._settings;
        }
        _delete() {
            return this._terminateTask || (this._terminateTask = this._terminate()), this._terminateTask;
        }
        /** Returns a JSON-serializable representation of this Firestore instance. */    toJSON() {
            return {
                app: this._app,
                databaseId: this._databaseId,
                settings: this._settings
            };
        }
        /**
         * Terminates all components used by this client. Subclasses can override
         * this method to clean up their own dependencies, but must also call this
         * method.
         *
         * Only ever called once.
         */    _terminate() {
            return function(t) {
                const e = Xe.get(t);
                e && (m$2("ComponentProvider", "Removing Datastore"), Xe.delete(t), e.terminate());
            }(this), Promise.resolve();
        }
    }

    /**
     * Returns the existing instance of Firestore that is associated with the
     * provided {@link @firebase/app#FirebaseApp}. If no instance exists, initializes a new
     * instance with default settings.
     *
     * @param app - The {@link @firebase/app#FirebaseApp} instance that the returned Firestore
     * instance is associated with.
     * @returns The `Firestore` instance of the provided app.
     */ function sn(n = getApp()) {
        return _getProvider(n, "firestore/lite").getImmediate();
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * A `DocumentReference` refers to a document location in a Firestore database
     * and can be used to write, read, or listen to the location. The document at
     * the referenced location may or may not exist.
     */
    class cn {
        /** @hideconstructor */
        constructor(t, 
        /**
         * If provided, the `FirestoreDataConverter` associated with this instance.
         */
        e, n) {
            this.converter = e, this._key = n, 
            /** The type of this Firestore reference. */
            this.type = "document", this.firestore = t;
        }
        get _path() {
            return this._key.path;
        }
        /**
         * The document's identifier within its collection.
         */    get id() {
            return this._key.path.lastSegment();
        }
        /**
         * A string representing the path of the referenced document (relative
         * to the root of the database).
         */    get path() {
            return this._key.path.canonicalString();
        }
        /**
         * The collection this `DocumentReference` belongs to.
         */    get parent() {
            return new hn(this.firestore, this.converter, this._key.path.popLast());
        }
        withConverter(t) {
            return new cn(this.firestore, t, this._key);
        }
    }

    /**
     * A `Query` refers to a Query which you can read or listen to. You can also
     * construct refined `Query` objects by adding filters and ordering.
     */ class an {
        // This is the lite version of the Query class in the main SDK.
        /** @hideconstructor protected */
        constructor(t, 
        /**
         * If provided, the `FirestoreDataConverter` associated with this instance.
         */
        e, n) {
            this.converter = e, this._query = n, 
            /** The type of this Firestore reference. */
            this.type = "query", this.firestore = t;
        }
        withConverter(t) {
            return new an(this.firestore, t, this._query);
        }
    }

    /**
     * A `CollectionReference` object can be used for adding documents, getting
     * document references, and querying for documents (using {@link query}).
     */ class hn extends an {
        /** @hideconstructor */
        constructor(t, e, n) {
            super(t, e, new se(n)), this._path = n, 
            /** The type of this Firestore reference. */
            this.type = "collection";
        }
        /** The collection's identifier. */    get id() {
            return this._query.path.lastSegment();
        }
        /**
         * A string representing the path of the referenced collection (relative
         * to the root of the database).
         */    get path() {
            return this._query.path.canonicalString();
        }
        /**
         * A reference to the containing `DocumentReference` if this is a
         * subcollection. If this isn't a subcollection, the reference is null.
         */    get parent() {
            const t = this._path.popLast();
            return t.isEmpty() ? null : new cn(this.firestore, 
            /* converter= */ null, new X$1(t));
        }
        withConverter(t) {
            return new hn(this.firestore, t, this._path);
        }
    }

    function dn(t, e, ...n) {
        if (t = getModularInstance(t), 
        // We allow omission of 'pathString' but explicitly prohibit passing in both
        // 'undefined' and 'null'.
        1 === arguments.length && (e = wt.N()), tt("doc", "path", e), t instanceof nn$1) {
            const r = K$2.fromString(e, ...n);
            return et(r), new cn(t, 
            /* converter= */ null, new X$1(r));
        }
        {
            if (!(t instanceof cn || t instanceof hn)) throw new U$2(A$3, "Expected first argument to collection() to be a CollectionReference, a DocumentReference or FirebaseFirestore");
            const r = t._path.child(K$2.fromString(e, ...n));
            return et(r), new cn(t.firestore, t instanceof hn ? t.converter : null, new X$1(r));
        }
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * A `FieldPath` refers to a field in a document. The path may consist of a
     * single field name (referring to a top-level field in the document), or a
     * list of field names (referring to a nested field in the document).
     *
     * Create a `FieldPath` by providing field names. If more than one field
     * name is provided, the path will point to a nested field in a document.
     */ class pn {
        /**
         * Creates a FieldPath from the provided field names. If more than one field
         * name is provided, the path will point to a nested field in a document.
         *
         * @param fieldNames - A list of field names.
         */
        constructor(...t) {
            for (let e = 0; e < t.length; ++e) if (0 === t[e].length) throw new U$2(A$3, "Invalid field name at argument $(i + 1). Field names must not be empty.");
            this._internalPath = new Z$2(t);
        }
        /**
         * Returns true if this `FieldPath` is equal to the provided one.
         *
         * @param other - The `FieldPath` to compare against.
         * @returns true if this `FieldPath` is equal to the provided one.
         */    isEqual(t) {
            return this._internalPath.isEqual(t._internalPath);
        }
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * An immutable object representing an array of bytes.
     */ class _n {
        /** @hideconstructor */
        constructor(t) {
            this._byteString = t;
        }
        /**
         * Creates a new `Bytes` object from the given Base64 string, converting it to
         * bytes.
         *
         * @param base64 - The Base64 string used to create the `Bytes` object.
         */    static fromBase64String(t) {
            try {
                return new _n(Et.fromBase64String(t));
            } catch (t) {
                throw new U$2(A$3, "Failed to construct data from Base64 string: " + t);
            }
        }
        /**
         * Creates a new `Bytes` object from the given Uint8Array.
         *
         * @param array - The Uint8Array used to create the `Bytes` object.
         */    static fromUint8Array(t) {
            return new _n(Et.fromUint8Array(t));
        }
        /**
         * Returns the underlying bytes as a Base64-encoded string.
         *
         * @returns The Base64-encoded string created from the `Bytes` object.
         */    toBase64() {
            return this._byteString.toBase64();
        }
        /**
         * Returns the underlying bytes in a new `Uint8Array`.
         *
         * @returns The Uint8Array created from the `Bytes` object.
         */    toUint8Array() {
            return this._byteString.toUint8Array();
        }
        /**
         * Returns a string representation of the `Bytes` object.
         *
         * @returns A string representation of the `Bytes` object.
         */    toString() {
            return "Bytes(base64: " + this.toBase64() + ")";
        }
        /**
         * Returns true if this `Bytes` object is equal to the provided one.
         *
         * @param other - The `Bytes` object to compare against.
         * @returns true if this `Bytes` object is equal to the provided one.
         */    isEqual(t) {
            return this._byteString.isEqual(t._byteString);
        }
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Sentinel values that can be used when writing document fields with `set()`
     * or `update()`.
     */ class gn {
        /**
         * @param _methodName - The public API endpoint that returns this class.
         * @hideconstructor
         */
        constructor(t) {
            this._methodName = t;
        }
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * An immutable object representing a geographic location in Firestore. The
     * location is represented as latitude/longitude pair.
     *
     * Latitude values are in the range of [-90, 90].
     * Longitude values are in the range of [-180, 180].
     */ class bn {
        /**
         * Creates a new immutable `GeoPoint` object with the provided latitude and
         * longitude values.
         * @param latitude - The latitude as number between -90 and 90.
         * @param longitude - The longitude as number between -180 and 180.
         */
        constructor(t, e) {
            if (!isFinite(t) || t < -90 || t > 90) throw new U$2(A$3, "Latitude must be a number between -90 and 90, but was: " + t);
            if (!isFinite(e) || e < -180 || e > 180) throw new U$2(A$3, "Longitude must be a number between -180 and 180, but was: " + e);
            this._lat = t, this._long = e;
        }
        /**
         * The latitude of this `GeoPoint` instance.
         */    get latitude() {
            return this._lat;
        }
        /**
         * The longitude of this `GeoPoint` instance.
         */    get longitude() {
            return this._long;
        }
        /**
         * Returns true if this `GeoPoint` is equal to the provided one.
         *
         * @param other - The `GeoPoint` to compare against.
         * @returns true if this `GeoPoint` is equal to the provided one.
         */    isEqual(t) {
            return this._lat === t._lat && this._long === t._long;
        }
        /** Returns a JSON-serializable representation of this GeoPoint. */    toJSON() {
            return {
                latitude: this._lat,
                longitude: this._long
            };
        }
        /**
         * Actually private to JS consumers of our API, so this function is prefixed
         * with an underscore.
         */    _compareTo(t) {
            return mt(this._lat, t._lat) || mt(this._long, t._long);
        }
    }

    /**
     * @license
     * Copyright 2017 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */ const vn = /^__.*__$/;

    /** The result of parsing document data (e.g. for a setData call). */ class En {
        constructor(t, e, n) {
            this.data = t, this.fieldMask = e, this.fieldTransforms = n;
        }
        toMutation(t, e) {
            return null !== this.fieldMask ? new Ee(t, this.data, this.fieldMask, e, this.fieldTransforms) : new ve(t, this.data, e, this.fieldTransforms);
        }
    }

    function In(t) {
        switch (t) {
          case 0 /* Set */ :
     // fall through
                  case 2 /* MergeSet */ :
     // fall through
                  case 1 /* Update */ :
            return !0;

          case 3 /* Argument */ :
          case 4 /* ArrayArgument */ :
            return !1;

          default:
            throw g$3();
        }
    }

    /** A "context" object passed around while parsing user data. */ class An {
        /**
         * Initializes a ParseContext with the given source and path.
         *
         * @param settings - The settings for the parser.
         * @param databaseId - The database ID of the Firestore instance.
         * @param serializer - The serializer to use to generate the Value proto.
         * @param ignoreUndefinedProperties - Whether to ignore undefined properties
         * rather than throw.
         * @param fieldTransforms - A mutable list of field transforms encountered
         * while parsing the data.
         * @param fieldMask - A mutable list of field paths encountered while parsing
         * the data.
         *
         * TODO(b/34871131): We don't support array paths right now, so path can be
         * null to indicate the context represents any location within an array (in
         * which case certain features will not work and errors will be somewhat
         * compromised).
         */
        constructor(t, e, n, r, s, i) {
            this.settings = t, this.databaseId = e, this.L = n, this.ignoreUndefinedProperties = r, 
            // Minor hack: If fieldTransforms is undefined, we assume this is an
            // external call and we need to validate the entire path.
            void 0 === s && this.nt(), this.fieldTransforms = s || [], this.fieldMask = i || [];
        }
        get path() {
            return this.settings.path;
        }
        get rt() {
            return this.settings.rt;
        }
        /** Returns a new context with the specified settings overwritten. */    st(t) {
            return new An(Object.assign(Object.assign({}, this.settings), t), this.databaseId, this.L, this.ignoreUndefinedProperties, this.fieldTransforms, this.fieldMask);
        }
        it(t) {
            var e;
            const n = null === (e = this.path) || void 0 === e ? void 0 : e.child(t), r = this.st({
                path: n,
                ot: !1
            });
            return r.ut(t), r;
        }
        ct(t) {
            var e;
            const n = null === (e = this.path) || void 0 === e ? void 0 : e.child(t), r = this.st({
                path: n,
                ot: !1
            });
            return r.nt(), r;
        }
        at(t) {
            // TODO(b/34871131): We don't support array paths right now; so make path
            // undefined.
            return this.st({
                path: void 0,
                ot: !0
            });
        }
        ht(t) {
            return zn(t, this.settings.methodName, this.settings.lt || !1, this.path, this.settings.ft);
        }
        /** Returns 'true' if 'fieldPath' was traversed when creating this context. */    contains(t) {
            return void 0 !== this.fieldMask.find((e => t.isPrefixOf(e))) || void 0 !== this.fieldTransforms.find((e => t.isPrefixOf(e.field)));
        }
        nt() {
            // TODO(b/34871131): Remove null check once we have proper paths for fields
            // within arrays.
            if (this.path) for (let t = 0; t < this.path.length; t++) this.ut(this.path.get(t));
        }
        ut(t) {
            if (0 === t.length) throw this.ht("Document fields must not be empty");
            if (In(this.rt) && vn.test(t)) throw this.ht('Document fields cannot begin and end with "__"');
        }
    }

    /**
     * Helper for parsing raw user input (provided via the API) into internal model
     * classes.
     */ class Pn {
        constructor(t, e, n) {
            this.databaseId = t, this.ignoreUndefinedProperties = e, this.L = n || Ge(t);
        }
        /** Creates a new top-level parse context. */    dt(t, e, n, r = !1) {
            return new An({
                rt: t,
                methodName: e,
                ft: n,
                path: Z$2.emptyPath(),
                ot: !1,
                lt: r
            }, this.databaseId, this.L, this.ignoreUndefinedProperties);
        }
    }

    function Rn(t) {
        const e = t._freezeSettings(), n = Ge(t._databaseId);
        return new Pn(t._databaseId, !!e.ignoreUndefinedProperties, n);
    }

    /** Parse document data from a set() call. */ function Vn(t, e, n, r, s, i = {}) {
        const o = t.dt(i.merge || i.mergeFields ? 2 /* MergeSet */ : 0 /* Set */ , e, n, s);
        kn("Data must be an object, but it was:", o, r);
        const u = Un(r, o);
        let c, a;
        if (i.merge) c = new vt(o.fieldMask), a = o.fieldTransforms; else if (i.mergeFields) {
            const t = [];
            for (const r of i.mergeFields) {
                const s = Mn(e, r, n);
                if (!o.contains(s)) throw new U$2(A$3, `Field '${s}' is specified in your field mask but missing from your input data.`);
                Wn(t, s) || t.push(s);
            }
            c = new vt(t), a = o.fieldTransforms.filter((t => c.covers(t.field)));
        } else c = null, a = o.fieldTransforms;
        return new En(new kt(u), c, a);
    }

    /**
     * Parses user data to Protobuf Values.
     *
     * @param input - Data to be parsed.
     * @param context - A context object representing the current path being parsed,
     * the source of the data being parsed, etc.
     * @returns The parsed value, or null if the value was a FieldValue sentinel
     * that should not be included in the resulting parsed data.
     */ function Ln(t, e) {
        if (jn(
        // Unwrap the API type from the Compat SDK. This will return the API type
        // from firestore-exp.
        t = getModularInstance(t))) return kn("Unsupported field value:", e, t), Un(t, e);
        if (t instanceof gn) 
        // FieldValues usually parse into transforms (except FieldValue.delete())
        // in which case we do not want to include this field in our parsed data
        // (as doing so will overwrite the field directly prior to the transform
        // trying to transform it). So we don't add this location to
        // context.fieldMask and we return null as our parsing result.
        /**
     * "Parses" the provided FieldValueImpl, adding any necessary transforms to
     * context.fieldTransforms.
     */
        return function(t, e) {
            // Sentinels are only supported with writes, and not within arrays.
            if (!In(e.rt)) throw e.ht(`${t._methodName}() can only be used with update() and set()`);
            if (!e.path) throw e.ht(`${t._methodName}() is not currently supported inside arrays`);
            const n = t._toFieldTransform(e);
            n && e.fieldTransforms.push(n);
        }
        /**
     * Helper to parse a scalar value (i.e. not an Object, Array, or FieldValue)
     *
     * @returns The parsed value
     */ (t, e), null;
        if (void 0 === t && e.ignoreUndefinedProperties) 
        // If the input is undefined it can never participate in the fieldMask, so
        // don't handle this below. If `ignoreUndefinedProperties` is false,
        // `parseScalarValue` will reject an undefined value.
        return null;
        if (
        // If context.path is null we are inside an array and we don't support
        // field mask paths more granular than the top-level array.
        e.path && e.fieldMask.push(e.path), t instanceof Array) {
            // TODO(b/34871131): Include the path containing the array in the error
            // message.
            // In the case of IN queries, the parsed data is an array (representing
            // the set of values to be included for the IN query) that may directly
            // contain additional arrays (each representing an individual field
            // value), so we disable this validation.
            if (e.settings.ot && 4 /* ArrayArgument */ !== e.rt) throw e.ht("Nested arrays are not supported");
            return function(t, e) {
                const n = [];
                let r = 0;
                for (const s of t) {
                    let t = Ln(s, e.at(r));
                    null == t && (
                    // Just include nulls in the array for fields being replaced with a
                    // sentinel.
                    t = {
                        nullValue: "NULL_VALUE"
                    }), n.push(t), r++;
                }
                return {
                    arrayValue: {
                        values: n
                    }
                };
            }(t, e);
        }
        return function(t, e) {
            if (null === (t = getModularInstance(t))) return {
                nullValue: "NULL_VALUE"
            };
            if ("number" == typeof t) return fe(e.L, t);
            if ("boolean" == typeof t) return {
                booleanValue: t
            };
            if ("string" == typeof t) return {
                stringValue: t
            };
            if (t instanceof Date) {
                const n = yt.fromDate(t);
                return {
                    timestampValue: Ve(e.L, n)
                };
            }
            if (t instanceof yt) {
                // Firestore backend truncates precision down to microseconds. To ensure
                // offline mode works the same with regards to truncation, perform the
                // truncation immediately without waiting for the backend to do that.
                const n = new yt(t.seconds, 1e3 * Math.floor(t.nanoseconds / 1e3));
                return {
                    timestampValue: Ve(e.L, n)
                };
            }
            if (t instanceof bn) return {
                geoPointValue: {
                    latitude: t.latitude,
                    longitude: t.longitude
                }
            };
            if (t instanceof _n) return {
                bytesValue: Ne(e.L, t._byteString)
            };
            if (t instanceof cn) {
                const n = e.databaseId, r = t.firestore._databaseId;
                if (!r.isEqual(n)) throw e.ht(`Document reference is for database ${r.projectId}/${r.database} but should be for database ${n.projectId}/${n.database}`);
                return {
                    referenceValue: Fe(t.firestore._databaseId || e.databaseId, t._key.path)
                };
            }
            throw e.ht(`Unsupported field value: ${rt(t)}`);
        }
        /**
     * Checks whether an object looks like a JSON object that should be converted
     * into a struct. Normal class/prototype instances are considered to look like
     * JSON objects since they should be converted to a struct value. Arrays, Dates,
     * GeoPoints, etc. are not considered to look like JSON objects since they map
     * to specific FieldValue types other than ObjectValue.
     */ (t, e);
    }

    function Un(t, e) {
        const n = {};
        return !function(t) {
            for (const e in t) if (Object.prototype.hasOwnProperty.call(t, e)) return !1;
            return !0;
        }(t) ? bt(t, ((t, r) => {
            const s = Ln(r, e.it(t));
            null != s && (n[t] = s);
        })) : 
        // If we encounter an empty object, we explicitly add it to the update
        // mask to ensure that the server creates a map entry.
        e.path && e.path.length > 0 && e.fieldMask.push(e.path), {
            mapValue: {
                fields: n
            }
        };
    }

    function jn(t) {
        return !("object" != typeof t || null === t || t instanceof Array || t instanceof Date || t instanceof yt || t instanceof bn || t instanceof _n || t instanceof cn || t instanceof gn);
    }

    function kn(t, e, n) {
        if (!jn(n) || !function(t) {
            return "object" == typeof t && null !== t && (Object.getPrototypeOf(t) === Object.prototype || null === Object.getPrototypeOf(t));
        }(n)) {
            const r = rt(n);
            throw "an object" === r ? e.ht(t + " a custom object") : e.ht(t + " " + r);
        }
    }

    /**
     * Helper that calls fromDotSeparatedString() but wraps any error thrown.
     */ function Mn(t, e, n) {
        if ((
        // If required, replace the FieldPath Compat class with with the firestore-exp
        // FieldPath.
        e = getModularInstance(e)) instanceof pn) return e._internalPath;
        if ("string" == typeof e) return Qn(t, e);
        throw zn("Field path arguments must be of type string or FieldPath.", t, 
        /* hasConverter= */ !1, 
        /* path= */ void 0, n);
    }

    /**
     * Matches any characters in a field path string that are reserved.
     */ const Bn = new RegExp("[~\\*/\\[\\]]");

    /**
     * Wraps fromDotSeparatedString with an error message about the method that
     * was thrown.
     * @param methodName - The publicly visible method name
     * @param path - The dot-separated string form of a field path which will be
     * split on dots.
     * @param targetDoc - The document against which the field path will be
     * evaluated.
     */ function Qn(t, e, n) {
        if (e.search(Bn) >= 0) throw zn(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`, t, 
        /* hasConverter= */ !1, 
        /* path= */ void 0, n);
        try {
            return new pn(...e.split("."))._internalPath;
        } catch (r) {
            throw zn(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`, t, 
            /* hasConverter= */ !1, 
            /* path= */ void 0, n);
        }
    }

    function zn(t, e, n, r, s) {
        const i = r && !r.isEmpty(), o = void 0 !== s;
        let u = `Function ${e}() called with invalid data`;
        n && (u += " (via `toFirestore()`)"), u += ". ";
        let c = "";
        return (i || o) && (c += " (found", i && (c += ` in field ${r}`), o && (c += ` in document ${s}`), 
        c += ")"), new U$2(A$3, u + t + c);
    }

    /** Checks `haystack` if FieldPath `needle` is present. Runs in O(n). */ function Wn(t, e) {
        return t.some((t => t.isEqual(e)));
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * A `DocumentSnapshot` contains data read from a document in your Firestore
     * database. The data can be extracted with `.data()` or `.get(<field>)` to
     * get a specific field.
     *
     * For a `DocumentSnapshot` that points to a non-existing document, any data
     * access will return 'undefined'. You can use the `exists()` method to
     * explicitly verify a document's existence.
     */ class Gn {
        // Note: This class is stripped down version of the DocumentSnapshot in
        // the legacy SDK. The changes are:
        // - No support for SnapshotMetadata.
        // - No support for SnapshotOptions.
        /** @hideconstructor protected */
        constructor(t, e, n, r, s) {
            this._firestore = t, this._userDataWriter = e, this._key = n, this._document = r, 
            this._converter = s;
        }
        /** Property of the `DocumentSnapshot` that provides the document's ID. */    get id() {
            return this._key.path.lastSegment();
        }
        /**
         * The `DocumentReference` for the document included in the `DocumentSnapshot`.
         */    get ref() {
            return new cn(this._firestore, this._converter, this._key);
        }
        /**
         * Signals whether or not the document at the snapshot's location exists.
         *
         * @returns true if the document exists.
         */    exists() {
            return null !== this._document;
        }
        /**
         * Retrieves all fields in the document as an `Object`. Returns `undefined` if
         * the document doesn't exist.
         *
         * @returns An `Object` containing all fields in the document or `undefined`
         * if the document doesn't exist.
         */    data() {
            if (this._document) {
                if (this._converter) {
                    // We only want to use the converter and create a new DocumentSnapshot
                    // if a converter has been provided.
                    const t = new Hn(this._firestore, this._userDataWriter, this._key, this._document, 
                    /* converter= */ null);
                    return this._converter.fromFirestore(t);
                }
                return this._userDataWriter.convertValue(this._document.data.value);
            }
        }
        /**
         * Retrieves the field specified by `fieldPath`. Returns `undefined` if the
         * document or field doesn't exist.
         *
         * @param fieldPath - The path (for example 'foo' or 'foo.bar') to a specific
         * field.
         * @returns The data at the specified field location or undefined if no such
         * field exists in the document.
         */
        // We are using `any` here to avoid an explicit cast by our users.
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        get(t) {
            if (this._document) {
                const e = this._document.data.field(Jn("DocumentSnapshot.get", t));
                if (null !== e) return this._userDataWriter.convertValue(e);
            }
        }
    }

    /**
     * A `QueryDocumentSnapshot` contains data read from a document in your
     * Firestore database as part of a query. The document is guaranteed to exist
     * and its data can be extracted with `.data()` or `.get(<field>)` to get a
     * specific field.
     *
     * A `QueryDocumentSnapshot` offers the same API surface as a
     * `DocumentSnapshot`. Since query results contain only existing documents, the
     * `exists` property will always be true and `data()` will never return
     * 'undefined'.
     */ class Hn extends Gn {
        /**
         * Retrieves all fields in the document as an `Object`.
         *
         * @override
         * @returns An `Object` containing all fields in the document.
         */
        data() {
            return super.data();
        }
    }

    /**
     * Helper that calls fromDotSeparatedString() but wraps any error thrown.
     */ function Jn(t, e) {
        return "string" == typeof e ? Qn(t, e) : e instanceof pn ? e._internalPath : e._delegate._internalPath;
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Converts Firestore's internal types to the JavaScript types that we expose
     * to the user.
     *
     * @internal
     */
    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Converts custom model object of type T into DocumentData by applying the
     * converter if it exists.
     *
     * This function is used when converting user objects to DocumentData
     * because we want to provide the user with a more specific error message if
     * their set() or fails due to invalid data originating from a toFirestore()
     * call.
     */
    function yr(t, e, n) {
        let r;
        // Cast to `any` in order to satisfy the union type constraint on
        // toFirestore().
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return r = t ? n && (n.merge || n.mergeFields) ? t.toFirestore(e, n) : t.toFirestore(e) : e, 
        r;
    }

    class _r extends class {
        convertValue(t, e = "none") {
            switch (Dt(t)) {
              case 0 /* NullValue */ :
                return null;

              case 1 /* BooleanValue */ :
                return t.booleanValue;

              case 2 /* NumberValue */ :
                return At(t.integerValue || t.doubleValue);

              case 3 /* TimestampValue */ :
                return this.convertTimestamp(t.timestampValue);

              case 4 /* ServerTimestampValue */ :
                return this.convertServerTimestamp(t, e);

              case 5 /* StringValue */ :
                return t.stringValue;

              case 6 /* BlobValue */ :
                return this.convertBytes(Pt(t.bytesValue));

              case 7 /* RefValue */ :
                return this.convertReference(t.referenceValue);

              case 8 /* GeoPointValue */ :
                return this.convertGeoPoint(t.geoPointValue);

              case 9 /* ArrayValue */ :
                return this.convertArray(t.arrayValue, e);

              case 10 /* ObjectValue */ :
                return this.convertObject(t.mapValue, e);

              default:
                throw g$3();
            }
        }
        convertObject(t, e) {
            const n = {};
            return bt(t.fields, ((t, r) => {
                n[t] = this.convertValue(r, e);
            })), n;
        }
        convertGeoPoint(t) {
            return new bn(At(t.latitude), At(t.longitude));
        }
        convertArray(t, e) {
            return (t.values || []).map((t => this.convertValue(t, e)));
        }
        convertServerTimestamp(t, e) {
            switch (e) {
              case "previous":
                const n = Vt(t);
                return null == n ? null : this.convertValue(n, e);

              case "estimate":
                return this.convertTimestamp(Nt(t));

              default:
                return null;
            }
        }
        convertTimestamp(t) {
            const e = It(t);
            return new yt(e.seconds, e.nanos);
        }
        convertDocumentKey(t, e) {
            const n = K$2.fromString(t);
            b$2(We(n));
            const r = new H$2(n.get(1), n.get(3)), s = new X$1(n.popFirst(5));
            return r.isEqual(e) || 
            // TODO(b/64130202): Somehow support foreign references.
            p$2(`Document ${s} contains a document reference within a different database (${r.projectId}/${r.database}) which is not supported. It will be treated as a reference in the current database (${e.projectId}/${e.database}) instead.`), 
            s;
        }
    } {
        constructor(t) {
            super(), this.firestore = t;
        }
        convertBytes(t) {
            return new _n(t);
        }
        convertReference(t) {
            const e = this.convertDocumentKey(t, this.firestore._databaseId);
            return new cn(this.firestore, /* converter= */ null, e);
        }
    }

    /**
     * Reads the document referred to by the specified document reference.
     *
     * All documents are directly fetched from the server, even if the document was
     * previously read or modified. Recent modifications are only reflected in the
     * retrieved `DocumentSnapshot` if they have already been applied by the
     * backend. If the client is offline, the read fails. If you like to use
     * caching or see local modifications, please use the full Firestore SDK.
     *
     * @param reference - The reference of the document to fetch.
     * @returns A Promise resolved with a `DocumentSnapshot` containing the current
     * document contents.
     */ function gr(t) {
        const e = tn$1((t = st(t, cn)).firestore), n = new _r(t.firestore);
        return Je(e, [ t._key ]).then((e => {
            b$2(1 === e.length);
            const r = e[0];
            return new Gn(t.firestore, n, t._key, r.isFoundDocument() ? r : null, t.converter);
        }));
    }

    function vr(t, e, n) {
        const r = yr((t = st(t, cn)).converter, e, n), s = Vn(Rn(t.firestore), "setDoc", t._key, r, null !== t.converter, n);
        return Ke(tn$1(t.firestore), [ s.toMutation(t._key, ge.none()) ]);
    }

    /**
     * Firestore Lite
     *
     * @remarks Firestore Lite is a small online-only SDK that allows read
     * and write access to your Firestore database. All operations connect
     * directly to the backend, and `onSnapshot()` APIs are not supported.
     * @packageDocumentation
     */ !function(t) {
        l$2 = t;
    }(`${SDK_VERSION}_lite`), _registerComponent(new Component("firestore/lite", ((t, {options: e}) => {
        const n = t.getProvider("app-exp").getImmediate(), r = new nn$1(n, t.getProvider("auth-internal"));
        return e && r._setSettings(e), r;
    }), "PUBLIC" /* PUBLIC */)), registerVersion("firestore-lite", "0.0.900-exp.6ef484a04", "node");

    function toArray(arr) {
      return Array.prototype.slice.call(arr);
    }

    function promisifyRequest(request) {
      return new Promise(function(resolve, reject) {
        request.onsuccess = function() {
          resolve(request.result);
        };

        request.onerror = function() {
          reject(request.error);
        };
      });
    }

    function promisifyRequestCall(obj, method, args) {
      var request;
      var p = new Promise(function(resolve, reject) {
        request = obj[method].apply(obj, args);
        promisifyRequest(request).then(resolve, reject);
      });

      p.request = request;
      return p;
    }

    function promisifyCursorRequestCall(obj, method, args) {
      var p = promisifyRequestCall(obj, method, args);
      return p.then(function(value) {
        if (!value) return;
        return new Cursor(value, p.request);
      });
    }

    function proxyProperties(ProxyClass, targetProp, properties) {
      properties.forEach(function(prop) {
        Object.defineProperty(ProxyClass.prototype, prop, {
          get: function() {
            return this[targetProp][prop];
          },
          set: function(val) {
            this[targetProp][prop] = val;
          }
        });
      });
    }

    function proxyRequestMethods(ProxyClass, targetProp, Constructor, properties) {
      properties.forEach(function(prop) {
        if (!(prop in Constructor.prototype)) return;
        ProxyClass.prototype[prop] = function() {
          return promisifyRequestCall(this[targetProp], prop, arguments);
        };
      });
    }

    function proxyMethods(ProxyClass, targetProp, Constructor, properties) {
      properties.forEach(function(prop) {
        if (!(prop in Constructor.prototype)) return;
        ProxyClass.prototype[prop] = function() {
          return this[targetProp][prop].apply(this[targetProp], arguments);
        };
      });
    }

    function proxyCursorRequestMethods(ProxyClass, targetProp, Constructor, properties) {
      properties.forEach(function(prop) {
        if (!(prop in Constructor.prototype)) return;
        ProxyClass.prototype[prop] = function() {
          return promisifyCursorRequestCall(this[targetProp], prop, arguments);
        };
      });
    }

    function Index(index) {
      this._index = index;
    }

    proxyProperties(Index, '_index', [
      'name',
      'keyPath',
      'multiEntry',
      'unique'
    ]);

    proxyRequestMethods(Index, '_index', IDBIndex, [
      'get',
      'getKey',
      'getAll',
      'getAllKeys',
      'count'
    ]);

    proxyCursorRequestMethods(Index, '_index', IDBIndex, [
      'openCursor',
      'openKeyCursor'
    ]);

    function Cursor(cursor, request) {
      this._cursor = cursor;
      this._request = request;
    }

    proxyProperties(Cursor, '_cursor', [
      'direction',
      'key',
      'primaryKey',
      'value'
    ]);

    proxyRequestMethods(Cursor, '_cursor', IDBCursor, [
      'update',
      'delete'
    ]);

    // proxy 'next' methods
    ['advance', 'continue', 'continuePrimaryKey'].forEach(function(methodName) {
      if (!(methodName in IDBCursor.prototype)) return;
      Cursor.prototype[methodName] = function() {
        var cursor = this;
        var args = arguments;
        return Promise.resolve().then(function() {
          cursor._cursor[methodName].apply(cursor._cursor, args);
          return promisifyRequest(cursor._request).then(function(value) {
            if (!value) return;
            return new Cursor(value, cursor._request);
          });
        });
      };
    });

    function ObjectStore(store) {
      this._store = store;
    }

    ObjectStore.prototype.createIndex = function() {
      return new Index(this._store.createIndex.apply(this._store, arguments));
    };

    ObjectStore.prototype.index = function() {
      return new Index(this._store.index.apply(this._store, arguments));
    };

    proxyProperties(ObjectStore, '_store', [
      'name',
      'keyPath',
      'indexNames',
      'autoIncrement'
    ]);

    proxyRequestMethods(ObjectStore, '_store', IDBObjectStore, [
      'put',
      'add',
      'delete',
      'clear',
      'get',
      'getAll',
      'getKey',
      'getAllKeys',
      'count'
    ]);

    proxyCursorRequestMethods(ObjectStore, '_store', IDBObjectStore, [
      'openCursor',
      'openKeyCursor'
    ]);

    proxyMethods(ObjectStore, '_store', IDBObjectStore, [
      'deleteIndex'
    ]);

    function Transaction(idbTransaction) {
      this._tx = idbTransaction;
      this.complete = new Promise(function(resolve, reject) {
        idbTransaction.oncomplete = function() {
          resolve();
        };
        idbTransaction.onerror = function() {
          reject(idbTransaction.error);
        };
        idbTransaction.onabort = function() {
          reject(idbTransaction.error);
        };
      });
    }

    Transaction.prototype.objectStore = function() {
      return new ObjectStore(this._tx.objectStore.apply(this._tx, arguments));
    };

    proxyProperties(Transaction, '_tx', [
      'objectStoreNames',
      'mode'
    ]);

    proxyMethods(Transaction, '_tx', IDBTransaction, [
      'abort'
    ]);

    function UpgradeDB(db, oldVersion, transaction) {
      this._db = db;
      this.oldVersion = oldVersion;
      this.transaction = new Transaction(transaction);
    }

    UpgradeDB.prototype.createObjectStore = function() {
      return new ObjectStore(this._db.createObjectStore.apply(this._db, arguments));
    };

    proxyProperties(UpgradeDB, '_db', [
      'name',
      'version',
      'objectStoreNames'
    ]);

    proxyMethods(UpgradeDB, '_db', IDBDatabase, [
      'deleteObjectStore',
      'close'
    ]);

    function DB(db) {
      this._db = db;
    }

    DB.prototype.transaction = function() {
      return new Transaction(this._db.transaction.apply(this._db, arguments));
    };

    proxyProperties(DB, '_db', [
      'name',
      'version',
      'objectStoreNames'
    ]);

    proxyMethods(DB, '_db', IDBDatabase, [
      'close'
    ]);

    // Add cursor iterators
    // TODO: remove this once browsers do the right thing with promises
    ['openCursor', 'openKeyCursor'].forEach(function(funcName) {
      [ObjectStore, Index].forEach(function(Constructor) {
        // Don't create iterateKeyCursor if openKeyCursor doesn't exist.
        if (!(funcName in Constructor.prototype)) return;

        Constructor.prototype[funcName.replace('open', 'iterate')] = function() {
          var args = toArray(arguments);
          var callback = args[args.length - 1];
          var nativeObject = this._store || this._index;
          var request = nativeObject[funcName].apply(nativeObject, args.slice(0, -1));
          request.onsuccess = function() {
            callback(request.result);
          };
        };
      });
    });

    // polyfill getAll
    [Index, ObjectStore].forEach(function(Constructor) {
      if (Constructor.prototype.getAll) return;
      Constructor.prototype.getAll = function(query, count) {
        var instance = this;
        var items = [];

        return new Promise(function(resolve) {
          instance.iterateCursor(query, function(cursor) {
            if (!cursor) {
              resolve(items);
              return;
            }
            items.push(cursor.value);

            if (count !== undefined && items.length == count) {
              resolve(items);
              return;
            }
            cursor.continue();
          });
        });
      };
    });

    function openDb(name, version, upgradeCallback) {
      var p = promisifyRequestCall(indexedDB, 'open', [name, version]);
      var request = p.request;

      if (request) {
        request.onupgradeneeded = function(event) {
          if (upgradeCallback) {
            upgradeCallback(new UpgradeDB(request.result, event.oldVersion, request.transaction));
          }
        };
      }

      return p.then(function(db) {
        return new DB(db);
      });
    }

    const name$1 = "@firebase/installations-exp";
    const version$1 = "0.0.900-exp.6ef484a04";

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const PENDING_TIMEOUT_MS = 10000;
    const PACKAGE_VERSION = `w:${version$1}`;
    const INTERNAL_AUTH_VERSION = 'FIS_v2';
    const INSTALLATIONS_API_URL = 'https://firebaseinstallations.googleapis.com/v1';
    const TOKEN_EXPIRATION_BUFFER = 60 * 60 * 1000; // One hour
    const SERVICE = 'installations';
    const SERVICE_NAME = 'Installations';

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const ERROR_DESCRIPTION_MAP$1 = {
        ["missing-app-config-values" /* MISSING_APP_CONFIG_VALUES */]: 'Missing App configuration value: "{$valueName}"',
        ["not-registered" /* NOT_REGISTERED */]: 'Firebase Installation is not registered.',
        ["installation-not-found" /* INSTALLATION_NOT_FOUND */]: 'Firebase Installation not found.',
        ["request-failed" /* REQUEST_FAILED */]: '{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',
        ["app-offline" /* APP_OFFLINE */]: 'Could not process request. Application offline.',
        ["delete-pending-registration" /* DELETE_PENDING_REGISTRATION */]: "Can't delete installation while there is a pending registration request."
    };
    const ERROR_FACTORY$1 = new ErrorFactory(SERVICE, SERVICE_NAME, ERROR_DESCRIPTION_MAP$1);
    /** Returns true if error is a FirebaseError that is based on an error from the server. */
    function isServerError(error) {
        return (error instanceof FirebaseError &&
            error.code.includes("request-failed" /* REQUEST_FAILED */));
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    function getInstallationsEndpoint({ projectId }) {
        return `${INSTALLATIONS_API_URL}/projects/${projectId}/installations`;
    }
    function extractAuthTokenInfoFromResponse(response) {
        return {
            token: response.token,
            requestStatus: 2 /* COMPLETED */,
            expiresIn: getExpiresInFromResponseExpiresIn(response.expiresIn),
            creationTime: Date.now()
        };
    }
    async function getErrorFromResponse(requestName, response) {
        const responseJson = await response.json();
        const errorData = responseJson.error;
        return ERROR_FACTORY$1.create("request-failed" /* REQUEST_FAILED */, {
            requestName,
            serverCode: errorData.code,
            serverMessage: errorData.message,
            serverStatus: errorData.status
        });
    }
    function getHeaders({ apiKey }) {
        return new Headers({
            'Content-Type': 'application/json',
            Accept: 'application/json',
            'x-goog-api-key': apiKey
        });
    }
    function getHeadersWithAuth(appConfig, { refreshToken }) {
        const headers = getHeaders(appConfig);
        headers.append('Authorization', getAuthorizationHeader(refreshToken));
        return headers;
    }
    /**
     * Calls the passed in fetch wrapper and returns the response.
     * If the returned response has a status of 5xx, re-runs the function once and
     * returns the response.
     */
    async function retryIfServerError(fn) {
        const result = await fn();
        if (result.status >= 500 && result.status < 600) {
            // Internal Server Error. Retry request.
            return fn();
        }
        return result;
    }
    function getExpiresInFromResponseExpiresIn(responseExpiresIn) {
        // This works because the server will never respond with fractions of a second.
        return Number(responseExpiresIn.replace('s', '000'));
    }
    function getAuthorizationHeader(refreshToken) {
        return `${INTERNAL_AUTH_VERSION} ${refreshToken}`;
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    async function createInstallationRequest(appConfig, { fid }) {
        const endpoint = getInstallationsEndpoint(appConfig);
        const headers = getHeaders(appConfig);
        const body = {
            fid,
            authVersion: INTERNAL_AUTH_VERSION,
            appId: appConfig.appId,
            sdkVersion: PACKAGE_VERSION
        };
        const request = {
            method: 'POST',
            headers,
            body: JSON.stringify(body)
        };
        const response = await retryIfServerError(() => fetch(endpoint, request));
        if (response.ok) {
            const responseValue = await response.json();
            const registeredInstallationEntry = {
                fid: responseValue.fid || fid,
                registrationStatus: 2 /* COMPLETED */,
                refreshToken: responseValue.refreshToken,
                authToken: extractAuthTokenInfoFromResponse(responseValue.authToken)
            };
            return registeredInstallationEntry;
        }
        else {
            throw await getErrorFromResponse('Create Installation', response);
        }
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /** Returns a promise that resolves after given time passes. */
    function sleep(ms) {
        return new Promise(resolve => {
            setTimeout(resolve, ms);
        });
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    function bufferToBase64UrlSafe(array) {
        const b64 = btoa(String.fromCharCode(...array));
        return b64.replace(/\+/g, '-').replace(/\//g, '_');
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const VALID_FID_PATTERN = /^[cdef][\w-]{21}$/;
    const INVALID_FID = '';
    /**
     * Generates a new FID using random values from Web Crypto API.
     * Returns an empty string if FID generation fails for any reason.
     */
    function generateFid() {
        try {
            // A valid FID has exactly 22 base64 characters, which is 132 bits, or 16.5
            // bytes. our implementation generates a 17 byte array instead.
            const fidByteArray = new Uint8Array(17);
            const crypto = self.crypto || self.msCrypto;
            crypto.getRandomValues(fidByteArray);
            // Replace the first 4 random bits with the constant FID header of 0b0111.
            fidByteArray[0] = 0b01110000 + (fidByteArray[0] % 0b00010000);
            const fid = encode(fidByteArray);
            return VALID_FID_PATTERN.test(fid) ? fid : INVALID_FID;
        }
        catch (_a) {
            // FID generation errored
            return INVALID_FID;
        }
    }
    /** Converts a FID Uint8Array to a base64 string representation. */
    function encode(fidByteArray) {
        const b64String = bufferToBase64UrlSafe(fidByteArray);
        // Remove the 23rd character that was added because of the extra 4 bits at the
        // end of our 17 byte array, and the '=' padding.
        return b64String.substr(0, 22);
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /** Returns a string key that can be used to identify the app. */
    function getKey(appConfig) {
        return `${appConfig.appName}!${appConfig.appId}`;
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const fidChangeCallbacks = new Map();
    /**
     * Calls the onIdChange callbacks with the new FID value, and broadcasts the
     * change to other tabs.
     */
    function fidChanged(appConfig, fid) {
        const key = getKey(appConfig);
        callFidChangeCallbacks(key, fid);
        broadcastFidChange(key, fid);
    }
    function callFidChangeCallbacks(key, fid) {
        const callbacks = fidChangeCallbacks.get(key);
        if (!callbacks) {
            return;
        }
        for (const callback of callbacks) {
            callback(fid);
        }
    }
    function broadcastFidChange(key, fid) {
        const channel = getBroadcastChannel();
        if (channel) {
            channel.postMessage({ key, fid });
        }
        closeBroadcastChannel();
    }
    let broadcastChannel = null;
    /** Opens and returns a BroadcastChannel if it is supported by the browser. */
    function getBroadcastChannel() {
        if (!broadcastChannel && 'BroadcastChannel' in self) {
            broadcastChannel = new BroadcastChannel('[Firebase] FID Change');
            broadcastChannel.onmessage = e => {
                callFidChangeCallbacks(e.data.key, e.data.fid);
            };
        }
        return broadcastChannel;
    }
    function closeBroadcastChannel() {
        if (fidChangeCallbacks.size === 0 && broadcastChannel) {
            broadcastChannel.close();
            broadcastChannel = null;
        }
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const DATABASE_NAME = 'firebase-installations-database';
    const DATABASE_VERSION = 1;
    const OBJECT_STORE_NAME = 'firebase-installations-store';
    let dbPromise = null;
    function getDbPromise() {
        if (!dbPromise) {
            dbPromise = openDb(DATABASE_NAME, DATABASE_VERSION, upgradeDB => {
                // We don't use 'break' in this switch statement, the fall-through
                // behavior is what we want, because if there are multiple versions between
                // the old version and the current version, we want ALL the migrations
                // that correspond to those versions to run, not only the last one.
                // eslint-disable-next-line default-case
                switch (upgradeDB.oldVersion) {
                    case 0:
                        upgradeDB.createObjectStore(OBJECT_STORE_NAME);
                }
            });
        }
        return dbPromise;
    }
    /** Assigns or overwrites the record for the given key with the given value. */
    async function set(appConfig, value) {
        const key = getKey(appConfig);
        const db = await getDbPromise();
        const tx = db.transaction(OBJECT_STORE_NAME, 'readwrite');
        const objectStore = tx.objectStore(OBJECT_STORE_NAME);
        const oldValue = await objectStore.get(key);
        await objectStore.put(value, key);
        await tx.complete;
        if (!oldValue || oldValue.fid !== value.fid) {
            fidChanged(appConfig, value.fid);
        }
        return value;
    }
    /** Removes record(s) from the objectStore that match the given key. */
    async function remove(appConfig) {
        const key = getKey(appConfig);
        const db = await getDbPromise();
        const tx = db.transaction(OBJECT_STORE_NAME, 'readwrite');
        await tx.objectStore(OBJECT_STORE_NAME).delete(key);
        await tx.complete;
    }
    /**
     * Atomically updates a record with the result of updateFn, which gets
     * called with the current value. If newValue is undefined, the record is
     * deleted instead.
     * @return Updated value
     */
    async function update(appConfig, updateFn) {
        const key = getKey(appConfig);
        const db = await getDbPromise();
        const tx = db.transaction(OBJECT_STORE_NAME, 'readwrite');
        const store = tx.objectStore(OBJECT_STORE_NAME);
        const oldValue = await store.get(key);
        const newValue = updateFn(oldValue);
        if (newValue === undefined) {
            await store.delete(key);
        }
        else {
            await store.put(newValue, key);
        }
        await tx.complete;
        if (newValue && (!oldValue || oldValue.fid !== newValue.fid)) {
            fidChanged(appConfig, newValue.fid);
        }
        return newValue;
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Updates and returns the InstallationEntry from the database.
     * Also triggers a registration request if it is necessary and possible.
     */
    async function getInstallationEntry(appConfig) {
        let registrationPromise;
        const installationEntry = await update(appConfig, oldEntry => {
            const installationEntry = updateOrCreateInstallationEntry(oldEntry);
            const entryWithPromise = triggerRegistrationIfNecessary(appConfig, installationEntry);
            registrationPromise = entryWithPromise.registrationPromise;
            return entryWithPromise.installationEntry;
        });
        if (installationEntry.fid === INVALID_FID) {
            // FID generation failed. Waiting for the FID from the server.
            return { installationEntry: await registrationPromise };
        }
        return {
            installationEntry,
            registrationPromise
        };
    }
    /**
     * Creates a new Installation Entry if one does not exist.
     * Also clears timed out pending requests.
     */
    function updateOrCreateInstallationEntry(oldEntry) {
        const entry = oldEntry || {
            fid: generateFid(),
            registrationStatus: 0 /* NOT_STARTED */
        };
        return clearTimedOutRequest(entry);
    }
    /**
     * If the Firebase Installation is not registered yet, this will trigger the
     * registration and return an InProgressInstallationEntry.
     *
     * If registrationPromise does not exist, the installationEntry is guaranteed
     * to be registered.
     */
    function triggerRegistrationIfNecessary(appConfig, installationEntry) {
        if (installationEntry.registrationStatus === 0 /* NOT_STARTED */) {
            if (!navigator.onLine) {
                // Registration required but app is offline.
                const registrationPromiseWithError = Promise.reject(ERROR_FACTORY$1.create("app-offline" /* APP_OFFLINE */));
                return {
                    installationEntry,
                    registrationPromise: registrationPromiseWithError
                };
            }
            // Try registering. Change status to IN_PROGRESS.
            const inProgressEntry = {
                fid: installationEntry.fid,
                registrationStatus: 1 /* IN_PROGRESS */,
                registrationTime: Date.now()
            };
            const registrationPromise = registerInstallation(appConfig, inProgressEntry);
            return { installationEntry: inProgressEntry, registrationPromise };
        }
        else if (installationEntry.registrationStatus === 1 /* IN_PROGRESS */) {
            return {
                installationEntry,
                registrationPromise: waitUntilFidRegistration(appConfig)
            };
        }
        else {
            return { installationEntry };
        }
    }
    /** This will be executed only once for each new Firebase Installation. */
    async function registerInstallation(appConfig, installationEntry) {
        try {
            const registeredInstallationEntry = await createInstallationRequest(appConfig, installationEntry);
            return set(appConfig, registeredInstallationEntry);
        }
        catch (e) {
            if (isServerError(e) && e.customData.serverCode === 409) {
                // Server returned a "FID can not be used" error.
                // Generate a new ID next time.
                await remove(appConfig);
            }
            else {
                // Registration failed. Set FID as not registered.
                await set(appConfig, {
                    fid: installationEntry.fid,
                    registrationStatus: 0 /* NOT_STARTED */
                });
            }
            throw e;
        }
    }
    /** Call if FID registration is pending in another request. */
    async function waitUntilFidRegistration(appConfig) {
        // Unfortunately, there is no way of reliably observing when a value in
        // IndexedDB changes (yet, see https://github.com/WICG/indexed-db-observers),
        // so we need to poll.
        let entry = await updateInstallationRequest(appConfig);
        while (entry.registrationStatus === 1 /* IN_PROGRESS */) {
            // createInstallation request still in progress.
            await sleep(100);
            entry = await updateInstallationRequest(appConfig);
        }
        if (entry.registrationStatus === 0 /* NOT_STARTED */) {
            // The request timed out or failed in a different call. Try again.
            const { installationEntry, registrationPromise } = await getInstallationEntry(appConfig);
            if (registrationPromise) {
                return registrationPromise;
            }
            else {
                // if there is no registrationPromise, entry is registered.
                return installationEntry;
            }
        }
        return entry;
    }
    /**
     * Called only if there is a CreateInstallation request in progress.
     *
     * Updates the InstallationEntry in the DB based on the status of the
     * CreateInstallation request.
     *
     * Returns the updated InstallationEntry.
     */
    function updateInstallationRequest(appConfig) {
        return update(appConfig, oldEntry => {
            if (!oldEntry) {
                throw ERROR_FACTORY$1.create("installation-not-found" /* INSTALLATION_NOT_FOUND */);
            }
            return clearTimedOutRequest(oldEntry);
        });
    }
    function clearTimedOutRequest(entry) {
        if (hasInstallationRequestTimedOut(entry)) {
            return {
                fid: entry.fid,
                registrationStatus: 0 /* NOT_STARTED */
            };
        }
        return entry;
    }
    function hasInstallationRequestTimedOut(installationEntry) {
        return (installationEntry.registrationStatus === 1 /* IN_PROGRESS */ &&
            installationEntry.registrationTime + PENDING_TIMEOUT_MS < Date.now());
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    async function generateAuthTokenRequest({ appConfig, platformLoggerProvider }, installationEntry) {
        const endpoint = getGenerateAuthTokenEndpoint(appConfig, installationEntry);
        const headers = getHeadersWithAuth(appConfig, installationEntry);
        // If platform logger exists, add the platform info string to the header.
        const platformLogger = platformLoggerProvider.getImmediate({
            optional: true
        });
        if (platformLogger) {
            headers.append('x-firebase-client', platformLogger.getPlatformInfoString());
        }
        const body = {
            installation: {
                sdkVersion: PACKAGE_VERSION
            }
        };
        const request = {
            method: 'POST',
            headers,
            body: JSON.stringify(body)
        };
        const response = await retryIfServerError(() => fetch(endpoint, request));
        if (response.ok) {
            const responseValue = await response.json();
            const completedAuthToken = extractAuthTokenInfoFromResponse(responseValue);
            return completedAuthToken;
        }
        else {
            throw await getErrorFromResponse('Generate Auth Token', response);
        }
    }
    function getGenerateAuthTokenEndpoint(appConfig, { fid }) {
        return `${getInstallationsEndpoint(appConfig)}/${fid}/authTokens:generate`;
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Returns a valid authentication token for the installation. Generates a new
     * token if one doesn't exist, is expired or about to expire.
     *
     * Should only be called if the Firebase Installation is registered.
     */
    async function refreshAuthToken(installations, forceRefresh = false) {
        let tokenPromise;
        const entry = await update(installations.appConfig, oldEntry => {
            if (!isEntryRegistered(oldEntry)) {
                throw ERROR_FACTORY$1.create("not-registered" /* NOT_REGISTERED */);
            }
            const oldAuthToken = oldEntry.authToken;
            if (!forceRefresh && isAuthTokenValid(oldAuthToken)) {
                // There is a valid token in the DB.
                return oldEntry;
            }
            else if (oldAuthToken.requestStatus === 1 /* IN_PROGRESS */) {
                // There already is a token request in progress.
                tokenPromise = waitUntilAuthTokenRequest(installations, forceRefresh);
                return oldEntry;
            }
            else {
                // No token or token expired.
                if (!navigator.onLine) {
                    throw ERROR_FACTORY$1.create("app-offline" /* APP_OFFLINE */);
                }
                const inProgressEntry = makeAuthTokenRequestInProgressEntry(oldEntry);
                tokenPromise = fetchAuthTokenFromServer(installations, inProgressEntry);
                return inProgressEntry;
            }
        });
        const authToken = tokenPromise
            ? await tokenPromise
            : entry.authToken;
        return authToken;
    }
    /**
     * Call only if FID is registered and Auth Token request is in progress.
     *
     * Waits until the current pending request finishes. If the request times out,
     * tries once in this thread as well.
     */
    async function waitUntilAuthTokenRequest(installations, forceRefresh) {
        // Unfortunately, there is no way of reliably observing when a value in
        // IndexedDB changes (yet, see https://github.com/WICG/indexed-db-observers),
        // so we need to poll.
        let entry = await updateAuthTokenRequest(installations.appConfig);
        while (entry.authToken.requestStatus === 1 /* IN_PROGRESS */) {
            // generateAuthToken still in progress.
            await sleep(100);
            entry = await updateAuthTokenRequest(installations.appConfig);
        }
        const authToken = entry.authToken;
        if (authToken.requestStatus === 0 /* NOT_STARTED */) {
            // The request timed out or failed in a different call. Try again.
            return refreshAuthToken(installations, forceRefresh);
        }
        else {
            return authToken;
        }
    }
    /**
     * Called only if there is a GenerateAuthToken request in progress.
     *
     * Updates the InstallationEntry in the DB based on the status of the
     * GenerateAuthToken request.
     *
     * Returns the updated InstallationEntry.
     */
    function updateAuthTokenRequest(appConfig) {
        return update(appConfig, oldEntry => {
            if (!isEntryRegistered(oldEntry)) {
                throw ERROR_FACTORY$1.create("not-registered" /* NOT_REGISTERED */);
            }
            const oldAuthToken = oldEntry.authToken;
            if (hasAuthTokenRequestTimedOut(oldAuthToken)) {
                return Object.assign(Object.assign({}, oldEntry), { authToken: { requestStatus: 0 /* NOT_STARTED */ } });
            }
            return oldEntry;
        });
    }
    async function fetchAuthTokenFromServer(installations, installationEntry) {
        try {
            const authToken = await generateAuthTokenRequest(installations, installationEntry);
            const updatedInstallationEntry = Object.assign(Object.assign({}, installationEntry), { authToken });
            await set(installations.appConfig, updatedInstallationEntry);
            return authToken;
        }
        catch (e) {
            if (isServerError(e) &&
                (e.customData.serverCode === 401 || e.customData.serverCode === 404)) {
                // Server returned a "FID not found" or a "Invalid authentication" error.
                // Generate a new ID next time.
                await remove(installations.appConfig);
            }
            else {
                const updatedInstallationEntry = Object.assign(Object.assign({}, installationEntry), { authToken: { requestStatus: 0 /* NOT_STARTED */ } });
                await set(installations.appConfig, updatedInstallationEntry);
            }
            throw e;
        }
    }
    function isEntryRegistered(installationEntry) {
        return (installationEntry !== undefined &&
            installationEntry.registrationStatus === 2 /* COMPLETED */);
    }
    function isAuthTokenValid(authToken) {
        return (authToken.requestStatus === 2 /* COMPLETED */ &&
            !isAuthTokenExpired(authToken));
    }
    function isAuthTokenExpired(authToken) {
        const now = Date.now();
        return (now < authToken.creationTime ||
            authToken.creationTime + authToken.expiresIn < now + TOKEN_EXPIRATION_BUFFER);
    }
    /** Returns an updated InstallationEntry with an InProgressAuthToken. */
    function makeAuthTokenRequestInProgressEntry(oldEntry) {
        const inProgressAuthToken = {
            requestStatus: 1 /* IN_PROGRESS */,
            requestTime: Date.now()
        };
        return Object.assign(Object.assign({}, oldEntry), { authToken: inProgressAuthToken });
    }
    function hasAuthTokenRequestTimedOut(authToken) {
        return (authToken.requestStatus === 1 /* IN_PROGRESS */ &&
            authToken.requestTime + PENDING_TIMEOUT_MS < Date.now());
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Creates a Firebase Installation if there isn't one for the app and
     * returns the Installation ID.
     * @param installations - The `Installations` instance.
     *
     * @public
     */
    async function getId(installations) {
        const installationsImpl = installations;
        const { installationEntry, registrationPromise } = await getInstallationEntry(installationsImpl.appConfig);
        if (registrationPromise) {
            registrationPromise.catch(console.error);
        }
        else {
            // If the installation is already registered, update the authentication
            // token if needed.
            refreshAuthToken(installationsImpl).catch(console.error);
        }
        return installationEntry.fid;
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Returns an Installation auth token, identifying the current Firebase Installation.
     * @param installations - The `Installations` instance.
     * @param forceRefresh - Force refresh regardless of token expiration.
     *
     * @public
     */
    async function getToken(installations, forceRefresh = false) {
        const installationsImpl = installations;
        await completeInstallationRegistration(installationsImpl.appConfig);
        // At this point we either have a Registered Installation in the DB, or we've
        // already thrown an error.
        const authToken = await refreshAuthToken(installationsImpl, forceRefresh);
        return authToken.token;
    }
    async function completeInstallationRegistration(appConfig) {
        const { registrationPromise } = await getInstallationEntry(appConfig);
        if (registrationPromise) {
            // A createInstallation request is in progress. Wait until it finishes.
            await registrationPromise;
        }
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    function extractAppConfig(app) {
        if (!app || !app.options) {
            throw getMissingValueError('App Configuration');
        }
        if (!app.name) {
            throw getMissingValueError('App Name');
        }
        // Required app config keys
        const configKeys = [
            'projectId',
            'apiKey',
            'appId'
        ];
        for (const keyName of configKeys) {
            if (!app.options[keyName]) {
                throw getMissingValueError(keyName);
            }
        }
        return {
            appName: app.name,
            projectId: app.options.projectId,
            apiKey: app.options.apiKey,
            appId: app.options.appId
        };
    }
    function getMissingValueError(valueName) {
        return ERROR_FACTORY$1.create("missing-app-config-values" /* MISSING_APP_CONFIG_VALUES */, {
            valueName
        });
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const INSTALLATIONS_NAME = 'installations-exp';
    const INSTALLATIONS_NAME_INTERNAL = 'installations-exp-internal';
    const publicFactory = (container) => {
        const app = container.getProvider('app-exp').getImmediate();
        // Throws if app isn't configured properly.
        const appConfig = extractAppConfig(app);
        const platformLoggerProvider = _getProvider(app, 'platform-logger');
        const installationsImpl = {
            app,
            appConfig,
            platformLoggerProvider,
            _delete: () => Promise.resolve()
        };
        return installationsImpl;
    };
    const internalFactory = (container) => {
        const app = container.getProvider('app-exp').getImmediate();
        // Internal FIS instance relies on public FIS instance.
        const installations = _getProvider(app, INSTALLATIONS_NAME).getImmediate();
        const installationsInternal = {
            getId: () => getId(installations),
            getToken: (forceRefresh) => getToken(installations, forceRefresh)
        };
        return installationsInternal;
    };
    function registerInstallations() {
        _registerComponent(new Component(INSTALLATIONS_NAME, publicFactory, "PUBLIC" /* PUBLIC */));
        _registerComponent(new Component(INSTALLATIONS_NAME_INTERNAL, internalFactory, "PRIVATE" /* PRIVATE */));
    }

    /**
     * Firebase Installations
     *
     * @packageDocumentation
     */
    registerInstallations();
    registerVersion(name$1, version$1);

    const name = "@firebase/remote-config-exp";
    const version = "0.0.900-exp.6ef484a04";

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Shims a minimal AbortSignal.
     *
     * <p>AbortController's AbortSignal conveniently decouples fetch timeout logic from other aspects
     * of networking, such as retries. Firebase doesn't use AbortController enough to justify a
     * polyfill recommendation, like we do with the Fetch API, but this minimal shim can easily be
     * swapped out if/when we do.
     */
    class RemoteConfigAbortSignal {
        constructor() {
            this.listeners = [];
        }
        addEventListener(listener) {
            this.listeners.push(listener);
        }
        abort() {
            this.listeners.forEach(listener => listener());
        }
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const RC_COMPONENT_NAME = 'remote-config-exp';

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const ERROR_DESCRIPTION_MAP = {
        ["registration-window" /* REGISTRATION_WINDOW */]: 'Undefined window object. This SDK only supports usage in a browser environment.',
        ["registration-project-id" /* REGISTRATION_PROJECT_ID */]: 'Undefined project identifier. Check Firebase app initialization.',
        ["registration-api-key" /* REGISTRATION_API_KEY */]: 'Undefined API key. Check Firebase app initialization.',
        ["registration-app-id" /* REGISTRATION_APP_ID */]: 'Undefined app identifier. Check Firebase app initialization.',
        ["storage-open" /* STORAGE_OPEN */]: 'Error thrown when opening storage. Original error: {$originalErrorMessage}.',
        ["storage-get" /* STORAGE_GET */]: 'Error thrown when reading from storage. Original error: {$originalErrorMessage}.',
        ["storage-set" /* STORAGE_SET */]: 'Error thrown when writing to storage. Original error: {$originalErrorMessage}.',
        ["storage-delete" /* STORAGE_DELETE */]: 'Error thrown when deleting from storage. Original error: {$originalErrorMessage}.',
        ["fetch-client-network" /* FETCH_NETWORK */]: 'Fetch client failed to connect to a network. Check Internet connection.' +
            ' Original error: {$originalErrorMessage}.',
        ["fetch-timeout" /* FETCH_TIMEOUT */]: 'The config fetch request timed out. ' +
            ' Configure timeout using "fetchTimeoutMillis" SDK setting.',
        ["fetch-throttle" /* FETCH_THROTTLE */]: 'The config fetch request timed out while in an exponential backoff state.' +
            ' Configure timeout using "fetchTimeoutMillis" SDK setting.' +
            ' Unix timestamp in milliseconds when fetch request throttling ends: {$throttleEndTimeMillis}.',
        ["fetch-client-parse" /* FETCH_PARSE */]: 'Fetch client could not parse response.' +
            ' Original error: {$originalErrorMessage}.',
        ["fetch-status" /* FETCH_STATUS */]: 'Fetch server returned an HTTP error status. HTTP status: {$httpStatus}.'
    };
    const ERROR_FACTORY = new ErrorFactory('remoteconfig' /* service */, 'Remote Config' /* service name */, ERROR_DESCRIPTION_MAP);
    // Note how this is like typeof/instanceof, but for ErrorCode.
    function hasErrorCode(e, errorCode) {
        return e instanceof FirebaseError && e.code.indexOf(errorCode) !== -1;
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const DEFAULT_VALUE_FOR_BOOLEAN = false;
    const DEFAULT_VALUE_FOR_STRING = '';
    const DEFAULT_VALUE_FOR_NUMBER = 0;
    const BOOLEAN_TRUTHY_VALUES = ['1', 'true', 't', 'yes', 'y', 'on'];
    class Value {
        constructor(_source, _value = DEFAULT_VALUE_FOR_STRING) {
            this._source = _source;
            this._value = _value;
        }
        asString() {
            return this._value;
        }
        asBoolean() {
            if (this._source === 'static') {
                return DEFAULT_VALUE_FOR_BOOLEAN;
            }
            return BOOLEAN_TRUTHY_VALUES.indexOf(this._value.toLowerCase()) >= 0;
        }
        asNumber() {
            if (this._source === 'static') {
                return DEFAULT_VALUE_FOR_NUMBER;
            }
            let num = Number(this._value);
            if (isNaN(num)) {
                num = DEFAULT_VALUE_FOR_NUMBER;
            }
            return num;
        }
        getSource() {
            return this._source;
        }
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     *
     * @param app - The `FirebaseApp` instance.
     * @returns A `RemoteConfig` instance.
     *
     * @public
     */
    function getRemoteConfig(app = getApp()) {
        app = getModularInstance(app);
        const rcProvider = _getProvider(app, RC_COMPONENT_NAME);
        return rcProvider.getImmediate();
    }
    /**
     * Makes the last fetched config available to the getters.
     * @param remoteConfig - The `RemoteConfig` instance.
     * @returns A promise which resolves to true if the current call activated the fetched configs.
     * If the fetched configs were already activated, the promise will resolve to false.
     *
     * @public
     */
    async function activate(remoteConfig) {
        const rc = getModularInstance(remoteConfig);
        const [lastSuccessfulFetchResponse, activeConfigEtag] = await Promise.all([
            rc._storage.getLastSuccessfulFetchResponse(),
            rc._storage.getActiveConfigEtag()
        ]);
        if (!lastSuccessfulFetchResponse ||
            !lastSuccessfulFetchResponse.config ||
            !lastSuccessfulFetchResponse.eTag ||
            lastSuccessfulFetchResponse.eTag === activeConfigEtag) {
            // Either there is no successful fetched config, or is the same as current active
            // config.
            return false;
        }
        await Promise.all([
            rc._storageCache.setActiveConfig(lastSuccessfulFetchResponse.config),
            rc._storage.setActiveConfigEtag(lastSuccessfulFetchResponse.eTag)
        ]);
        return true;
    }
    /**
     * Ensures the last activated config are available to the getters.
     * @param remoteConfig - The `RemoteConfig` instance.
     *
     * @returns A promise that resolves when the last activated config is available to the getters.
     * @public
     */
    function ensureInitialized(remoteConfig) {
        const rc = getModularInstance(remoteConfig);
        if (!rc._initializePromise) {
            rc._initializePromise = rc._storageCache.loadFromStorage().then(() => {
                rc._isInitializationComplete = true;
            });
        }
        return rc._initializePromise;
    }
    /**
     * Fetches and caches configuration from the Remote Config service.
     * @param remoteConfig - The `RemoteConfig` instance.
     * @public
     */
    async function fetchConfig(remoteConfig) {
        const rc = getModularInstance(remoteConfig);
        // Aborts the request after the given timeout, causing the fetch call to
        // reject with an AbortError.
        //
        // <p>Aborting after the request completes is a no-op, so we don't need a
        // corresponding clearTimeout.
        //
        // Locating abort logic here because:
        // * it uses a developer setting (timeout)
        // * it applies to all retries (like curl's max-time arg)
        // * it is consistent with the Fetch API's signal input
        const abortSignal = new RemoteConfigAbortSignal();
        setTimeout(async () => {
            // Note a very low delay, eg < 10ms, can elapse before listeners are initialized.
            abortSignal.abort();
        }, rc.settings.fetchTimeoutMillis);
        // Catches *all* errors thrown by client so status can be set consistently.
        try {
            await rc._client.fetch({
                cacheMaxAgeMillis: rc.settings.minimumFetchIntervalMillis,
                signal: abortSignal
            });
            await rc._storageCache.setLastFetchStatus('success');
        }
        catch (e) {
            const lastFetchStatus = hasErrorCode(e, "fetch-throttle" /* FETCH_THROTTLE */)
                ? 'throttle'
                : 'failure';
            await rc._storageCache.setLastFetchStatus(lastFetchStatus);
            throw e;
        }
    }
    /**
     * Gets the value for the given key as a string.
     * Convenience method for calling <code>remoteConfig.getValue(key).asString()</code>.
     *
     * @param remoteConfig - The `RemoteConfig` instance.
     * @param key - The name of the parameter.
     *
     * @returns The value for the given key as a string.
     *
     * @public
     */
    function getString(remoteConfig, key) {
        return getValue(getModularInstance(remoteConfig), key).asString();
    }
    /**
     * Gets the {@link Value} for the given key.
     *
     * @param remoteConfig - The `RemoteConfig` instance.
     * @param key - The name of the parameter.
     *
     * @returns The value for the given key.
     *
     * @public
     */
    function getValue(remoteConfig, key) {
        const rc = getModularInstance(remoteConfig);
        if (!rc._isInitializationComplete) {
            rc._logger.debug(`A value was requested for key "${key}" before SDK initialization completed.` +
                ' Await on ensureInitialized if the intent was to get a previously activated value.');
        }
        const activeConfig = rc._storageCache.getActiveConfig();
        if (activeConfig && activeConfig[key] !== undefined) {
            return new Value('remote', activeConfig[key]);
        }
        else if (rc.defaultConfig && rc.defaultConfig[key] !== undefined) {
            return new Value('default', String(rc.defaultConfig[key]));
        }
        rc._logger.debug(`Returning static value for key "${key}".` +
            ' Define a default or remote value if this is unintentional.');
        return new Value('static');
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Implements the {@link RemoteConfigClient} abstraction with success response caching.
     *
     * <p>Comparable to the browser's Cache API for responses, but the Cache API requires a Service
     * Worker, which requires HTTPS, which would significantly complicate SDK installation. Also, the
     * Cache API doesn't support matching entries by time.
     */
    class CachingClient {
        constructor(client, storage, storageCache, logger) {
            this.client = client;
            this.storage = storage;
            this.storageCache = storageCache;
            this.logger = logger;
        }
        /**
         * Returns true if the age of the cached fetched configs is less than or equal to
         * {@link Settings#minimumFetchIntervalInSeconds}.
         *
         * <p>This is comparable to passing `headers = { 'Cache-Control': max-age <maxAge> }` to the
         * native Fetch API.
         *
         * <p>Visible for testing.
         */
        isCachedDataFresh(cacheMaxAgeMillis, lastSuccessfulFetchTimestampMillis) {
            // Cache can only be fresh if it's populated.
            if (!lastSuccessfulFetchTimestampMillis) {
                this.logger.debug('Config fetch cache check. Cache unpopulated.');
                return false;
            }
            // Calculates age of cache entry.
            const cacheAgeMillis = Date.now() - lastSuccessfulFetchTimestampMillis;
            const isCachedDataFresh = cacheAgeMillis <= cacheMaxAgeMillis;
            this.logger.debug('Config fetch cache check.' +
                ` Cache age millis: ${cacheAgeMillis}.` +
                ` Cache max age millis (minimumFetchIntervalMillis setting): ${cacheMaxAgeMillis}.` +
                ` Is cache hit: ${isCachedDataFresh}.`);
            return isCachedDataFresh;
        }
        async fetch(request) {
            // Reads from persisted storage to avoid cache miss if callers don't wait on initialization.
            const [lastSuccessfulFetchTimestampMillis, lastSuccessfulFetchResponse] = await Promise.all([
                this.storage.getLastSuccessfulFetchTimestampMillis(),
                this.storage.getLastSuccessfulFetchResponse()
            ]);
            // Exits early on cache hit.
            if (lastSuccessfulFetchResponse &&
                this.isCachedDataFresh(request.cacheMaxAgeMillis, lastSuccessfulFetchTimestampMillis)) {
                return lastSuccessfulFetchResponse;
            }
            // Deviates from pure decorator by not honoring a passed ETag since we don't have a public API
            // that allows the caller to pass an ETag.
            request.eTag =
                lastSuccessfulFetchResponse && lastSuccessfulFetchResponse.eTag;
            // Falls back to service on cache miss.
            const response = await this.client.fetch(request);
            // Fetch throws for non-success responses, so success is guaranteed here.
            const storageOperations = [
                // Uses write-through cache for consistency with synchronous public API.
                this.storageCache.setLastSuccessfulFetchTimestampMillis(Date.now())
            ];
            if (response.status === 200) {
                // Caches response only if it has changed, ie non-304 responses.
                storageOperations.push(this.storage.setLastSuccessfulFetchResponse(response));
            }
            await Promise.all(storageOperations);
            return response;
        }
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Attempts to get the most accurate browser language setting.
     *
     * <p>Adapted from getUserLanguage in packages/auth/src/utils.js for TypeScript.
     *
     * <p>Defers default language specification to server logic for consistency.
     *
     * @param navigatorLanguage Enables tests to override read-only {@link NavigatorLanguage}.
     */
    function getUserLanguage(navigatorLanguage = navigator) {
        return (
        // Most reliable, but only supported in Chrome/Firefox.
        (navigatorLanguage.languages && navigatorLanguage.languages[0]) ||
            // Supported in most browsers, but returns the language of the browser
            // UI, not the language set in browser settings.
            navigatorLanguage.language
        // Polyfill otherwise.
        );
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Implements the Client abstraction for the Remote Config REST API.
     */
    class RestClient {
        constructor(firebaseInstallations, sdkVersion, namespace, projectId, apiKey, appId) {
            this.firebaseInstallations = firebaseInstallations;
            this.sdkVersion = sdkVersion;
            this.namespace = namespace;
            this.projectId = projectId;
            this.apiKey = apiKey;
            this.appId = appId;
        }
        /**
         * Fetches from the Remote Config REST API.
         *
         * @throws a {@link ErrorCode.FETCH_NETWORK} error if {@link GlobalFetch#fetch} can't
         * connect to the network.
         * @throws a {@link ErrorCode.FETCH_PARSE} error if {@link Response#json} can't parse the
         * fetch response.
         * @throws a {@link ErrorCode.FETCH_STATUS} error if the service returns an HTTP error status.
         */
        async fetch(request) {
            const [installationId, installationToken] = await Promise.all([
                this.firebaseInstallations.getId(),
                this.firebaseInstallations.getToken()
            ]);
            const urlBase = window.FIREBASE_REMOTE_CONFIG_URL_BASE ||
                'https://firebaseremoteconfig.googleapis.com';
            const url = `${urlBase}/v1/projects/${this.projectId}/namespaces/${this.namespace}:fetch?key=${this.apiKey}`;
            const headers = {
                'Content-Type': 'application/json',
                'Content-Encoding': 'gzip',
                // Deviates from pure decorator by not passing max-age header since we don't currently have
                // service behavior using that header.
                'If-None-Match': request.eTag || '*'
            };
            const requestBody = {
                /* eslint-disable camelcase */
                sdk_version: this.sdkVersion,
                app_instance_id: installationId,
                app_instance_id_token: installationToken,
                app_id: this.appId,
                language_code: getUserLanguage()
                /* eslint-enable camelcase */
            };
            const options = {
                method: 'POST',
                headers,
                body: JSON.stringify(requestBody)
            };
            // This logic isn't REST-specific, but shimming abort logic isn't worth another decorator.
            const fetchPromise = fetch(url, options);
            const timeoutPromise = new Promise((_resolve, reject) => {
                // Maps async event listener to Promise API.
                request.signal.addEventListener(() => {
                    // Emulates https://heycam.github.io/webidl/#aborterror
                    const error = new Error('The operation was aborted.');
                    error.name = 'AbortError';
                    reject(error);
                });
            });
            let response;
            try {
                await Promise.race([fetchPromise, timeoutPromise]);
                response = await fetchPromise;
            }
            catch (originalError) {
                let errorCode = "fetch-client-network" /* FETCH_NETWORK */;
                if (originalError.name === 'AbortError') {
                    errorCode = "fetch-timeout" /* FETCH_TIMEOUT */;
                }
                throw ERROR_FACTORY.create(errorCode, {
                    originalErrorMessage: originalError.message
                });
            }
            let status = response.status;
            // Normalizes nullable header to optional.
            const responseEtag = response.headers.get('ETag') || undefined;
            let config;
            let state;
            // JSON parsing throws SyntaxError if the response body isn't a JSON string.
            // Requesting application/json and checking for a 200 ensures there's JSON data.
            if (response.status === 200) {
                let responseBody;
                try {
                    responseBody = await response.json();
                }
                catch (originalError) {
                    throw ERROR_FACTORY.create("fetch-client-parse" /* FETCH_PARSE */, {
                        originalErrorMessage: originalError.message
                    });
                }
                config = responseBody['entries'];
                state = responseBody['state'];
            }
            // Normalizes based on legacy state.
            if (state === 'INSTANCE_STATE_UNSPECIFIED') {
                status = 500;
            }
            else if (state === 'NO_CHANGE') {
                status = 304;
            }
            else if (state === 'NO_TEMPLATE' || state === 'EMPTY_CONFIG') {
                // These cases can be fixed remotely, so normalize to safe value.
                config = {};
            }
            // Normalize to exception-based control flow for non-success cases.
            // Encapsulates HTTP specifics in this class as much as possible. Status is still the best for
            // differentiating success states (200 from 304; the state body param is undefined in a
            // standard 304).
            if (status !== 304 && status !== 200) {
                throw ERROR_FACTORY.create("fetch-status" /* FETCH_STATUS */, {
                    httpStatus: status
                });
            }
            return { status, eTag: responseEtag, config };
        }
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Supports waiting on a backoff by:
     *
     * <ul>
     *   <li>Promisifying setTimeout, so we can set a timeout in our Promise chain</li>
     *   <li>Listening on a signal bus for abort events, just like the Fetch API</li>
     *   <li>Failing in the same way the Fetch API fails, so timing out a live request and a throttled
     *       request appear the same.</li>
     * </ul>
     *
     * <p>Visible for testing.
     */
    function setAbortableTimeout(signal, throttleEndTimeMillis) {
        return new Promise((resolve, reject) => {
            // Derives backoff from given end time, normalizing negative numbers to zero.
            const backoffMillis = Math.max(throttleEndTimeMillis - Date.now(), 0);
            const timeout = setTimeout(resolve, backoffMillis);
            // Adds listener, rather than sets onabort, because signal is a shared object.
            signal.addEventListener(() => {
                clearTimeout(timeout);
                // If the request completes before this timeout, the rejection has no effect.
                reject(ERROR_FACTORY.create("fetch-throttle" /* FETCH_THROTTLE */, {
                    throttleEndTimeMillis
                }));
            });
        });
    }
    /**
     * Returns true if the {@link Error} indicates a fetch request may succeed later.
     */
    function isRetriableError(e) {
        if (!(e instanceof FirebaseError) || !e.customData) {
            return false;
        }
        // Uses string index defined by ErrorData, which FirebaseError implements.
        const httpStatus = Number(e.customData['httpStatus']);
        return (httpStatus === 429 ||
            httpStatus === 500 ||
            httpStatus === 503 ||
            httpStatus === 504);
    }
    /**
     * Decorates a Client with retry logic.
     *
     * <p>Comparable to CachingClient, but uses backoff logic instead of cache max age and doesn't cache
     * responses (because the SDK has no use for error responses).
     */
    class RetryingClient {
        constructor(client, storage) {
            this.client = client;
            this.storage = storage;
        }
        async fetch(request) {
            const throttleMetadata = (await this.storage.getThrottleMetadata()) || {
                backoffCount: 0,
                throttleEndTimeMillis: Date.now()
            };
            return this.attemptFetch(request, throttleMetadata);
        }
        /**
         * A recursive helper for attempting a fetch request repeatedly.
         *
         * @throws any non-retriable errors.
         */
        async attemptFetch(request, { throttleEndTimeMillis, backoffCount }) {
            // Starts with a (potentially zero) timeout to support resumption from stored state.
            // Ensures the throttle end time is honored if the last attempt timed out.
            // Note the SDK will never make a request if the fetch timeout expires at this point.
            await setAbortableTimeout(request.signal, throttleEndTimeMillis);
            try {
                const response = await this.client.fetch(request);
                // Note the SDK only clears throttle state if response is success or non-retriable.
                await this.storage.deleteThrottleMetadata();
                return response;
            }
            catch (e) {
                if (!isRetriableError(e)) {
                    throw e;
                }
                // Increments backoff state.
                const throttleMetadata = {
                    throttleEndTimeMillis: Date.now() + calculateBackoffMillis(backoffCount),
                    backoffCount: backoffCount + 1
                };
                // Persists state.
                await this.storage.setThrottleMetadata(throttleMetadata);
                return this.attemptFetch(request, throttleMetadata);
            }
        }
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    const DEFAULT_FETCH_TIMEOUT_MILLIS = 60 * 1000; // One minute
    const DEFAULT_CACHE_MAX_AGE_MILLIS = 12 * 60 * 60 * 1000; // Twelve hours.
    /**
     * Encapsulates business logic mapping network and storage dependencies to the public SDK API.
     *
     * See {@link https://github.com/FirebasePrivate/firebase-js-sdk/blob/master/packages/firebase/index.d.ts|interface documentation} for method descriptions.
     */
    class RemoteConfig {
        constructor(
        // Required by FirebaseServiceFactory interface.
        app, 
        // JS doesn't support private yet
        // (https://github.com/tc39/proposal-class-fields#private-fields), so we hint using an
        // underscore prefix.
        /**
         * @internal
         */
        _client, 
        /**
         * @internal
         */
        _storageCache, 
        /**
         * @internal
         */
        _storage, 
        /**
         * @internal
         */
        _logger) {
            this.app = app;
            this._client = _client;
            this._storageCache = _storageCache;
            this._storage = _storage;
            this._logger = _logger;
            /**
             * Tracks completion of initialization promise.
             * @internal
             */
            this._isInitializationComplete = false;
            this.settings = {
                fetchTimeoutMillis: DEFAULT_FETCH_TIMEOUT_MILLIS,
                minimumFetchIntervalMillis: DEFAULT_CACHE_MAX_AGE_MILLIS
            };
            this.defaultConfig = {};
        }
        get fetchTimeMillis() {
            return this._storageCache.getLastSuccessfulFetchTimestampMillis() || -1;
        }
        get lastFetchStatus() {
            return this._storageCache.getLastFetchStatus() || 'no-fetch-yet';
        }
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * Converts an error event associated with a {@link IDBRequest} to a {@link FirebaseError}.
     */
    function toFirebaseError(event, errorCode) {
        const originalError = event.target.error || undefined;
        return ERROR_FACTORY.create(errorCode, {
            originalErrorMessage: originalError && originalError.message
        });
    }
    /**
     * A general-purpose store keyed by app + namespace + {@link
     * ProjectNamespaceKeyFieldValue}.
     *
     * <p>The Remote Config SDK can be used with multiple app installations, and each app can interact
     * with multiple namespaces, so this store uses app (ID + name) and namespace as common parent keys
     * for a set of key-value pairs. See {@link Storage#createCompositeKey}.
     *
     * <p>Visible for testing.
     */
    const APP_NAMESPACE_STORE = 'app_namespace_store';
    const DB_NAME = 'firebase_remote_config';
    const DB_VERSION = 1;
    // Visible for testing.
    function openDatabase() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onerror = event => {
                reject(toFirebaseError(event, "storage-open" /* STORAGE_OPEN */));
            };
            request.onsuccess = event => {
                resolve(event.target.result);
            };
            request.onupgradeneeded = event => {
                const db = event.target.result;
                // We don't use 'break' in this switch statement, the fall-through
                // behavior is what we want, because if there are multiple versions between
                // the old version and the current version, we want ALL the migrations
                // that correspond to those versions to run, not only the last one.
                // eslint-disable-next-line default-case
                switch (event.oldVersion) {
                    case 0:
                        db.createObjectStore(APP_NAMESPACE_STORE, {
                            keyPath: 'compositeKey'
                        });
                }
            };
        });
    }
    /**
     * Abstracts data persistence.
     */
    class Storage {
        /**
         * @param appId enables storage segmentation by app (ID + name).
         * @param appName enables storage segmentation by app (ID + name).
         * @param namespace enables storage segmentation by namespace.
         */
        constructor(appId, appName, namespace, openDbPromise = openDatabase()) {
            this.appId = appId;
            this.appName = appName;
            this.namespace = namespace;
            this.openDbPromise = openDbPromise;
        }
        getLastFetchStatus() {
            return this.get('last_fetch_status');
        }
        setLastFetchStatus(status) {
            return this.set('last_fetch_status', status);
        }
        // This is comparable to a cache entry timestamp. If we need to expire other data, we could
        // consider adding timestamp to all storage records and an optional max age arg to getters.
        getLastSuccessfulFetchTimestampMillis() {
            return this.get('last_successful_fetch_timestamp_millis');
        }
        setLastSuccessfulFetchTimestampMillis(timestamp) {
            return this.set('last_successful_fetch_timestamp_millis', timestamp);
        }
        getLastSuccessfulFetchResponse() {
            return this.get('last_successful_fetch_response');
        }
        setLastSuccessfulFetchResponse(response) {
            return this.set('last_successful_fetch_response', response);
        }
        getActiveConfig() {
            return this.get('active_config');
        }
        setActiveConfig(config) {
            return this.set('active_config', config);
        }
        getActiveConfigEtag() {
            return this.get('active_config_etag');
        }
        setActiveConfigEtag(etag) {
            return this.set('active_config_etag', etag);
        }
        getThrottleMetadata() {
            return this.get('throttle_metadata');
        }
        setThrottleMetadata(metadata) {
            return this.set('throttle_metadata', metadata);
        }
        deleteThrottleMetadata() {
            return this.delete('throttle_metadata');
        }
        async get(key) {
            const db = await this.openDbPromise;
            return new Promise((resolve, reject) => {
                const transaction = db.transaction([APP_NAMESPACE_STORE], 'readonly');
                const objectStore = transaction.objectStore(APP_NAMESPACE_STORE);
                const compositeKey = this.createCompositeKey(key);
                try {
                    const request = objectStore.get(compositeKey);
                    request.onerror = event => {
                        reject(toFirebaseError(event, "storage-get" /* STORAGE_GET */));
                    };
                    request.onsuccess = event => {
                        const result = event.target.result;
                        if (result) {
                            resolve(result.value);
                        }
                        else {
                            resolve(undefined);
                        }
                    };
                }
                catch (e) {
                    reject(ERROR_FACTORY.create("storage-get" /* STORAGE_GET */, {
                        originalErrorMessage: e && e.message
                    }));
                }
            });
        }
        async set(key, value) {
            const db = await this.openDbPromise;
            return new Promise((resolve, reject) => {
                const transaction = db.transaction([APP_NAMESPACE_STORE], 'readwrite');
                const objectStore = transaction.objectStore(APP_NAMESPACE_STORE);
                const compositeKey = this.createCompositeKey(key);
                try {
                    const request = objectStore.put({
                        compositeKey,
                        value
                    });
                    request.onerror = (event) => {
                        reject(toFirebaseError(event, "storage-set" /* STORAGE_SET */));
                    };
                    request.onsuccess = () => {
                        resolve();
                    };
                }
                catch (e) {
                    reject(ERROR_FACTORY.create("storage-set" /* STORAGE_SET */, {
                        originalErrorMessage: e && e.message
                    }));
                }
            });
        }
        async delete(key) {
            const db = await this.openDbPromise;
            return new Promise((resolve, reject) => {
                const transaction = db.transaction([APP_NAMESPACE_STORE], 'readwrite');
                const objectStore = transaction.objectStore(APP_NAMESPACE_STORE);
                const compositeKey = this.createCompositeKey(key);
                try {
                    const request = objectStore.delete(compositeKey);
                    request.onerror = (event) => {
                        reject(toFirebaseError(event, "storage-delete" /* STORAGE_DELETE */));
                    };
                    request.onsuccess = () => {
                        resolve();
                    };
                }
                catch (e) {
                    reject(ERROR_FACTORY.create("storage-delete" /* STORAGE_DELETE */, {
                        originalErrorMessage: e && e.message
                    }));
                }
            });
        }
        // Facilitates composite key functionality (which is unsupported in IE).
        createCompositeKey(key) {
            return [this.appId, this.appName, this.namespace, key].join();
        }
    }

    /**
     * @license
     * Copyright 2019 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    /**
     * A memory cache layer over storage to support the SDK's synchronous read requirements.
     */
    class StorageCache {
        constructor(storage) {
            this.storage = storage;
        }
        /**
         * Memory-only getters
         */
        getLastFetchStatus() {
            return this.lastFetchStatus;
        }
        getLastSuccessfulFetchTimestampMillis() {
            return this.lastSuccessfulFetchTimestampMillis;
        }
        getActiveConfig() {
            return this.activeConfig;
        }
        /**
         * Read-ahead getter
         */
        async loadFromStorage() {
            const lastFetchStatusPromise = this.storage.getLastFetchStatus();
            const lastSuccessfulFetchTimestampMillisPromise = this.storage.getLastSuccessfulFetchTimestampMillis();
            const activeConfigPromise = this.storage.getActiveConfig();
            // Note:
            // 1. we consistently check for undefined to avoid clobbering defined values
            //   in memory
            // 2. we defer awaiting to improve readability, as opposed to destructuring
            //   a Promise.all result, for example
            const lastFetchStatus = await lastFetchStatusPromise;
            if (lastFetchStatus) {
                this.lastFetchStatus = lastFetchStatus;
            }
            const lastSuccessfulFetchTimestampMillis = await lastSuccessfulFetchTimestampMillisPromise;
            if (lastSuccessfulFetchTimestampMillis) {
                this.lastSuccessfulFetchTimestampMillis = lastSuccessfulFetchTimestampMillis;
            }
            const activeConfig = await activeConfigPromise;
            if (activeConfig) {
                this.activeConfig = activeConfig;
            }
        }
        /**
         * Write-through setters
         */
        setLastFetchStatus(status) {
            this.lastFetchStatus = status;
            return this.storage.setLastFetchStatus(status);
        }
        setLastSuccessfulFetchTimestampMillis(timestampMillis) {
            this.lastSuccessfulFetchTimestampMillis = timestampMillis;
            return this.storage.setLastSuccessfulFetchTimestampMillis(timestampMillis);
        }
        setActiveConfig(activeConfig) {
            this.activeConfig = activeConfig;
            return this.storage.setActiveConfig(activeConfig);
        }
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    function registerRemoteConfig() {
        _registerComponent(new Component(RC_COMPONENT_NAME, remoteConfigFactory, "PUBLIC" /* PUBLIC */).setMultipleInstances(true));
        registerVersion(name, version);
        function remoteConfigFactory(container, { instanceIdentifier: namespace }) {
            /* Dependencies */
            // getImmediate for FirebaseApp will always succeed
            const app = container.getProvider('app-exp').getImmediate();
            // The following call will always succeed because rc has `import '@firebase/installations'`
            const installations = container
                .getProvider('installations-exp-internal')
                .getImmediate();
            // Guards against the SDK being used in non-browser environments.
            if (typeof window === 'undefined') {
                throw ERROR_FACTORY.create("registration-window" /* REGISTRATION_WINDOW */);
            }
            // Normalizes optional inputs.
            const { projectId, apiKey, appId } = app.options;
            if (!projectId) {
                throw ERROR_FACTORY.create("registration-project-id" /* REGISTRATION_PROJECT_ID */);
            }
            if (!apiKey) {
                throw ERROR_FACTORY.create("registration-api-key" /* REGISTRATION_API_KEY */);
            }
            if (!appId) {
                throw ERROR_FACTORY.create("registration-app-id" /* REGISTRATION_APP_ID */);
            }
            namespace = namespace || 'firebase';
            const storage = new Storage(appId, app.name, namespace);
            const storageCache = new StorageCache(storage);
            const logger = new Logger(name);
            // Sets ERROR as the default log level.
            // See RemoteConfig#setLogLevel for corresponding normalization to ERROR log level.
            logger.logLevel = LogLevel.ERROR;
            const restClient = new RestClient(installations, 
            // Uses the JS SDK version, by which the RC package version can be deduced, if necessary.
            SDK_VERSION, namespace, projectId, apiKey, appId);
            const retryingClient = new RetryingClient(restClient, storage);
            const cachingClient = new CachingClient(retryingClient, storage, storageCache, logger);
            const remoteConfigInstance = new RemoteConfig(app, cachingClient, storageCache, storage, logger);
            // Starts warming cache.
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            ensureInitialized(remoteConfigInstance);
            return remoteConfigInstance;
        }
    }

    /**
     * @license
     * Copyright 2020 Google LLC
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *   http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    // This API is put in a separate file, so we can stub fetchConfig and activate in tests.
    // It's not possible to stub standalone functions from the same module.
    /**
     *
     * Performs fetch and activate operations, as a convenience.
     *
     * @param remoteConfig - The remote config instance.
     *
     * @returns A promise which resolves to true if the current call activated the fetched configs.
     * If the fetched configs were already activated, the promise will resolve to false.
     *
     * @public
     */
    async function fetchAndActivate(remoteConfig) {
        remoteConfig = getModularInstance(remoteConfig);
        await fetchConfig(remoteConfig);
        return activate(remoteConfig);
    }

    /**
     * Firebase Remote Config
     *
     * @packageDocumentation
     */
    /** register component and version */
    registerRemoteConfig();

    const firebaseApp = initializeApp(JSON.parse(atob(firebaseConfig)));
    const db = sn(firebaseApp);
    const remoteConfig = getRemoteConfig(firebaseApp);
    remoteConfig.settings = {
        fetchTimeoutMillis: 3600000,
        minimumFetchIntervalMillis: 600000,
    };

    class UpdateService {
        async checkForUpdate() {
            await fetchAndActivate(remoteConfig);
            let latestVersion = getString(remoteConfig, "currentVersion");
            if (version$4 < latestVersion)
                return latestVersion;
            return null;
        }
    }
    var updateService = new UpdateService();

    var t$1,u$1,r$1,o$1=0,i$1=[],c$1=l$3.__b,f$1=l$3.__r,e$1=l$3.diffed,a$1=l$3.__c,v$1=l$3.unmount;function m$1(t,r){l$3.__h&&l$3.__h(u$1,t,o$1||r),o$1=0;var i=u$1.__H||(u$1.__H={__:[],__h:[]});return t>=i.__.length&&i.__.push({}),i.__[t]}function l$1(n){return o$1=1,p$1(w$2,n)}function p$1(n,r,o){var i=m$1(t$1++,2);return i.t=n,i.__c||(i.__=[o?o(r):w$2(void 0,r),function(n){var t=i.t(i.__[0],n);i.__[0]!==t&&(i.__=[t,i.__[1]],i.__c.setState({}));}],i.__c=u$1),i.__}function y$1(r,o){var i=m$1(t$1++,3);!l$3.__s&&k$2(i.__H,o)&&(i.__=r,i.__H=o,u$1.__H.__h.push(i));}function h$1(r,o){var i=m$1(t$1++,4);!l$3.__s&&k$2(i.__H,o)&&(i.__=r,i.__H=o,u$1.__h.push(i));}function s$1(n){return o$1=5,d$1(function(){return {current:n}},[])}function _(n,t,u){o$1=6,h$1(function(){"function"==typeof n?n(t()):n&&(n.current=t());},null==u?u:u.concat(n));}function d$1(n,u){var r=m$1(t$1++,7);return k$2(r.__H,u)&&(r.__=n(),r.__H=u,r.__h=n),r.__}function A$2(n,t){return o$1=8,d$1(function(){return n},t)}function F$2(n){var r=u$1.context[n.__c],o=m$1(t$1++,9);return o.c=n,r?(null==o.__&&(o.__=!0,r.sub(u$1)),r.props.value):n.__}function T$2(t,u){l$3.useDebugValue&&l$3.useDebugValue(u?u(t):t);}function x$2(){i$1.forEach(function(t){if(t.__P)try{t.__H.__h.forEach(g$2),t.__H.__h.forEach(j$2),t.__H.__h=[];}catch(u){t.__H.__h=[],l$3.__e(u,t.__v);}}),i$1=[];}l$3.__b=function(n){u$1=null,c$1&&c$1(n);},l$3.__r=function(n){f$1&&f$1(n),t$1=0;var r=(u$1=n.__c).__H;r&&(r.__h.forEach(g$2),r.__h.forEach(j$2),r.__h=[]);},l$3.diffed=function(t){e$1&&e$1(t);var o=t.__c;o&&o.__H&&o.__H.__h.length&&(1!==i$1.push(o)&&r$1===l$3.requestAnimationFrame||((r$1=l$3.requestAnimationFrame)||function(n){var t,u=function(){clearTimeout(r),b$1&&cancelAnimationFrame(t),setTimeout(n);},r=setTimeout(u,100);b$1&&(t=requestAnimationFrame(u));})(x$2)),u$1=void 0;},l$3.__c=function(t,u){u.some(function(t){try{t.__h.forEach(g$2),t.__h=t.__h.filter(function(n){return !n.__||j$2(n)});}catch(r){u.some(function(n){n.__h&&(n.__h=[]);}),u=[],l$3.__e(r,t.__v);}}),a$1&&a$1(t,u);},l$3.unmount=function(t){v$1&&v$1(t);var u=t.__c;if(u&&u.__H)try{u.__H.__.forEach(g$2);}catch(t){l$3.__e(t,u.__v);}};var b$1="function"==typeof requestAnimationFrame;function g$2(n){var t=u$1;"function"==typeof n.__c&&n.__c(),u$1=t;}function j$2(n){var t=u$1;n.__c=n.__(),u$1=t;}function k$2(n,t){return !n||n.length!==t.length||t.some(function(t,u){return t!==n[u]})}function w$2(n,t){return "function"==typeof t?t(n):t}

    function S$1(n,t){for(var e in t)n[e]=t[e];return n}function C$1(n,t){for(var e in n)if("__source"!==e&&!(e in t))return !0;for(var r in t)if("__source"!==r&&n[r]!==t[r])return !0;return !1}function E$1(n){this.props=n;}function g$1(n,t){function e(n){var e=this.props.ref,r=e==n.ref;return !r&&e&&(e.call?e(null):e.current=null),t?!t(this.props,n)||!r:C$1(this.props,n)}function r(t){return this.shouldComponentUpdate=e,v$3(n,t)}return r.displayName="Memo("+(n.displayName||n.name)+")",r.prototype.isReactComponent=!0,r.__f=!0,r}(E$1.prototype=new _$2).isPureReactComponent=!0,E$1.prototype.shouldComponentUpdate=function(n,t){return C$1(this.props,n)||C$1(this.state,t)};var w$1=l$3.__b;l$3.__b=function(n){n.type&&n.type.__f&&n.ref&&(n.props.ref=n.ref,n.ref=null),w$1&&w$1(n);};var R$1="undefined"!=typeof Symbol&&Symbol.for&&Symbol.for("react.forward_ref")||3911;function x$1(n){function t(t,e){var r=S$1({},t);return delete r.ref,n(r,(e=t.ref||e)&&("object"!=typeof e||"current"in e)?e:null)}return t.$$typeof=R$1,t.render=t,t.prototype.isReactComponent=t.__f=!0,t.displayName="ForwardRef("+(n.displayName||n.name)+")",t}var N$1=function(n,t){return null==n?null:A$4(A$4(n).map(t))},k$1={map:N$1,forEach:N$1,count:function(n){return n?A$4(n).length:0},only:function(n){var t=A$4(n);if(1!==t.length)throw "Children.only";return t[0]},toArray:A$4},A$1=l$3.__e;l$3.__e=function(n,t,e){if(n.then)for(var r,u=t;u=u.__;)if((r=u.__c)&&r.__c)return null==t.__e&&(t.__e=e.__e,t.__k=e.__k),r.__c(n,t);A$1(n,t,e);};var O$1=l$3.unmount;function L$1(){this.__u=0,this.t=null,this.__b=null;}function U$1(n){var t=n.__.__c;return t&&t.__e&&t.__e(n)}function F$1(n){var t,e,r;function u(u){if(t||(t=n()).then(function(n){e=n.default||n;},function(n){r=n;}),r)throw r;if(!e)throw t;return v$3(e,u)}return u.displayName="Lazy",u.__f=!0,u}function M$1(){this.u=null,this.o=null;}l$3.unmount=function(n){var t=n.__c;t&&t.__R&&t.__R(),t&&!0===n.__h&&(n.type=null),O$1&&O$1(n);},(L$1.prototype=new _$2).__c=function(n,t){var e=t.__c,r=this;null==r.t&&(r.t=[]),r.t.push(e);var u=U$1(r.__v),o=!1,i=function(){o||(o=!0,e.__R=null,u?u(l):l());};e.__R=i;var l=function(){if(!--r.__u){if(r.state.__e){var n=r.state.__e;r.__v.__k[0]=function n(t,e,r){return t&&(t.__v=null,t.__k=t.__k&&t.__k.map(function(t){return n(t,e,r)}),t.__c&&t.__c.__P===e&&(t.__e&&r.insertBefore(t.__e,t.__d),t.__c.__e=!0,t.__c.__P=r)),t}(n,n.__c.__P,n.__c.__O);}var t;for(r.setState({__e:r.__b=null});t=r.t.pop();)t.forceUpdate();}},f=!0===t.__h;r.__u++||f||r.setState({__e:r.__b=r.__v.__k[0]}),n.then(i,i);},L$1.prototype.componentWillUnmount=function(){this.t=[];},L$1.prototype.render=function(n,t){if(this.__b){if(this.__v.__k){var e=document.createElement("div"),r=this.__v.__k[0].__c;this.__v.__k[0]=function n(t,e,r){return t&&(t.__c&&t.__c.__H&&(t.__c.__H.__.forEach(function(n){"function"==typeof n.__c&&n.__c();}),t.__c.__H=null),null!=(t=S$1({},t)).__c&&(t.__c.__P===r&&(t.__c.__P=e),t.__c=null),t.__k=t.__k&&t.__k.map(function(t){return n(t,e,r)})),t}(this.__b,e,r.__O=r.__P);}this.__b=null;}var u=t.__e&&v$3(d$3,null,n.fallback);return u&&(u.__h=null),[v$3(d$3,null,t.__e?null:n.children),u]};var T$1=function(n,t,e){if(++e[1]===e[0]&&n.o.delete(t),n.props.revealOrder&&("t"!==n.props.revealOrder[0]||!n.o.size))for(e=n.u;e;){for(;e.length>3;)e.pop()();if(e[1]<e[0])break;n.u=e=e[2];}};function D$1(n){return this.getChildContext=function(){return n.context},n.children}function I$1(n){var t=this,e=n.i;t.componentWillUnmount=function(){S$3(null,t.l),t.l=null,t.i=null;},t.i&&t.i!==e&&t.componentWillUnmount(),n.__v?(t.l||(t.i=e,t.l={nodeType:1,parentNode:e,childNodes:[],appendChild:function(n){this.childNodes.push(n),t.i.appendChild(n);},insertBefore:function(n,e){this.childNodes.push(n),t.i.appendChild(n);},removeChild:function(n){this.childNodes.splice(this.childNodes.indexOf(n)>>>1,1),t.i.removeChild(n);}}),S$3(v$3(D$1,{context:t.context},n.__v),t.l)):t.l&&t.componentWillUnmount();}function W$1(n,t){return v$3(I$1,{__v:n,i:t})}(M$1.prototype=new _$2).__e=function(n){var t=this,e=U$1(t.__v),r=t.o.get(n);return r[0]++,function(u){var o=function(){t.props.revealOrder?(r.push(u),T$1(t,n,r)):u();};e?e(o):o();}},M$1.prototype.render=function(n){this.u=null,this.o=new Map;var t=A$4(n.children);n.revealOrder&&"b"===n.revealOrder[0]&&t.reverse();for(var e=t.length;e--;)this.o.set(t[e],this.u=[1,0,this.u]);return n.children},M$1.prototype.componentDidUpdate=M$1.prototype.componentDidMount=function(){var n=this;this.o.forEach(function(t,e){T$1(n,e,t);});};var j$1="undefined"!=typeof Symbol&&Symbol.for&&Symbol.for("react.element")||60103,P$1=/^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|fill|flood|font|glyph(?!R)|horiz|marker(?!H|W|U)|overline|paint|stop|strikethrough|stroke|text(?!L)|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,V$1=function(n){return ("undefined"!=typeof Symbol&&"symbol"==typeof Symbol()?/fil|che|rad/i:/fil|che|ra/i).test(n)};function z$1(n,t,e){return null==t.__k&&(t.textContent=""),S$3(n,t),"function"==typeof e&&e(),n?n.__c:null}function B$1(n,t,e){return q$3(n,t),"function"==typeof e&&e(),n?n.__c:null}_$2.prototype.isReactComponent={},["componentWillMount","componentWillReceiveProps","componentWillUpdate"].forEach(function(n){Object.defineProperty(_$2.prototype,n,{configurable:!0,get:function(){return this["UNSAFE_"+n]},set:function(t){Object.defineProperty(this,n,{configurable:!0,writable:!0,value:t});}});});var H$1=l$3.event;function Z(){}function Y$1(){return this.cancelBubble}function $$2(){return this.defaultPrevented}l$3.event=function(n){return H$1&&(n=H$1(n)),n.persist=Z,n.isPropagationStopped=Y$1,n.isDefaultPrevented=$$2,n.nativeEvent=n};var q$1,G$1={configurable:!0,get:function(){return this.class}},J$1=l$3.vnode;l$3.vnode=function(n){var t=n.type,e=n.props,r=e;if("string"==typeof t){for(var u in r={},e){var o=e[u];"value"===u&&"defaultValue"in e&&null==o||("defaultValue"===u&&"value"in e&&null==e.value?u="value":"download"===u&&!0===o?o="":/ondoubleclick/i.test(u)?u="ondblclick":/^onchange(textarea|input)/i.test(u+t)&&!V$1(e.type)?u="oninput":/^on(Ani|Tra|Tou|BeforeInp)/.test(u)?u=u.toLowerCase():P$1.test(u)?u=u.replace(/[A-Z0-9]/,"-$&").toLowerCase():null===o&&(o=void 0),r[u]=o);}"select"==t&&r.multiple&&Array.isArray(r.value)&&(r.value=A$4(e.children).forEach(function(n){n.props.selected=-1!=r.value.indexOf(n.props.value);})),"select"==t&&null!=r.defaultValue&&(r.value=A$4(e.children).forEach(function(n){n.props.selected=r.multiple?-1!=r.defaultValue.indexOf(n.props.value):r.defaultValue==n.props.value;})),n.props=r;}t&&e.class!=e.className&&(G$1.enumerable="className"in e,null!=e.className&&(r.class=e.className),Object.defineProperty(r,"className",G$1)),n.$$typeof=j$1,J$1&&J$1(n);};var K$1=l$3.__r;l$3.__r=function(n){K$1&&K$1(n),q$1=n.__c;};var Q$1={ReactCurrentDispatcher:{current:{readContext:function(n){return q$1.__n[n.__c].props.value}}}};function nn(n){return v$3.bind(null,n)}function tn(n){return !!n&&n.$$typeof===j$1}function en(n){return tn(n)?B$2.apply(null,arguments):n}function rn(n){return !!n.__k&&(S$3(null,n),!0)}function un(n){return n&&(n.base||1===n.nodeType&&n)||null}var on=function(n,t){return n(t)},ln=function(n,t){return n(t)};var Z$1 = {useState:l$1,useReducer:p$1,useEffect:y$1,useLayoutEffect:h$1,useRef:s$1,useImperativeHandle:_,useMemo:d$1,useCallback:A$2,useContext:F$2,useDebugValue:T$2,version:"17.0.2",Children:k$1,render:z$1,hydrate:B$1,unmountComponentAtNode:rn,createPortal:W$1,createElement:v$3,createContext:D$3,createFactory:nn,cloneElement:en,createRef:p$3,Fragment:d$3,isValidElement:tn,findDOMNode:un,Component:_$2,PureComponent:E$1,memo:g$1,forwardRef:x$1,flushSync:ln,unstable_batchedUpdates:on,StrictMode:d$3,Suspense:L$1,SuspenseList:M$1,lazy:F$1,__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED:Q$1};

    var e={all:"all"},t="colors",n="sizes",i="space",r={gap:i,gridGap:i,columnGap:i,gridColumnGap:i,rowGap:i,gridRowGap:i,inset:i,insetBlock:i,insetBlockEnd:i,insetBlockStart:i,insetInline:i,insetInlineEnd:i,insetInlineStart:i,margin:i,marginTop:i,marginRight:i,marginBottom:i,marginLeft:i,marginBlock:i,marginBlockEnd:i,marginBlockStart:i,marginInline:i,marginInlineEnd:i,marginInlineStart:i,padding:i,paddingTop:i,paddingRight:i,paddingBottom:i,paddingLeft:i,paddingBlock:i,paddingBlockEnd:i,paddingBlockStart:i,paddingInline:i,paddingInlineEnd:i,paddingInlineStart:i,top:i,right:i,bottom:i,left:i,scrollMargin:i,scrollMarginTop:i,scrollMarginRight:i,scrollMarginBottom:i,scrollMarginLeft:i,scrollMarginX:i,scrollMarginY:i,scrollMarginBlock:i,scrollMarginBlockEnd:i,scrollMarginBlockStart:i,scrollMarginInline:i,scrollMarginInlineEnd:i,scrollMarginInlineStart:i,scrollPadding:i,scrollPaddingTop:i,scrollPaddingRight:i,scrollPaddingBottom:i,scrollPaddingLeft:i,scrollPaddingX:i,scrollPaddingY:i,scrollPaddingBlock:i,scrollPaddingBlockEnd:i,scrollPaddingBlockStart:i,scrollPaddingInline:i,scrollPaddingInlineEnd:i,scrollPaddingInlineStart:i,fontSize:"fontSizes",background:t,backgroundColor:t,backgroundImage:t,border:t,borderBlock:t,borderBlockEnd:t,borderBlockStart:t,borderBottom:t,borderBottomColor:t,borderColor:t,borderInline:t,borderInlineEnd:t,borderInlineStart:t,borderLeft:t,borderLeftColor:t,borderRight:t,borderRightColor:t,borderTop:t,borderTopColor:t,caretColor:t,color:t,columnRuleColor:t,fill:t,outline:t,outlineColor:t,stroke:t,textDecorationColor:t,fontFamily:"fonts",fontWeight:"fontWeights",lineHeight:"lineHeights",letterSpacing:"letterSpacings",blockSize:n,minBlockSize:n,maxBlockSize:n,inlineSize:n,minInlineSize:n,maxInlineSize:n,width:n,minWidth:n,maxWidth:n,height:n,minHeight:n,maxHeight:n,flexBasis:n,gridTemplateColumns:n,gridTemplateRows:n,borderWidth:"borderWidths",borderTopWidth:"borderWidths",borderRightWidth:"borderWidths",borderBottomWidth:"borderWidths",borderLeftWidth:"borderWidths",borderStyle:"borderStyles",borderTopStyle:"borderStyles",borderRightStyle:"borderStyles",borderBottomStyle:"borderStyles",borderLeftStyle:"borderStyles",borderRadius:"radii",borderTopLeftRadius:"radii",borderTopRightRadius:"radii",borderBottomRightRadius:"radii",borderBottomLeftRadius:"radii",boxShadow:"shadows",textShadow:"shadows",transition:"transitions",zIndex:"zIndices"},o=(e,t)=>"function"==typeof t?{"()":Function.prototype.toString.call(t)}:t,l=()=>{const e=Object.create(null);return (t,n,...i)=>{const r=(e=>JSON.stringify(e,o))(t);return r in e?e[r]:e[r]=n(t,...i)}},s=Symbol.for("sxs.composers"),a=(e,t)=>Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)),c=e=>{for(const t in e)return !0;return !1},{hasOwnProperty:d}=Object.prototype,g=(e,t)=>d.call(e,t),u=e=>e.includes("-")?e:e.replace(/[A-Z]/g,(e=>"-"+e.toLowerCase())),p=/\s+(?![^()]*\))/,h=e=>t=>e(..."string"==typeof t?String(t).split(p):[t]),f={appearance:e=>({WebkitAppearance:e,appearance:e}),backfaceVisibility:e=>({WebkitBackfaceVisibility:e,backfaceVisibility:e}),backdropFilter:e=>({WebkitBackdropFilter:e,backdropFilter:e}),backgroundClip:e=>({WebkitBackgroundClip:e,backgroundClip:e}),boxDecorationBreak:e=>({WebkitBoxDecorationBreak:e,boxDecorationBreak:e}),clipPath:e=>({WebkitClipPath:e,clipPath:e}),content:e=>({content:e.includes('"')||e.includes("'")||/^([A-Za-z]+\([^]*|[^]*-quote|inherit|initial|none|normal|revert|unset)$/.test(e)?e:`"${e}"`}),hyphens:e=>({WebkitHyphens:e,hyphens:e}),maskImage:e=>({WebkitMaskImage:e,maskImage:e}),tabSize:e=>({MozTabSize:e,tabSize:e}),textSizeAdjust:e=>({WebkitTextSizeAdjust:e,textSizeAdjust:e}),userSelect:e=>({WebkitUserSelect:e,userSelect:e}),marginBlock:h(((e,t)=>({marginBlockStart:e,marginBlockEnd:t||e}))),marginInline:h(((e,t)=>({marginInlineStart:e,marginInlineEnd:t||e}))),maxSize:h(((e,t)=>({maxBlockSize:e,maxInlineSize:t||e}))),minSize:h(((e,t)=>({minBlockSize:e,minInlineSize:t||e}))),paddingBlock:h(((e,t)=>({paddingBlockStart:e,paddingBlockEnd:t||e}))),paddingInline:h(((e,t)=>({paddingInlineStart:e,paddingInlineEnd:t||e})))},m=/([\d.]+)([^]*)/,b=(e,t)=>e.length?e.reduce(((e,n)=>(e.push(...t.map((e=>e.includes("&")?e.replace(/&/g,/[ +>|~]/.test(n)&&/&.*&/.test(e)?`:is(${n})`:n):n+" "+e))),e)),[]):t,S=(e,t)=>e in k&&"string"==typeof t?t.replace(/^((?:[^]*[^\w-])?)(fit-content|stretch)((?:[^\w-][^]*)?)$/,((t,n,i,r)=>n+("stretch"===i?`-moz-available${r};${e}:${n}-webkit-fill-available`:`-moz-fit-content${r};${e}:${n}fit-content`)+r)):String(t),k={blockSize:1,height:1,inlineSize:1,maxBlockSize:1,maxHeight:1,maxInlineSize:1,maxWidth:1,minBlockSize:1,minHeight:1,minInlineSize:1,minWidth:1,width:1},y=e=>e?e+"-":"",B=(e,t,n)=>e.replace(/([+-])?((?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][+-]?\d+)?)?(\$|--)([$\w-]+)/g,((e,i,r,o,l)=>"$"==o==!!r?e:(i||"--"==o?"calc(":"")+"var(--"+("$"===o?y(t)+(l.includes("$")?"":y(n))+l.replace(/\$/g,"-"):l)+")"+(i||"--"==o?"*"+(i||"")+(r||"1")+")":""))),R=/\s*,\s*(?![^()]*\))/,$$1=Object.prototype.toString,x=(e,t,n,i,r)=>{let o,l,s;const a=(e,t,n)=>{let c,d;const g=e=>{for(c in e){const k=64===c.charCodeAt(0),x=k&&Array.isArray(e[c])?e[c]:[e[c]];for(d of x){const e="object"==typeof d&&d&&d.toString===$$1,x=/[A-Z]/.test(h=c)?h:h.replace(/-[^]/g,(e=>e[1].toUpperCase()));if(x in i.utils){const e=i.utils[x];if(e!==l){l=e,g(e(i)(d)),l=null;continue}}else if(x in f){const e=f[x];if(e!==s){s=e,g(e(d)),s=null;continue}}if(k&&(p=c.slice(1)in i.media?"@media "+i.media[c.slice(1)]:c,c=p.replace(/\(\s*([\w-]+)\s*(=|<|<=|>|>=)\s*([\w-]+)\s*(?:(<|<=|>|>=)\s*([\w-]+)\s*)?\)/g,((e,t,n,i,r,o)=>{const l=m.test(t),s=.0625*(l?-1:1),[a,c]=l?[i,t]:[t,i];return "("+("="===n[0]?"":">"===n[0]===l?"max-":"min-")+a+":"+("="!==n[0]&&1===n.length?c.replace(m,((e,t,i)=>Number(t)+s*(">"===n?1:-1)+i)):c)+(r?") and ("+(">"===r[0]?"min-":"max-")+a+":"+(1===r.length?o.replace(m,((e,t,n)=>Number(t)+s*(">"===r?-1:1)+n)):o):"")+")"}))),e){const e=k?n.concat(c):[...n],i=k?[...t]:b(t,c.split(R));void 0!==o&&r(I(...o)),o=void 0,a(d,i,e);}else void 0===o&&(o=[[],t,n]),c=k||36!==c.charCodeAt(0)?c:`--${y(i.prefix)}${c.slice(1).replace(/\$/g,"-")}`,d=e?d:"number"==typeof d?d&&x in W?String(d)+"px":String(d):B(S(x,d),i.prefix,i.themeMap[x]),o[0].push(`${k?`${c} `:`${u(c)}:`}${d}`);}}var p,h;};g(e),void 0!==o&&r(I(...o)),o=void 0;};a(e,t,n);},I=(e,t,n)=>`${n.map((e=>`${e}{`)).join("")}${t.length?`${t.join(",")}{`:""}${e.join(";")}${t.length?"}":""}${Array(n.length?n.length+1:0).join("}")}`,W={animationDelay:1,animationDuration:1,backgroundSize:1,blockSize:1,border:1,borderBlock:1,borderBlockEnd:1,borderBlockEndWidth:1,borderBlockStart:1,borderBlockStartWidth:1,borderBlockWidth:1,borderBottom:1,borderBottomLeftRadius:1,borderBottomRightRadius:1,borderBottomWidth:1,borderEndEndRadius:1,borderEndStartRadius:1,borderInlineEnd:1,borderInlineEndWidth:1,borderInlineStart:1,borderInlineStartWidth:1,borderInlineWidth:1,borderLeft:1,borderLeftWidth:1,borderRadius:1,borderRight:1,borderRightWidth:1,borderSpacing:1,borderStartEndRadius:1,borderStartStartRadius:1,borderTop:1,borderTopLeftRadius:1,borderTopRightRadius:1,borderTopWidth:1,borderWidth:1,bottom:1,columnGap:1,columnRule:1,columnRuleWidth:1,columnWidth:1,containIntrinsicSize:1,flexBasis:1,fontSize:1,gap:1,gridAutoColumns:1,gridAutoRows:1,gridTemplateColumns:1,gridTemplateRows:1,height:1,inlineSize:1,inset:1,insetBlock:1,insetBlockEnd:1,insetBlockStart:1,insetInline:1,insetInlineEnd:1,insetInlineStart:1,left:1,letterSpacing:1,margin:1,marginBlock:1,marginBlockEnd:1,marginBlockStart:1,marginBottom:1,marginInline:1,marginInlineEnd:1,marginInlineStart:1,marginLeft:1,marginRight:1,marginTop:1,maxBlockSize:1,maxHeight:1,maxInlineSize:1,maxWidth:1,minBlockSize:1,minHeight:1,minInlineSize:1,minWidth:1,offsetDistance:1,offsetRotate:1,outline:1,outlineOffset:1,outlineWidth:1,overflowClipMargin:1,padding:1,paddingBlock:1,paddingBlockEnd:1,paddingBlockStart:1,paddingBottom:1,paddingInline:1,paddingInlineEnd:1,paddingInlineStart:1,paddingLeft:1,paddingRight:1,paddingTop:1,perspective:1,right:1,rowGap:1,scrollMargin:1,scrollMarginBlock:1,scrollMarginBlockEnd:1,scrollMarginBlockStart:1,scrollMarginBottom:1,scrollMarginInline:1,scrollMarginInlineEnd:1,scrollMarginInlineStart:1,scrollMarginLeft:1,scrollMarginRight:1,scrollMarginTop:1,scrollPadding:1,scrollPaddingBlock:1,scrollPaddingBlockEnd:1,scrollPaddingBlockStart:1,scrollPaddingBottom:1,scrollPaddingInline:1,scrollPaddingInlineEnd:1,scrollPaddingInlineStart:1,scrollPaddingLeft:1,scrollPaddingRight:1,scrollPaddingTop:1,shapeMargin:1,textDecoration:1,textDecorationThickness:1,textIndent:1,textUnderlineOffset:1,top:1,transitionDelay:1,transitionDuration:1,verticalAlign:1,width:1,wordSpacing:1},j=e=>String.fromCharCode(e+(e>25?39:97)),z=e=>(e=>{let t,n="";for(t=Math.abs(e);t>52;t=t/52|0)n=j(t%52)+n;return j(t%52)+n})(((e,t)=>{let n=t.length;for(;n;)e=33*e^t.charCodeAt(--n);return e})(5381,JSON.stringify(e))>>>0),w=l(),v=(e,t)=>w(e,(()=>(...n)=>{let i=null;const r=new Set;for(const t of n)if(null!=t)switch(typeof t){case"function":if(null==i&&!t[s]){i=t;break}case"object":if(null==i&&null!=t.type&&(i=t.type),s in t)for(const e of t[s])r.add(e);else if(!("$$typeof"in t)){const n=E(t,e);r.add(n);}break;case"string":i=t;}return null==i&&(i="span"),r.size||r.add(["PJLV",{},[],[],{},[]]),M(e,i,r,t)})),E=({variants:e,compoundVariants:t,defaultVariants:n,...i},r)=>{const o=`${y(r.prefix)}c-${z(i)}`,l=[],s=[],a=Object.create(null),d=[];for(const e in n)a[e]=String(n[e]);if("object"==typeof e&&e)for(const t in e){g(a,t)||(a[t]="undefined");const n=e[t];for(const e in n){const i={[t]:String(e)};"undefined"===String(e)&&d.push(t);const r=n[e],o=[i,r,!c(r)];l.push(o);}}if("object"==typeof t&&t)for(const e of t){let{css:t,...n}=e;t="object"==typeof t&&t||{};for(const e in n)n[e]=String(n[e]);const i=[n,t,!c(t)];s.push(i);}return [o,i,l,s,a,d]},M=(e,t,n,i)=>{const[r,o,l,c]=C(n),d=`.${r}`,g=s=>{s="object"==typeof s&&s||T;const{css:a,...g}=s,u={};for(const e in l)if(delete g[e],e in s){let t=s[e];"object"==typeof t&&t?u[e]={"@initial":l[e],...t}:(t=String(t),u[e]="undefined"!==t||c.has(e)?t:l[e]);}else u[e]=l[e];const p=new Set([...o]);for(const[t,r,o,l]of n){i.rules.styled.cache.has(t)||(i.rules.styled.cache.add(t),x(r,[`.${t}`],[],e,(e=>{i.rules.styled.apply(e);})));const n=P(o,u,e.media),s=P(l,u,e.media,!0);for(const r of n)if(void 0!==r)for(const[n,o]of r){const r=`${t}-${z(o)}-${n}`;p.add(r),i.rules.onevar.cache.has(r)||(i.rules.onevar.cache.add(r),x(o,[`.${r}`],[],e,(e=>{i.rules.onevar.apply(e);})));}for(const n of s)if(void 0!==n)for(const[r,o]of n){const n=`${t}-${z(o)}-${r}`;p.add(n),i.rules.allvar.cache.has(n)||(i.rules.allvar.cache.add(n),x(o,[`.${n}`],[],e,(e=>{i.rules.allvar.apply(e);})));}}if("object"==typeof a&&a){const t=`${r}-i${z(a)}-css`;p.add(t),i.rules.inline.cache.has(t)||(i.rules.inline.cache.add(t),x(a,[`.${t}`],[],e,(e=>{i.rules.inline.apply(e);})));}for(const e of String(s.className||"").trim().split(/\s+/))e&&p.add(e);const h=g.className=[...p].join(" ");return {type:t,className:h,selector:d,props:g,toString:()=>h}};return a(g,{type:t,className:r,selector:d,[s]:n,toString:()=>(i.rules.styled.cache.has(r)||g(),r)})},C=e=>{let t="";const n=[],i={},r=[];for(const[o,,,,l,s]of e){""===t&&(t=o),n.push(o),r.push(...s);for(const e in l){const t=l[e];(void 0===i[e]||"undefined"!==t||s.includes(t))&&(i[e]=t);}}return [t,n,i,new Set(r)]},P=(e,t,n,i)=>{const r=[];e:for(let[o,l,s]of e){if(s)continue;let e,a=0;for(e in o){const i=o[e];let r=t[e];if(r!==i){if("object"!=typeof r||!r)continue e;{let e,t=0;for(const o in r)i===String(r[o])&&("@initial"!==o&&(l={[o in n?n[o]:o]:l}),a+=t,e=!0),++t;if(!e)continue e}}}(r[a]=r[a]||[]).push([i?"cv":`${e}-${o[e]}`,l]);}return r},T={},L=l(),O=(e,t)=>L(e,(()=>n=>{const i=z(n="object"==typeof n&&n||{}),r=()=>{if(!t.rules.global.cache.has(i)){if(t.rules.global.cache.add(i),"@import"in n){let e=[].indexOf.call(t.sheet.cssRules,t.rules.themed.group)-1;for(let i of [].concat(n["@import"]))i=i.includes('"')||i.includes("'")?i:`"${i}"`,t.sheet.insertRule(`@import ${i};`,e++);delete n["@import"];}x(n,[],[],e,(e=>{t.rules.global.apply(e);}));}return ""};return a(r,{toString:r})})),A=l(),N=(e,t)=>A(e,(()=>n=>{const i=`${y(e.prefix)}k-${z(n)}`,r=()=>{if(!t.rules.global.cache.has(i)){t.rules.global.cache.add(i);const r=[];x(n,[],[],e,(e=>r.push(e)));const o=`@keyframes ${i}{${r.join("")}}`;t.rules.global.apply(o);}return i};return a(r,{get name(){return r()},toString:r})})),D=class{constructor(e,t,n,i){this.token=null==e?"":String(e),this.value=null==t?"":String(t),this.scale=null==n?"":String(n),this.prefix=null==i?"":String(i);}get computedValue(){return "var("+this.variable+")"}get variable(){return "--"+y(this.prefix)+y(this.scale)+this.token}toString(){return this.computedValue}},H=l(),V=(e,t)=>H(e,(()=>(n,i)=>{i="object"==typeof n&&n||Object(i);const r=`.${n=(n="string"==typeof n?n:"")||`${y(e.prefix)}t-${z(i)}`}`,o={},l=[];for(const t in i){o[t]={};for(const n in i[t]){const r=`--${y(e.prefix)}${t}-${n}`,s=B(String(i[t][n]),e.prefix,t);o[t][n]=new D(n,s,t,e.prefix),l.push(`${r}:${s}`);}}return {...o,className:n,selector:r,toString:()=>{if(l.length&&!t.rules.themed.cache.has(n)){t.rules.themed.cache.add(n);const r=`${i===e.theme?":root,":""}.${n}{${l.join(";")}}`;t.rules.themed.apply(r);}return n}}})),G=["themed","global","styled","onevar","allvar","inline"],F=e=>{let t;const n=()=>{if(t){const{rules:e,sheet:n}=t;if(!n.deleteRule){for(;3===Object(Object(n.cssRules)[0]).type;)n.cssRules.splice(0,1);n.cssRules=[];}for(const t in e)delete e[t];n.ownerRule&&(n.ownerRule.textContent=n.ownerRule.textContent);}const i=Object(e).styleSheets||[];for(const e of i)if(!e.href||e.href.startsWith(location.origin)){for(let i=0,r=e.cssRules;r[i];++i){const o=Object(r[i]);if(1!==o.type)continue;const l=Object(r[i+1]);if(4!==l.type)continue;++i;const{cssText:s}=o;if(!s.startsWith("--stitches"))continue;const a=s.slice(16,-3).trim().split(/\s+/),c=G[a[0]];c&&(t||(t={sheet:e,reset:n,rules:{}}),t.rules[c]={group:l,index:i,cache:new Set(a)});}if(t)break}if(!t){const i=(e,t)=>({type:t,cssRules:[],insertRule(e,t){this.cssRules.splice(t,0,i(e,{import:3,undefined:1}[(e.toLowerCase().match(/^@([a-z]+)/)||[])[1]]||4));},get cssText(){return "@media{}"===e?`@media{${[].map.call(this.cssRules,(e=>e.cssText)).join("")}}`:e}});t={sheet:e?(e.head||e).appendChild(document.createElement("style")).sheet:i("","text/css"),rules:{},reset:n,toString(){const{cssRules:e}=t.sheet;return [].map.call(e,((n,i)=>{const{cssText:r}=n;let o="";if(r.startsWith("--stitches"))return "";if(e[i-1]&&(o=e[i-1].cssText).startsWith("--stitches")){if(!n.cssRules.length)return "";for(const e in t.rules)if(t.rules[e].group===n)return `--stitches{--:${[...t.rules[e].cache].join(" ")}}${r}`;return n.cssRules.length?`${o}${r}`:""}return r})).join("")}};}const{sheet:r,rules:o}=t;if(!o.inline){const e=r.cssRules.length;r.insertRule("@media{}",e),r.insertRule("--stitches{--:5}",e),o.inline={index:e,group:r.cssRules[e+1],cache:new Set([5])};}if(J(o.inline),!o.allvar){const e=o.inline.index;r.insertRule("@media{}",e),r.insertRule("--stitches{--:4}",e),o.allvar={index:e,group:r.cssRules[e+1],cache:new Set([4])};}if(J(o.allvar),!o.onevar){const e=o.allvar.index;r.insertRule("@media{}",e),r.insertRule("--stitches{--:3}",e),o.onevar={index:e,group:r.cssRules[e+1],cache:new Set([3])};}if(J(o.onevar),!o.styled){const e=o.onevar.index;r.insertRule("@media{}",e),r.insertRule("--stitches{--:2}",e),o.styled={index:e,group:r.cssRules[e+1],cache:new Set([2])};}if(J(o.styled),!o.global){const e=o.styled.index;r.insertRule("@media{}",e),r.insertRule("--stitches{--:1}",e),o.global={index:e,group:r.cssRules[e+1],cache:new Set([1])};}if(J(o.global),!o.themed){const e=o.global.index;r.insertRule("@media{}",e),r.insertRule("--stitches{--:0}",e),o.themed={index:e,group:r.cssRules[e+1],cache:new Set([0])};}J(o.themed);};return n(),t},J=e=>{const t=e.group;let n=t.cssRules.length;e.apply=e=>{try{t.insertRule(e,n),++n;}catch{}};},U=l();var X,Y=e=>null==e?"span":"object"!=typeof e||e.$$typeof?g(e,s)?Y(e.type):e:"span",q=l(),K=t=>{const n=(t=>{let n=!1;const i=U(t,(t=>{n=!0;const i="prefix"in(t="object"==typeof t&&t||{})?String(t.prefix):"",o={...e,..."object"==typeof t.media&&t.media||{}},l="object"==typeof t.root?t.root||null:globalThis.document||null,s="object"==typeof t.theme&&t.theme||{},a={prefix:i,media:o,root:l,theme:s,themeMap:"object"==typeof t.themeMap&&t.themeMap||{...r},utils:"object"==typeof t.utils&&t.utils||{}},c=F(l),d={css:v(a,c),global:O(a,c),keyframes:N(a,c),theme:V(a,c),reset(){c.reset(),g.toString();},sheet:c,config:a,prefix:i,getCssString:c.toString,toString:c.toString},g=d.theme(s);return Object.assign(d.theme,g),g.toString(),d}));return n||i.reset(),i})(t);return n.styled=(({config:e,sheet:t})=>q(e,(()=>{const n=v(e,t);return (...e)=>{const t=Y(e[0]),i=n(...e),r=Z$1.forwardRef(((e,n)=>{const r=e&&e.as||t,o=i(e).props;return delete o.as,o.ref=n,Z$1.createElement(r,o)}));return r.className=i.className,r.displayName=`Styled.${t.displayName||t.name||t}`,r.selector=i.selector,r.type=t,r.toString=()=>i.selector,r[s]=i[s],r}})))(n),n},Q=()=>X||(X=K()),te=(...e)=>Q().keyframes(...e),ne=(...e)=>Q().styled(...e);//# sourceMappingUrl=index.map

    const nativeFontFamily$1 = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif';
    const ModalContainer = ne('div', {
        fontFamily: nativeFontFamily$1,
        variants: {
            opened: {
                true: {
                    background: 'rgba(0, 0, 0, .6)',
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                },
                false: {
                    display: 'none',
                }
            }
        },
    });
    const Modal = ne('div', {
        maxWidth: 420,
        borderRadius: 6,
        background: '#fff',
        padding: '16px 16px 0',
        '& > div': {
            padding: 16,
        },
        '& .h1': {
            fontWeight: 500,
            fontSize: 16,
            marginBottom: 10,
        },
    });
    const ModalFooter = ne('div', {
        borderTop: '1px solid #d1d1d1',
        display: 'flex',
        justifyContent: 'space-between',
        '& > div:first-child': {
            opacity: .7,
        }
    });
    const Button = ne('a', {
        display: 'inline-block',
        textTransform: 'uppercase',
        padding: '5px 10px',
        cursor: 'pointer',
        '&:hover': {
            opacity: 1,
            background: 'rgba(66, 139, 202, 0.2)',
            borderRadius: 3,
        }
    });
    const Link = ne('a', {
        color: 'inherit',
        opacity: .6,
        display: 'inline-block',
        padding: '6px 13px',
        fontSize: '90%',
        cursor: 'pointer',
        '&:hover': {
            color: 'inherit',
            textDecoration: 'underline',
        }
    });

    function UpdateModal({ version }) {
        const [isOpened, setOpened] = l$1(true);
        y$1(() => {
            setOpened((isOpened) => {
                if (isOpened === false) {
                    $(".container").css("filter", "blur(0px)");
                    document.body.style.overflow = 'initial';
                }
                return isOpened;
            });
        }, [isOpened]);
        return (v$3(ModalContainer, { opened: isOpened },
            v$3(Modal, null,
                v$3("div", null,
                    v$3("div", { className: "h1" }, "Update Required"),
                    v$3("p", null, "The extension needs to be updated in order to work properly."),
                    v$3("p", null,
                        "Click ",
                        v$3("b", null, "INSTALL"),
                        " to see installation guides or ",
                        v$3("b", null, "Deactivate"),
                        " to deactivate the extension.")),
                v$3(ModalFooter, null,
                    v$3("div", null,
                        "v",
                        version),
                    v$3("div", null,
                        v$3(Link, { onClick: () => setOpened(false) }, "Deactivate Extension"),
                        v$3(Button, { href: "https://github.com/itsumarfarooq/quizsliver#how-to-install" }, "Install"))))));
    }

    const Loader$2 = ne('div', {
        border: "1px solid",
        height: 32,
        borderRadius: 18,
        position: "absolute",
        top: 73,
        right: 15,
        display: "flex",
        alignItems: 'center',
        overflow: "hidden",
        padding: "6px 12px",
        cursor: "pointer",
        "&:hover .message": {
            opacity: 1,
            maxWidth: 600,
            marginLeft: 10,
            transition: "opacity 100ms ease-out 400ms, max-width 500ms ease-out 50ms, margin 100ms linear 0ms",
        },
        "& .message": {
            display: "inline-block",
            opacity: 0,
            marginLeft: 0,
            maxWidth: 0,
            transition: "opacity 100ms ease-out 0ms, max-width 450ms ease-out 0ms, margin 100ms linear 0ms",
        },
        "& .icon": {
            display: "inline-block",
            position: "relative",
            padding: "1px 6px",
            width: 16,
            height: 16,
        },
        variants: {
            state: {
                success: {
                    color: "#155724",
                    borderColor: "#c3e6cb",
                    backgroundColor: "#d4edda",
                },
                error: {
                    color: "#721c24",
                    borderColor: "#f5c6cb",
                    backgroundColor: "#f8d7da",
                },
                loading: {
                    color: "#0c5460",
                    borderColor: "#c3e6cb",
                    backgroundColor: "#d4edda",
                }
            },
            expanded: {
                true: {
                    "& .message": {
                        opacity: 1,
                        maxWidth: 600,
                        marginLeft: 10,
                    }
                }
            }
        },
    });

    const spin = te({
        '0%': { transform: 'rotate(0deg)' },
        '100%': { transform: 'rotate(360deg)' },
    });
    var Spinner = ne('div', {
        border: "2px solid transparent",
        borderTopColor: "currentColor",
        borderRadius: "50%",
        display: "inline-block",
        width: 18,
        height: 18,
        animation: `${spin} 1s linear infinite`,
    });

    function CheckIcon(props) {
      return /*#__PURE__*/v$3("svg", Object.assign({
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor"
      }, props), /*#__PURE__*/v$3("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 2,
        d: "M5 13l4 4L19 7"
      }));
    }

    function XIcon(props) {
      return /*#__PURE__*/v$3("svg", Object.assign({
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor"
      }, props), /*#__PURE__*/v$3("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: 2,
        d: "M6 18L18 6M6 6l12 12"
      }));
    }

    var LoaderState;
    (function (LoaderState) {
        LoaderState["Loading"] = "loading";
        LoaderState["Error"] = "error";
        LoaderState["Success"] = "success";
    })(LoaderState || (LoaderState = {}));
    let icons = {
        [LoaderState.Loading]: v$3(Spinner, null),
        [LoaderState.Success]: v$3(CheckIcon, { style: { width: '16px', height: '16px' } }),
        [LoaderState.Error]: v$3(XIcon, { style: { width: '16px', height: '16px' } }),
    };
    function Loader$1() {
        const [state, setState] = l$1(LoaderState.Loading);
        const [message, setMessage] = l$1("");
        const [isExpanded, setExpand] = l$1(true);
        const [interval, setIntervalVal] = l$1();
        window[_app$].updateLoaderState = (state, message) => {
            setState(state);
            setMessage(message);
            setExpand(true);
            setIntervalVal((interval) => {
                if (interval) {
                    clearInterval(interval);
                }
                return window.setInterval(() => setExpand(false), 3000);
            });
        };
        y$1(() => {
            setInterval(() => setExpand(false), 5000);
        }, []);
        return (v$3(Loader$2, { state: state, expanded: isExpanded },
            icons[state],
            v$3("span", { className: "message" }, message)));
    }

    class InstructionsPage {
        loading = true;
        async handle(doc) {
            this.renderLoader();
            let quizBtn = $(".start_quiz_btn");
            $(quizBtn).removeAttr("href");
            $(quizBtn).click(this.onQuizStart.bind(this));
            localStorage["currentQuiz"] = getQueryParam("QuizId");
            window[_app$].updateLoaderState(LoaderState.Loading, "Checking for version info");
            let newVersion = await updateService.checkForUpdate();
            if (newVersion) {
                window[_app$].updateLoaderState(LoaderState.Error, "Update required");
                setTimeout(() => {
                    this.renderUpdateModel(newVersion);
                }, 0);
            }
            else {
                window[_app$].updateLoaderState(LoaderState.Success, "Ready to start quiz");
            }
            this.loading = false;
        }
        onQuizStart() {
            if (this.loading) {
                window[_app$].updateLoaderState(LoaderState.Loading, "Please wait while extension is loading data");
                setTimeout(this.onQuizStart.bind(this), 500);
            }
            else {
                window[_app$].updateLoaderState(LoaderState.Loading, "Starting quiz");
                window.location.assign("/Quizzes/PopulateSingleQuiz");
            }
        }
        renderLoader() {
            let div = document.getElementsByClassName("content_area")[0];
            div.style.position = 'relative';
            div.appendChild(document.createElement('div'));
            S$3(v$3(Loader$1, null), div.lastElementChild);
        }
        renderUpdateModel(version) {
            document.body.style.overflow = 'hidden';
            document.body.appendChild(document.createElement('div'));
            $(".container").css("filter", "blur(4px)");
            S$3(v$3(UpdateModal, { version: version }), document.body.lastElementChild);
        }
    }
    var instructionsPage = new InstructionsPage();

    class McqParser {
        getQuestion(doc) {
            return doc.querySelector('.question_box>*:first-child').innerText;
        }
        getOptions(doc) {
            let options = [];
            let labels = doc.querySelectorAll('.question_box>label');
            labels.forEach((labelEl) => {
                options.push({
                    text: labelEl.innerText,
                    id: labelEl.title,
                });
            });
            return options;
        }
        parse(doc) {
            return {
                text: this.getQuestion(doc),
                opts: this.getOptions(doc),
            };
        }
    }
    var mcqParser = new McqParser();

    class DatabaseService {
        normalizeRollNum(rollNum) {
            return rollNum.replace(/\//g, "-");
        }
        getMcq(courseId, mcqId) {
            return gr(dn(db, `/subjects/${courseId}/mcqs/${mcqId}`));
        }
        setMcq(courseId, mcqId, mcq) {
            return vr(dn(db, `/subjects/${courseId}/mcqs/${mcqId}`), mcq);
        }
        updateMcqAns(ref, data) {
            return vr(ref, data, { merge: true });
        }
        saveMcqToUser(mcqId, ansId, rollNum, quizId, courseId) {
            let docRef = dn(db, `users/${this.normalizeRollNum(rollNum)}/courses/${courseId}/quizzes/${quizId}/`);
            return vr(docRef, { [`mcqs.${mcqId}`]: ansId }, { merge: true });
        }
        async getUserQuiz(rollNum, courseId, quizId) {
            let docRef = dn(db, `users/${this.normalizeRollNum(rollNum)}/courses/${courseId}/quizzes/${quizId}/`);
            return gr(docRef);
        }
    }
    var dbService = new DatabaseService();

    class McqService {
        searchMcq(courseId, mcq) {
            let hash = hashCode(mcq.text);
            return dbService.getMcq(courseId, hash);
        }
        saveMcq(courseId, mcq) {
            let hash = hashCode(mcq.text);
            return dbService.setMcq(courseId, hash, mcq);
        }
        async updateMcq(courseId, mcq) {
            let question = await this.searchMcq(courseId, mcq);
            if (!question || !question.data()) {
                await this.saveMcq(courseId, {
                    text: mcq.text,
                    correct: mcq.correct,
                });
                return;
            }
            let ans;
            for (let choice in question.data().opts)
                if (choice == mcq.correct)
                    ans = question.data().opts[choice];
            if (ans)
                await dbService.updateMcqAns(question.ref, { ans: ans });
            else
                await dbService.updateMcqAns(question.ref, { correct: mcq.correct });
        }
        saveMcqToUser(mcqId, ansId, rollNum, quizId, courseId) {
            return dbService.saveMcqToUser(mcqId, ansId, rollNum, quizId, courseId);
        }
        getUserQuiz(rollNum, courseId, quizId) {
            return dbService.getUserQuiz(rollNum, courseId, quizId);
        }
    }
    var mcqService = new McqService();

    class UserInfoParser {
        parse(doc) {
            let text = document.querySelector(".top_row").innerText;
            let rollNum = text.match(/CIIT\/\w{2}\d{2}-\w{3}-\d{3}\/\w{3}/)[0];
            let [name, father] = document.querySelector('.top_row span').getAttribute('title').split(" S/D/O ");
            return { rollNum, name, father };
        }
    }
    var userInfoParser = new UserInfoParser();

    class CourseDetailsParser {
        parse(doc) {
            if (!document.querySelector(".page_title_container"))
                return { tile: null, teacher: null, creditHours: null, courseCode: null };
            return {
                tile: document.querySelector(".page_title_container>h3").innerText,
                teacher: document.querySelector(".page_title_container>h5:last-of-type").innerText.split(":")[1].trim(),
                creditHours: document.querySelector(".page_title_container>h5").innerText.split(":")[2].trim(),
                courseCode: document.querySelector(".page_title_container>h5").innerText.match(/\w{3}\d{3}/)[0] || localStorage["CurrentCourse"]
            };
        }
    }
    var courseDetailsParser = new CourseDetailsParser();

    class McqPage {
        mcqFound = false;
        mcqMarked = false;
        course;
        parsedMcq;
        userAns;
        user;
        async handle(doc) {
            // remove mcq number
            $(".quiz_opts b").remove();
            if (!document.getElementById("quiz_questions"))
                return;
            this.renderLoader();
            window[_app$].updateLoaderState(LoaderState.Loading, "Parsing Mcq");
            this.course = courseDetailsParser.parse(doc);
            this.parsedMcq = {
                ...mcqParser.parse(doc),
                ans: undefined,
            };
            this.user = userInfoParser.parse(doc);
            window[_app$].updateLoaderState(LoaderState.Loading, "Fetching Mcq");
            let fetchedMcq = await mcqService.searchMcq(this.course.courseCode || localStorage["CurrentCourse"], this.parsedMcq);
            this.mcqFound = !!fetchedMcq.exists;
            this.bindOnMcqSubmitted();
            this.bindOnOptionSelected();
            if (fetchedMcq.exists) {
                this.mcqMarked = await this.markMcq(fetchedMcq.data());
                if (this.mcqMarked) {
                    window[_app$].updateLoaderState(LoaderState.Success, "Known answer marked");
                }
                else {
                    window[_app$].updateLoaderState(LoaderState.Error, "Answer not found");
                }
                // uncomment to auto submit mcq if found
                // this.onMcqSubmit();
            }
            else {
                window[_app$].updateLoaderState(LoaderState.Error, "Answer not found");
            }
        }
        bindOnMcqSubmitted() {
            document.querySelector(`.submit_btn`).setAttribute('onclick', '');
            document.querySelector(`.submit_btn`).addEventListener("click", this.onMcqSubmit.bind(this));
        }
        bindOnOptionSelected() {
            const onOptionSelected = (e) => {
                if (!this.mcqFound && !this.mcqMarked)
                    this.parsedMcq.ans = e.target["value"];
                this.userAns = e.target["value"];
                window[_app$].updateLoaderState(LoaderState.Success, "Answer saved");
            };
            document.querySelectorAll("[name='quiz_option']").forEach(el => el.addEventListener("click", onOptionSelected.bind(this)));
        }
        async onMcqSubmit() {
            window[_app$].updateLoaderState(LoaderState.Loading, "Submitting your Answer");
            if (!this.mcqFound)
                await mcqService.saveMcq(this.course.courseCode || localStorage["CurrentCourse"], this.parsedMcq);
            await mcqService.saveMcqToUser(hashCode(this.parsedMcq.text).toString(), this.userAns, this.user.rollNum, localStorage["currentQuiz"], this.course.courseCode || localStorage["CurrentCourse"]);
            document.forms[0].submit();
        }
        mark(id) {
            let el = document.querySelector(`[value='${id}']`);
            el && el.click();
            return !!el;
        }
        markFromText(text) {
            let correctId = null;
            document.querySelectorAll("[name='quiz_option']").forEach((el) => {
                let id = el.getAttribute("id");
                let labelText = document.querySelector(`[for='${id}']`).innerText.trim();
                if (text == labelText) {
                    correctId = el["value"];
                    el.click();
                }
            });
            return correctId;
        }
        async markMcq(fetchedMcq) {
            if (fetchedMcq.ans) {
                return this.mark(fetchedMcq.ans);
            }
            if (fetchedMcq.correct) {
                let correctId = this.markFromText(fetchedMcq.correct);
                if (!correctId)
                    return false;
                await mcqService.saveMcq(this.course.courseCode, {
                    ...this.parsedMcq,
                    ans: correctId
                });
                return true;
            }
            return false;
        }
        renderLoader() {
            let form = document.getElementById("quiz_questions");
            form.style.position = 'relative';
            form.appendChild(document.createElement('div'));
            S$3(v$3(Loader$1, null), form.lastElementChild);
        }
    }
    var mcqPage = new McqPage();

    const nativeFontFamily = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif';
    const McqsCard = ne('div', {
        float: 'left',
        margin: 16,
        padding: 16,
        overflowX: 'auto',
        fontSize: 16,
        width: 'calc(100% - 30px)',
        fontFamily: nativeFontFamily,
        '& ol': {
            padding: 0,
        },
        '& h1': {
            marginBottom: 40,
            fontWeight: 300,
            opacity: .8,
            textAlign: 'center'
        },
        '& p': {
            fontSize: 16,
        }
    });

    const Question = ne('li', {
        paddingTop: 50,
        paddingLeft: 20,
        marginLeft: 20,
        marginBottom: 8,
        '&:first-of-type': {
            paddingTop: 20,
        },
    });
    const QuestionText = ne('p', {
        paddingTop: 8,
        fontSize: 16,
        paddingBottom: 20,
    });
    const QuestionOption = ne('div', {
        padding: "5px 0 5px 50px",
        position: "relative",
        variants: {
            correct: {
                true: {
                    '&::before': {
                        content: ' ',
                        position: "absolute",
                        left: 3,
                        top: 8,
                        height: 9,
                        width: 17,
                        opacity: .7,
                        borderStyle: "solid",
                        borderWidth: "0 0 2px 2px",
                        borderColor: "green",
                        transform: "rotate(-45deg)",
                    }
                }
            },
            disabled: {
                true: {
                    '&::before': {
                        content: ' ',
                        position: "absolute",
                        left: 0,
                        height: 20,
                        width: 20,
                        border: "2px solid rgba(0, 0, 0, 0.54)",
                        borderRadius: '50%',
                    }
                }
            },
            selected: {
                true: {
                    '&::before': {
                        content: ' ',
                        position: "absolute",
                        left: 0,
                        top: 15,
                        width: 20,
                        border: '1px solid red',
                        opacity: 0.7,
                        transform: 'rotate(-45deg)',
                    },
                    '&::after': {
                        content: ' ',
                        position: "absolute",
                        left: 0,
                        top: 15,
                        width: 20,
                        border: '1px solid red',
                        opacity: 0.7,
                        transform: 'rotate(45deg)',
                    }
                }
            }
        }
    });

    function Loader(props) {
        const [loading, setLoading] = l$1(true);
        const [mcq, setMcq] = l$1();
        y$1(() => {
            dbService.getMcq(props.courseId, props.mcq)
                .then((mcq) => {
                setLoading(false);
                setMcq(mcq.data());
            });
        }, []);
        if (loading) {
            return v$3(Question, null,
                v$3(Spinner, null));
        }
        return (v$3(Question, null,
            v$3(QuestionText, null, mcq.text),
            v$3("div", null, mcq.opts && Object.entries(mcq.opts).map(([optText, optId]) => {
                let isCorrect = optText == mcq.ans || optText == mcq.correct;
                let isSelected = props.selected == optText;
                return (v$3(QuestionOption, { selected: isSelected, correct: isCorrect, disabled: !isCorrect && !isSelected }, optText));
            }))));
    }

    function UserMcqs(props) {
        if (!props.mcqs) {
            return (v$3(McqsCard, null,
                v$3("h1", null, "Attempted Mcqs not Found"),
                v$3("p", null, "QuizSliver extension was not enabled while solving this quiz.")));
        }
        return (v$3(McqsCard, null,
            v$3("h1", null, "All Attempted Mcqs"),
            v$3("ol", null, Object.keys(props.mcqs).map((id) => (v$3(Loader, { mcq: id.replace("mcqs.", ''), selected: props.mcqs[id], courseId: props.courseId }))))));
    }

    class TabularParser {
        tableContainerSelector;
        buildObj(_) {
            return null;
        }
        static getNthCol(row, n) {
            return row.querySelector(`td:nth-child(${n})`);
        }
        static getNthColText(row, n) {
            return TabularParser.getNthCol(row, n).innerText;
        }
        parse(element, isDocument = true) {
            let data = [];
            let rows;
            if (isDocument)
                rows = element.querySelectorAll(`${this.tableContainerSelector} table>tbody>tr`);
            else
                rows = element.querySelectorAll(`tbody>tr`);
            rows.forEach((row) => {
                if (!row.innerText.match(/No data available/i))
                    data.push(this.buildObj(row));
            });
            return data;
        }
    }

    class QuizDetailParser extends TabularParser {
        constructor() {
            super();
            this.tableContainerSelector = ".allowance_table";
        }
        buildObj(row) {
            return {
                text: TabularParser.getNthCol(row, 3).children[0].innerText,
                selectText: TabularParser.getNthCol(row, 4).children[0].innerText,
                correct: TabularParser.getNthCol(row, 5).children[0].innerText,
            };
        }
    }
    var quizDetailParser = new QuizDetailParser();

    class McqDetailPage {
        course;
        userInfo;
        quizId;
        async handle(doc) {
            this.course = courseDetailsParser.parse(doc);
            this.userInfo = userInfoParser.parse(doc);
            for (const mcq of quizDetailParser.parse(doc)) {
                await mcqService.updateMcq(this.course.courseCode, mcq);
            }
            this.quizId = getQueryParam("QuizId");
            let userMcqs = await mcqService.getUserQuiz(this.userInfo.rollNum, this.course.courseCode, this.quizId);
            await this.renderUserMcq(userMcqs.data(), this.course.courseCode);
        }
        async renderUserMcq(mcqs, courseId) {
            let mainContent = document.getElementById("QuizSummaryMain");
            mainContent.innerHTML += "<div></div>";
            S$3(v$3(UserMcqs, { mcqs: mcqs, courseId: courseId }), mainContent.lastElementChild);
        }
    }
    var mcqDetailPage = new McqDetailPage();

    class QuizzesPage {
        handle(doc) {
            $(".startquiz[title^='Take']").on('click', async (e) => {
                $(".se-pre-con").fadeIn("slow");
                e.preventDefault();
                // Will be used if current course is lost from session
                localStorage["CurrentCourse"] = courseDetailsParser.parse(doc).courseCode;
                window.location.assign($(e.target).attr('href'));
            });
        }
    }
    var quizzesPage = new QuizzesPage();

    class CoursesPage {
        async handle(doc) {
            let trs = document.querySelectorAll("tr[onclick]");
            for (let i = 0; i < trs.length; i++) {
                let id = trs[i]
                    .getAttribute('onclick')
                    .match(/\/Courses\/SetCourse\/(\d+)/)[1];
                trs[i].setAttribute('onclick', "");
                trs[i].onclick = () => {
                    this.onCourseOpened(id, trs[i].querySelector('td').innerText.trim());
                };
            }
        }
        onCourseOpened(id, code) {
            localStorage['currentCourse'] = code;
            window.location.assign(`/Courses/SetCourse/${id}`);
        }
    }
    var coursesPage = new CoursesPage();

    let handlers = {
        "^\/Quizzes\/Instructions$": instructionsPage,
        "PopulateSingleQuiz": mcqPage,
        "GetAttemptedQuizDetails": mcqDetailPage,
        "^\/Quizzes\/?(Index)?\/?$": quizzesPage,
        "^\/Courses\/?(Index\/?)?$": coursesPage
    };
    for (let handler in handlers) {
        let re = new RegExp(handler, "i");
        if (re.exec(window.location.pathname)) {
            handlers[handler].handle(document);
        }
    }

}());
